async function test() {
  const res = await fetch("https://vidcloud.eu.org/play.php", {
    headers: { "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36" }
  });
  const html = await res.text();
  const scripts = html.match(/<script[^>]*>[\s\S]*?<\/script>/gi) || [];
  console.log("Total scripts:", scripts.length);
  for (const s of scripts) {
    const srcMatch = s.match(/src=["']([^"']+)["']/);
    if (srcMatch) {
      console.log("Script src:", srcMatch[1]);
    } else {
      console.log("Inline script snippet:", s.slice(0, 400));
      console.log("---");
    }
  }
}
test().catch(console.error);
