import React, { useState, useEffect, useMemo } from "react";
import { Link } from "wouter";
import { BatchItem } from "../types/meded";
import { fetchMyBatches, fetchCohortBatches } from "../lib/api";
import { BatchCard } from "../components/BatchCard";
import {
  Search,
  Sparkles,
  BookOpen,
  Layers,
  Award,
  Stethoscope,
  RefreshCw,
  GraduationCap,
  ArrowRight,
  Filter,
  CheckCircle2,
} from "lucide-react";

type CategoryFilter = "all" | "bds" | "neetpg" | "fmge" | "clinical";

function categorize(name: string): "bds" | "neetpg" | "fmge" | "clinical" {
  const n = (name || "").toUpperCase();
  if (n.includes("BDS") || n.includes("DENTAL") || n.includes("PRECLINICAL")) return "bds";
  if (n.includes("FMGE")) return "fmge";
  if (n.includes("NEET") || n.includes("INICET")) return "neetpg";
  return "clinical";
}

function getBadge(category: "bds" | "neetpg" | "fmge" | "clinical"): string {
  switch (category) {
    case "bds":
      return "BDS Curriculum";
    case "neetpg":
      return "NEET-PG / INI-CET";
    case "fmge":
      return "FMGE";
    case "clinical":
      return "Clinical & MBBS";
  }
}

export function Home() {
  const [activeCategory, setActiveCategory] = useState<CategoryFilter>("all");
  const [allBatches, setAllBatches] = useState<BatchItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");

  const loadData = async () => {
    setLoading(true);
    try {
      const [mine, cohort] = await Promise.all([
        fetchMyBatches(),
        fetchCohortBatches(),
      ]);

      // Merge unique batches by _id
      const batchMap = new Map<string, BatchItem>();
      (mine || []).forEach((b) => batchMap.set(b._id, b));
      (cohort || []).forEach((b) => {
        if (!batchMap.has(b._id)) {
          batchMap.set(b._id, b);
        }
      });

      setAllBatches(Array.from(batchMap.values()));
    } catch (err) {
      console.error("Error loading batches:", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  // Category counts
  const counts = useMemo(() => {
    const res = { all: allBatches.length, bds: 0, neetpg: 0, fmge: 0, clinical: 0 };
    allBatches.forEach((b) => {
      const cat = categorize(b.name);
      res[cat] = (res[cat] || 0) + 1;
    });
    return res;
  }, [allBatches]);

  // Filtered displayed batches
  const displayedBatches = useMemo(() => {
    return allBatches.filter((b) => {
      const matchesCategory =
        activeCategory === "all" || categorize(b.name) === activeCategory;
      const matchesSearch =
        search.trim() === "" ||
        b.name.toLowerCase().includes(search.toLowerCase()) ||
        (b.byName && b.byName.toLowerCase().includes(search.toLowerCase()));
      return matchesCategory && matchesSearch;
    });
  }, [allBatches, activeCategory, search]);

  return (
    <div className="min-h-screen pb-16">
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-b from-cyan-950/40 via-slate-900 to-slate-950 border-b border-slate-800 py-12 px-4 sm:px-6 lg:px-8">
        <div className="absolute top-0 right-1/4 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none"></div>
        <div className="absolute bottom-0 left-1/3 w-80 h-80 bg-teal-500/10 rounded-full blur-3xl pointer-events-none"></div>

        <div className="max-w-7xl mx-auto relative z-10">
          <div className="inline-flex items-center space-x-2 px-3 py-1.5 rounded-full bg-cyan-900/60 border border-cyan-700/60 text-cyan-300 text-xs font-semibold mb-4 backdrop-blur-sm">
            <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
            <span>PW MedEd Active Student Workspace</span>
          </div>

          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white tracking-tight leading-tight">
            Medical Education Platform <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-teal-300 to-sky-400">
              NEET-PG, FMGE, BDS & MBBS
            </span>
          </h1>

          <p className="mt-3 text-base sm:text-lg text-slate-300 max-w-2xl">
            Access your live lectures, recorded videos, interactive 3D models, class notes PDFs, and DPPs across all 44 medical & dental curriculum batches.
          </p>

          {/* Quick Stats Bar */}
          <div className="mt-8 grid grid-cols-2 sm:grid-cols-4 gap-4 max-w-4xl">
            <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-3.5 flex items-center space-x-3">
              <div className="p-2.5 rounded-lg bg-cyan-950 text-cyan-400">
                <BookOpen className="w-5 h-5" />
              </div>
              <div>
                <p className="text-xs text-slate-400 font-medium">Available Batches</p>
                <p className="text-lg font-bold text-white">{allBatches.length || 44} Batches</p>
              </div>
            </div>

            <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-3.5 flex items-center space-x-3">
              <div className="p-2.5 rounded-lg bg-teal-950 text-teal-400">
                <Stethoscope className="w-5 h-5" />
              </div>
              <div>
                <p className="text-xs text-slate-400 font-medium">Primary Focus</p>
                <p className="text-lg font-bold text-white">BDS 1st Year</p>
              </div>
            </div>

            <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-3.5 flex items-center space-x-3">
              <div className="p-2.5 rounded-lg bg-indigo-950 text-indigo-400">
                <Layers className="w-5 h-5" />
              </div>
              <div>
                <p className="text-xs text-slate-400 font-medium">Curricula Covered</p>
                <p className="text-lg font-bold text-white">BDS, PG, FMGE</p>
              </div>
            </div>

            <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-3.5 flex items-center space-x-3">
              <div className="p-2.5 rounded-lg bg-emerald-950 text-emerald-400">
                <Award className="w-5 h-5" />
              </div>
              <div>
                <p className="text-xs text-slate-400 font-medium">Account Access</p>
                <p className="text-lg font-bold text-emerald-400">Verified Pro</p>
              </div>
            </div>
          </div>

          {/* Quick Access Featured: PRARAMBH BDS 1st Year 2026 */}
          <div className="mt-8 p-4 sm:p-5 rounded-2xl bg-gradient-to-r from-cyan-950/70 via-slate-900/90 to-teal-950/70 border border-cyan-800/40 shadow-xl max-w-4xl backdrop-blur-sm">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="flex items-start sm:items-center space-x-3.5">
                <div className="p-3 rounded-xl bg-cyan-600/20 border border-cyan-500/40 text-cyan-400 shrink-0">
                  <GraduationCap className="w-6 h-6" />
                </div>
                <div>
                  <div className="flex items-center space-x-2">
                    <span className="px-2 py-0.5 text-[10px] font-bold bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 rounded">
                      PRIMARY COHORT
                    </span>
                    <span className="text-xs text-slate-400">5 Core Subjects</span>
                  </div>
                  <h3 className="text-base sm:text-lg font-bold text-white mt-0.5">
                    PRARAMBH BDS 1st Year 2026
                  </h3>
                  <p className="text-xs text-slate-300 mt-0.5 line-clamp-1">
                    Anatomy • Dental Anatomy & Histology (DADH) • Physiology • Biochemistry • Preclinical
                  </p>
                </div>
              </div>
              <Link
                href="/batch/6a6de3dc386150cc7a2b4232"
                className="shrink-0 inline-flex items-center justify-center space-x-2 px-4 py-2.5 bg-gradient-to-r from-cyan-600 to-teal-600 hover:from-cyan-500 hover:to-teal-500 text-white font-semibold text-sm rounded-xl shadow-lg shadow-cyan-600/30 transition-all group"
              >
                <span>Enter Classroom</span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Main Content Area */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-8">
        {/* Filter Controls & Search */}
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-6 border-b border-slate-800">
          {/* Category Tabs */}
          <div className="flex flex-wrap p-1 bg-slate-900 border border-slate-800 rounded-xl gap-1">
            <button
              onClick={() => setActiveCategory("all")}
              className={`px-3 sm:px-4 py-2 rounded-lg text-xs sm:text-sm font-semibold transition-all ${
                activeCategory === "all"
                  ? "bg-cyan-600 text-white shadow-md shadow-cyan-600/30"
                  : "text-slate-400 hover:text-white"
              }`}
            >
              All Batches ({counts.all})
            </button>

            <button
              onClick={() => setActiveCategory("bds")}
              className={`px-3 sm:px-4 py-2 rounded-lg text-xs sm:text-sm font-semibold transition-all ${
                activeCategory === "bds"
                  ? "bg-cyan-600 text-white shadow-md shadow-cyan-600/30"
                  : "text-slate-400 hover:text-white"
              }`}
            >
              BDS Curriculum ({counts.bds})
            </button>

            <button
              onClick={() => setActiveCategory("neetpg")}
              className={`px-3 sm:px-4 py-2 rounded-lg text-xs sm:text-sm font-semibold transition-all ${
                activeCategory === "neetpg"
                  ? "bg-cyan-600 text-white shadow-md shadow-cyan-600/30"
                  : "text-slate-400 hover:text-white"
              }`}
            >
              NEET-PG / INI-CET ({counts.neetpg})
            </button>

            <button
              onClick={() => setActiveCategory("fmge")}
              className={`px-3 sm:px-4 py-2 rounded-lg text-xs sm:text-sm font-semibold transition-all ${
                activeCategory === "fmge"
                  ? "bg-cyan-600 text-white shadow-md shadow-cyan-600/30"
                  : "text-slate-400 hover:text-white"
              }`}
            >
              FMGE ({counts.fmge})
            </button>

            <button
              onClick={() => setActiveCategory("clinical")}
              className={`px-3 sm:px-4 py-2 rounded-lg text-xs sm:text-sm font-semibold transition-all ${
                activeCategory === "clinical"
                  ? "bg-cyan-600 text-white shadow-md shadow-cyan-600/30"
                  : "text-slate-400 hover:text-white"
              }`}
            >
              MBBS & Clinical ({counts.clinical})
            </button>
          </div>

          {/* Search Bar & Refresh */}
          <div className="flex items-center space-x-2">
            <div className="relative flex-1 sm:w-72">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search batches by name..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="w-full pl-9 pr-4 py-2 bg-slate-900 border border-slate-800 rounded-xl text-sm text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 transition-colors"
              />
              {search && (
                <button
                  onClick={() => setSearch("")}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-slate-400 hover:text-white"
                >
                  ✕
                </button>
              )}
            </div>

            <button
              onClick={loadData}
              title="Refresh batches"
              className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            >
              <RefreshCw className={`w-4 h-4 ${loading ? "animate-spin" : ""}`} />
            </button>
          </div>
        </div>

        {/* Active Filter Indicator */}
        <div className="flex items-center justify-between text-xs text-slate-400 mt-4">
          <div className="flex items-center space-x-1.5">
            <Filter className="w-3.5 h-3.5 text-cyan-400" />
            <span>
              Showing <strong className="text-white">{displayedBatches.length}</strong> of {allBatches.length} available batches
              {activeCategory !== "all" && (
                <span className="text-cyan-400 font-semibold ml-1">
                  • {getBadge(activeCategory as any)}
                </span>
              )}
            </span>
          </div>

          {search && (
            <button
              onClick={() => setSearch("")}
              className="text-cyan-400 hover:underline"
            >
              Clear search filter
            </button>
          )}
        </div>

        {/* Batches Grid */}
        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mt-6">
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <div
                key={i}
                className="h-80 bg-slate-900/60 border border-slate-800/80 rounded-2xl animate-pulse"
              ></div>
            ))}
          </div>
        ) : displayedBatches.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mt-6">
            {displayedBatches.map((batch) => {
              const cat = categorize(batch.name);
              return (
                <BatchCard
                  key={batch._id}
                  batch={batch}
                  badge={getBadge(cat)}
                />
              );
            })}
          </div>
        ) : (
          <div className="text-center py-16 bg-slate-900/40 border border-slate-800/60 rounded-2xl mt-6">
            <Stethoscope className="w-12 h-12 text-slate-600 mx-auto mb-3" />
            <h3 className="text-lg font-bold text-white">No batches match your query</h3>
            <p className="text-sm text-slate-400 mt-1">
              Try adjusting your search query or selecting a different category tab.
            </p>
            {(activeCategory !== "all" || search) && (
              <button
                onClick={() => {
                  setActiveCategory("all");
                  setSearch("");
                }}
                className="mt-4 px-4 py-2 bg-cyan-600 hover:bg-cyan-500 text-white rounded-xl text-xs font-semibold"
              >
                Reset All Filters
              </button>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
