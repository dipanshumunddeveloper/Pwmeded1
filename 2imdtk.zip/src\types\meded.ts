export interface BatchItem {
  _id: string;
  name: string;
  batchName?: string;
  byName?: string;
  slug?: string;
  language?: string;
  exam?: string[];
  class?: string;
  examYear?: string;
  isPurchased?: boolean;
  isFree?: boolean;
  previewImage?: {
    _id?: string;
    baseUrl?: string;
    key?: string;
    name?: string;
  };
  startDate?: string;
  endDate?: string;
  meta?: Array<{
    key: string;
    value: string;
    displayOrder?: number;
  }>;
}

export interface Teacher {
  _id: string;
  firstName: string;
  lastName: string;
  qualification?: string;
  subject?: string;
  experience?: string;
  imageId?: {
    baseUrl?: string;
    key?: string;
  };
}

export interface Subject {
  _id: string;
  subject: string;
  subjectId: string;
  slug: string;
  lectureCount: number;
  tagCount: number;
  teacherIds: Teacher[];
  fileId?: {
    baseUrl?: string;
    key?: string;
  };
  imageId?: {
    baseUrl?: string;
    key?: string;
  };
}

export interface BatchDetail extends BatchItem {
  subjects: Subject[];
  description?: string;
  shortDescription?: string;
}

export interface Topic {
  _id: string;
  name: string;
  slug?: string;
  tag?: string;
  type?: string;
  typeId?: string;
  displayOrder?: number;
  notes?: number;
  exercises?: number;
  videos?: number;
  lectureVideos?: number;
  videoCount?: number;
  notesCount?: number;
  dppCount?: number;
}

export interface LectureContent {
  _id: string;
  topic: string;
  childId?: string;
  videoId?: string;
  date?: string;
  startTime?: string;
  endTime?: string;
  status?: string;
  url?: string;
  urlType?: string;
  lectureType?: string;
  duration?: string;
  videoDetails?: {
    _id?: string;
    id?: string;
    name?: string;
    image?: string;
    videoUrl?: string;
    embedCode?: string;
    duration?: string;
    drmProtected?: boolean;
  };
  homeworkIds?: Array<{
    _id: string;
    topic: string;
    note?: string;
    attachmentIds?: Array<{
      _id: string;
      baseUrl?: string;
      key?: string;
      name?: string;
    }>;
  }>;
}
