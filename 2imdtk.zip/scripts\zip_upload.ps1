$source = "C:\Users\hp\.gemini\antigravity\scratch\pwmeded"
$zipPath = "C:\Users\hp\.gemini\antigravity\scratch\pwmeded_backup.zip"
$tempDir = "C:\Users\hp\.gemini\antigravity\scratch\pwmeded_temp_zip"

if (Test-Path $zipPath) { Remove-Item $zipPath -Force }
if (Test-Path $tempDir) { Remove-Item $tempDir -Recurse -Force }

New-Item -ItemType Directory -Path $tempDir | Out-Null

$exclude = @('node_modules', 'dist', '.wrangler', '.git')

Get-ChildItem -Path $source -Recurse | Where-Object {
    $item = $_
    $skip = $false
    foreach ($ex in $exclude) {
        if ($item.FullName -match "[\\/]$ex([\\/]|$)") {
            $skip = $true
            break
        }
    }
    -not $skip
} | ForEach-Object {
    $rel = $_.FullName.Substring($source.Length).TrimStart('\', '/')
    if ($rel.Length -gt 0) {
        $dest = Join-Path $tempDir $rel
        if ($_.PSIsContainer) {
            New-Item -ItemType Directory -Path $dest -Force | Out-Null
        } else {
            $destParent = Split-Path $dest -Parent
            if (-not (Test-Path $destParent)) {
                New-Item -ItemType Directory -Path $destParent -Force | Out-Null
            }
            Copy-Item -Path $_.FullName -Destination $dest -Force
        }
    }
}

Compress-Archive -Path "$tempDir\*" -DestinationPath $zipPath -Force
Remove-Item $tempDir -Recurse -Force

Write-Output "Zip size: $((Get-Item $zipPath).Length) bytes"

$form = @{
    reqtype = 'fileupload'
    fileToUpload = Get-Item $zipPath
}

$response = Invoke-RestMethod -Uri 'https://catbox.moe/user/api.php' -Method Post -Form $form
Write-Output "CATBOX_URL: $response"
