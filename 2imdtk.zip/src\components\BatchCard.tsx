import React from "react";
import { Link } from "wouter";
import { BatchItem } from "../types/meded";
import { getFullImageUrl } from "../lib/api";
import { GraduationCap, ArrowRight, CheckCircle2, Calendar } from "lucide-react";

interface BatchCardProps {
  batch: BatchItem;
  badge?: string;
}

export function BatchCard({ batch, badge }: BatchCardProps) {
  const imageUrl = getFullImageUrl(batch.previewImage);

  return (
    <div className="group relative bg-slate-900 border border-slate-800 hover:border-cyan-500/50 rounded-2xl overflow-hidden transition-all duration-300 hover:shadow-xl hover:shadow-cyan-950/30 flex flex-col">
      {/* Thumbnail */}
      <div className="relative aspect-video w-full bg-slate-950 overflow-hidden">
        <img
          src={imageUrl}
          alt={batch.name}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          onError={(e) => {
            (e.target as HTMLImageElement).src =
              "https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?w=600&auto=format&fit=crop&q=80";
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-transparent to-black/30"></div>

        {/* Badges */}
        <div className="absolute top-3 left-3 flex flex-wrap gap-1.5">
          {badge && (
            <span className="px-2.5 py-1 text-xs font-semibold bg-emerald-500/90 text-white rounded-md backdrop-blur-sm shadow-sm flex items-center space-x-1">
              <CheckCircle2 className="w-3 h-3" />
              <span>{badge}</span>
            </span>
          )}
          {batch.exam && batch.exam[0] && (
            <span className="px-2.5 py-1 text-xs font-semibold bg-cyan-600/90 text-white rounded-md backdrop-blur-sm">
              {batch.exam[0]}
            </span>
          )}
        </div>

        {batch.language && (
          <div className="absolute bottom-3 right-3 px-2 py-0.5 text-[11px] font-medium bg-slate-900/80 text-slate-300 rounded border border-slate-700/60 backdrop-blur-sm">
            {batch.language}
          </div>
        )}
      </div>

      {/* Content */}
      <div className="p-5 flex-1 flex flex-col justify-between">
        <div>
          <h3 className="font-bold text-lg text-white group-hover:text-cyan-400 transition-colors line-clamp-1">
            {batch.name}
          </h3>
          <p className="text-xs text-slate-400 mt-1 line-clamp-2">
            {batch.byName || "PW MedEd Comprehensive Curriculum for Medical & Dental Aspirants"}
          </p>

          {/* Metadata chips */}
          <div className="mt-4 flex flex-wrap gap-2 text-xs text-slate-400">
            {batch.meta?.map((m, idx) => (
              <span key={idx} className="bg-slate-800/80 px-2 py-1 rounded-md border border-slate-700/50">
                <strong className="text-slate-200">{m.value}</strong> {m.key.toLowerCase()}
              </span>
            ))}
            {batch.class && (
              <span className="bg-slate-800/80 px-2 py-1 rounded-md border border-slate-700/50">
                Class: <strong className="text-slate-200">{batch.class}</strong>
              </span>
            )}
          </div>
        </div>

        {/* CTA Button */}
        <div className="mt-5 pt-4 border-t border-slate-800/80">
          <Link
            href={`/batch/${batch._id}`}
            className="w-full inline-flex items-center justify-center space-x-2 px-4 py-2.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-medium text-sm transition-colors shadow-md shadow-cyan-600/20"
          >
            <span>Enter Classroom</span>
            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </Link>
        </div>
      </div>
    </div>
  );
}
