@echo off
cd /d "%~dp0"
echo ==================================================
echo   Starting PWMedEd Local Platform...
echo ==================================================
node scripts\start.mjs
pause
