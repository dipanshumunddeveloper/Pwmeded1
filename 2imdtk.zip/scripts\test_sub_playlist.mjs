// Test: check sub-playlist for FairPlay keys and check if segments are accessible
const baseUrl = 'https://d1d34p8vz63oiq.cloudfront.net/drm/de9f6d33-1be5-4ed0-a9ad-8913dc037cb0';

async function run() {
  // Check sub-playlist
  const subRes = await fetch(`${baseUrl}/media-1/stream.m3u8`);
  const subText = await subRes.text();
  console.log('Sub-playlist status:', subRes.status);
  console.log(subText.substring(0, 2000));
  
  // Extract FairPlay KID
  const skdMatch = subText.match(/URI="skd:\/\/([^"]+)"/);
  if (skdMatch) {
    console.log('\nFairPlay KID base64:', skdMatch[1]);
    const kidHex = Buffer.from(skdMatch[1], 'base64').toString('hex');
    console.log('KID hex:', kidHex);
  }
  
  // Check if segments are accessible  
  const segMatch = subText.match(/^(segment-\d+\.ts)$/m);
  if (segMatch) {
    console.log('\nTesting segment access:', segMatch[1]);
    const segRes = await fetch(`${baseUrl}/media-1/${segMatch[1]}`, { method: 'HEAD' });
    console.log('Segment status:', segRes.status);
    console.log('Content-Type:', segRes.headers.get('content-type'));
    console.log('Content-Length:', segRes.headers.get('content-length'));
  }

  // Also check if there's a non-DRM version accessible
  // Some PW videos have BOTH /drm/ and non-drm paths
  const nonDrmUrl = baseUrl.replace('/drm/', '/');
  try {
    const nonDrmRes = await fetch(`${nonDrmUrl}/master.m3u8`, { method: 'HEAD' });
    console.log('\nNon-DRM master.m3u8 status:', nonDrmRes.status);
  } catch(e) {
    console.log('\nNon-DRM check failed:', e.message);
  }
}
run();
