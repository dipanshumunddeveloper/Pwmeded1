# PWMedEd — Medical Education Platform (Local Web Clone)

A dedicated, local learning portal crafted for **PW MedEd** (NEET-PG, FMGE, BDS 1st Year & MDS).

## Features

- **Direct MedEd API Integration**: Connects securely with `meded-api.penpencil.co` using active session credentials.
- **Enrolled Batches**:
  - `PRARAMBH BDS 1st Year 2026`
  - `PRECLINICAL PRACTICAL BDS 1st Year`
  - `FARRE 1st Year 2026`
  - `Survival Guide 2026`
- **Full Cohort Browser**: Instant access to all BDS 1st Year, NEET-PG, and MDS cohort batches.
- **Classroom & Subjects**:
  - Subject cards with official faculty details & photos (Dr. Aakash Sinha, Dr. Rajesh Jambhulkar, Dr. Ichita Joshi, Dr. Jyoti Chaturvedi).
  - Chapters & Topics filtering.
- **Lectures & Video Player**:
  - Responsive embedded player for YouTube demo & foundation lectures.
  - Video lecture playlist with completion status, duration, and stream links.
- **Class Notes & DPPs**:
  - In-browser PDF previewer with zoom and drawing tools.
  - 1-click direct download of high-resolution lecture notes.
- **Proxy Server**:
  - Built-in Node Express proxy on port `8081` to handle CORS and stream/PDF delivery seamlessly.

## Quick Start

### 1. Run via Batch File (Double-click or PowerShell)
```cmd
start.bat
```

### 2. Run via Node
```bash
node scripts/start.mjs
```

### 3. URLs
- **Web App**: [http://localhost:5001](http://localhost:5001)
- **API Proxy**: [http://localhost:8081](http://localhost:8081)
