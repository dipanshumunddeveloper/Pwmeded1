import { spawn } from "node:child_process";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const rootDir = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");

console.log("\x1b[36m%s\x1b[0m", "==================================================");
console.log("\x1b[32m%s\x1b[0m", " Starting PWMedEd (Medical Education Platform)...");
console.log("\x1b[36m%s\x1b[0m", "==================================================");

// 1. Start Server
console.log("\x1b[34m[API]\x1b[0m Starting MedEd API proxy on http://localhost:8081...");
const apiServer = spawn(process.execPath, [path.join(rootDir, "server", "index.js")], {
  cwd: rootDir,
  stdio: "inherit",
});

// 2. Start Frontend
console.log("\x1b[35m[Web]\x1b[0m Starting MedEd Frontend on http://localhost:5001...");
const isWin = process.platform === "win32";
const npxCmd = isWin ? "npx.cmd" : "npx";

const webServer = spawn(npxCmd, ["vite", "--port", "5001", "--host", "0.0.0.0"], {
  cwd: rootDir,
  stdio: "inherit",
  shell: true,
});

function cleanup() {
  console.log("\nShutting down PWMedEd...");
  try {
    apiServer.kill();
  } catch {}
  try {
    webServer.kill();
  } catch {}
  process.exit(0);
}

process.on("SIGINT", cleanup);
process.on("SIGTERM", cleanup);

apiServer.on("exit", (code) => {
  if (code && code !== 0) console.error(`[API] Exited with code ${code}`);
});

webServer.on("exit", (code) => {
  if (code && code !== 0) console.error(`[Web] Exited with code ${code}`);
});
