import React, { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { Stethoscope, BookOpen, Layers, ShieldCheck, Search, Sparkles } from "lucide-react";

const SCHOLAR_EMOJIS = [
  "🩺", // Stethoscope
  "👨‍⚕️", // Doctor
  "🧠", // Brain / Neurology
  "⚡", // Energy / Focus
  "🔬", // Microscope
  "🧬", // DNA / Genetics
  "💊", // Pharmacology
  "🎓", // Graduation / Scholar
  "🥼", // Lab Coat
  "✨", // Sparkles
  "🫀", // Anatomical Heart
  "🌟", // Star
];

export function Navbar() {
  const [location] = useLocation();
  const [userProfile, setUserProfile] = useState<{ college?: string; targetExam?: string } | null>(null);
  const [emojiIndex, setEmojiIndex] = useState(0);
  const [isRotating, setIsRotating] = useState(false);

  useEffect(() => {
    fetch("/api/me")
      .then((r) => r.json())
      .then((d) => {
        if (d?.success && d.data) {
          setUserProfile(d.data);
        }
      })
      .catch(() => {});
  }, []);

  // Automatically cycle emojis every 2.6 seconds
  useEffect(() => {
    const interval = setInterval(() => {
      setIsRotating(true);
      setTimeout(() => {
        setEmojiIndex((prev) => (prev + 1) % SCHOLAR_EMOJIS.length);
        setIsRotating(false);
      }, 200);
    }, 2600);
    return () => clearInterval(interval);
  }, []);

  const triggerNextEmoji = () => {
    setIsRotating(true);
    setTimeout(() => {
      setEmojiIndex((prev) => (prev + 1) % SCHOLAR_EMOJIS.length);
      setIsRotating(false);
    }, 150);
  };

  const currentEmoji = SCHOLAR_EMOJIS[emojiIndex];

  return (
    <header className="sticky top-0 z-40 bg-slate-900/90 backdrop-blur-md border-b border-slate-800">
      <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-14 sm:h-16">
          {/* Logo */}
          <div className="flex items-center space-x-2 sm:space-x-3 min-w-0">
            <Link href="/" className="flex items-center space-x-2 sm:space-x-2.5 group">
              <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-xl bg-gradient-to-tr from-cyan-600 to-teal-400 flex items-center justify-center text-white shadow-lg shadow-cyan-500/20 group-hover:scale-105 transition-transform shrink-0">
                <Stethoscope className="w-4 h-4 sm:w-5 sm:h-5" />
              </div>
              <div className="min-w-0">
                <div className="flex items-center space-x-1 sm:space-x-1.5">
                  <span className="font-extrabold text-lg sm:text-xl tracking-tight text-white">PW<span className="text-cyan-400">MedEd</span></span>
                  <span className="px-1.5 py-0.2 text-[9px] sm:text-[10px] font-bold bg-cyan-950 text-cyan-300 border border-cyan-800 rounded">PRO</span>
                </div>
                <p className="hidden sm:block text-[10px] text-slate-400 font-medium truncate">NEET-PG • FMGE • BDS • MDS</p>
              </div>
            </Link>
          </div>

          {/* Navigation Links */}
          <nav className="hidden md:flex items-center space-x-1">
            <Link
              href="/"
              className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-colors ${
                location === "/" ? "bg-slate-800 text-cyan-400 font-semibold" : "text-slate-300 hover:text-white hover:bg-slate-800/60"
              }`}
            >
              My Batches
            </Link>
            <Link
              href="/explore"
              className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-colors ${
                location === "/explore" ? "bg-slate-800 text-cyan-400 font-semibold" : "text-slate-300 hover:text-white hover:bg-slate-800/60"
              }`}
            >
              Explore All Batches
            </Link>
          </nav>

          {/* Dynamic Changing Emoji Profile Badge */}
          <div className="flex items-center space-x-3">
            <div className="hidden sm:flex flex-col text-right">
              <div className="flex items-center justify-end space-x-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                <span className="text-xs font-semibold text-white">
                  Medical Scholar
                </span>
              </div>
              <span className="text-[10px] text-slate-400 truncate max-w-[200px]">
                {userProfile?.college || "PGIDS Rohtak • BDS 1st Year"}
              </span>
            </div>

            <button
              onClick={triggerNextEmoji}
              type="button"
              title="Click to change emoji"
              className="w-10 h-10 rounded-full bg-gradient-to-br from-cyan-950 via-slate-900 to-teal-950 border-2 border-cyan-500/50 hover:border-cyan-400 flex items-center justify-center text-lg shadow-lg shadow-cyan-950/60 hover:scale-105 active:scale-95 transition-all cursor-pointer group relative overflow-hidden"
            >
              <div className="absolute inset-0 bg-cyan-400/10 opacity-0 group-hover:opacity-100 transition-opacity" />
              <span
                className={`transition-all duration-300 transform select-none ${
                  isRotating ? "scale-50 rotate-12 opacity-0" : "scale-100 rotate-0 opacity-100"
                }`}
              >
                {currentEmoji}
              </span>
            </button>
          </div>
        </div>
      </div>
    </header>
  );
}
