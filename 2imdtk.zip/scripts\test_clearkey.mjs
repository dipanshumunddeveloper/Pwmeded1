const token = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJkYXRhIjp7Il9pZCI6IjZhYzc4ZTE4MjUxMzhlOTI3ZmM3YmU4NyIsImNvdW50cnlHcm91cCI6IklOIiwib3JnYW5pemF0aW9uIjp7Il9pZCI6IjYzYjUyOTYzZTcyZThiMDAxODZjMTFmMyJ9LCJyb2xlcyI6WyI1YjI3YmQ5NjU4NDJmOTUwYTc3OGM2ZWYiXSwidHlwZSI6IlVTRVIiLCJ1c2VybmFtZSI6IjYzODc0MjY3NzgifSwiZXhwIjoxNzk1NzAxMzQwLjgxOSwiaWF0IjoxNzk1MDk2NTQwLCJqdGkiOiI4aFZfenpvM1JhYVd0aXdTRGEzRkJ3XzZhYzc4ZTE4MjUxMzhlOTI3ZmM3YmU4NyJ9._zGTjQd2p9mqe3XH7UR9gbgyVezXhXuA6SYpMc1IRV0';

let q = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=';
let P = e => Buffer.from(e.replace(/\r|\n/g, '').replace(/([\da-fA-F]{2}) ?/g, '0x$1 ').replace(/ +$/, '').split(' ').map(x => parseInt(x, 16))).toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=*$/, '');
let N = (e, t) => e.charCodeAt(Math.floor(t % e.length));
let H = e => {
  let t, i, n, o, r, l, a, s, d = 0, u = [];
  if (!e) return e;
  e += '';
  do {
    o = q.indexOf(e.charAt(d++));
    r = q.indexOf(e.charAt(d++));
    l = q.indexOf(e.charAt(d++));
    a = q.indexOf(e.charAt(d++));
    s = o << 18 | r << 12 | l << 6 | a;
    t = s >> 16 & 255;
    i = s >> 8 & 255;
    n = s & 255;
    u.push(t);
    if (64 !== l) {
      u.push(i);
      if (64 !== a) u.push(n);
    }
  } while (d < e.length);
  return u;
};
let Y = (e, t) => Object.assign([], t).map((t, i) => String.fromCharCode(t ^ N(e, i))).join('');
let V = (e, t) => Y(e, t = H(t));
let Q = (e, t) => Object.assign([], t).map((t, i) => t.charCodeAt(0) ^ N(e, i));
let x = e => {
  let t, i, n, o, r, l, a, s, d = 0, u = '';
  if (!e) return e;
  do {
    t = e[d++];
    i = e[d++];
    a = t << 16 | i << 8 | e[d++];
    n = a >> 18 & 63;
    o = a >> 12 & 63;
    r = a >> 6 & 63;
    l = a & 63;
    u += q.charAt(n) + q.charAt(o) + q.charAt(r) + q.charAt(l);
  } while (d < e.length);
  return ((s = e.length % 3) ? u.slice(0, s - 3) : u) + '==='.slice(s || 3);
};
let R = (e, t) => x(t = Q(e, t));
let K = e => {
  e = e.replace(/\-/g, '+').replace(/\_/g, '/');
  let i = Buffer.from(e, 'base64').toString('binary');
  let n = [];
  for (var t = 0; t < i.length; ++t) {
    let e = i.charCodeAt(t).toString(16);
    1 === e.length && (e = '0' + e);
    n[n.length] = e;
  }
  return n.join('');
};
let eo = e => {
  let t, i = '';
  for (t = 0; t < e.length; t++) {
    i += ('000' + e.charCodeAt(t).toString(16)).slice(-4);
  }
  return i;
};

async function test() {
  let kidRaw = 'de9f6d331be54ed0a9ad8913dc037cb0';
  const kidB64 = Buffer.from(kidRaw, 'hex').toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
  const encodedKey = eo(R(token, K(kidB64)));
  
  const headers = {
    'Authorization': 'Bearer ' + token,
    'randomId': '6144d854-f28a-42d3-88c2-276310d6db15',
    'client-id': '63b52963e72e8b00186c11f3',
    'client-version': '165',
    'client-type': 'WEB',
    'version': '0.0.1',
    'Content-Type': 'application/json'
  };

  const urls = [
    'https://meded-api.penpencil.co/v1/videos/get-otp?key=' + encodeURIComponent(encodedKey) + '&isEncoded=true',
    'https://api.penpencil.co/v1/videos/get-otp?key=' + encodeURIComponent(encodedKey) + '&isEncoded=true'
  ];

  for (const u of urls) {
    try {
      const resp = await fetch(u, { headers });
      console.log('URL:', u);
      console.log('Status:', resp.status);
      const json = await resp.json();
      console.log('Response:', json);
      if (json && json.data && json.data.otp) {
        const clearKeyK = P(V(token, json.data.otp));
        console.log('SUCCESS! ClearKey (k):', clearKeyK);
      }
    } catch(e) {
      console.error(e.message);
    }
  }
}
test();
