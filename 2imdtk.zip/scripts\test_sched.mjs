const token = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJkYXRhIjp7Il9pZCI6IjZhYzc4ZTE4MjUxMzhlOTI3ZmM3YmU4NyIsImNvdW50cnlHcm91cCI6IklOIiwib3JnYW5pemF0aW9uIjp7Il9pZCI6IjYzYjUyOTYzZTcyZThiMDAxODZjMTFmMyJ9LCJyb2xlcyI6WyI1YjI3YmQ5NjU4NDJmOTUwYTc3OGM2ZWYiXSwidHlwZSI6IlVTRVIiLCJ1c2VybmFtZSI6IjYzODc0MjY3NzgifSwiZXhwIjoxNzk1NzAxMzQwLjgxOSwiaWF0IjoxNzk1MDk2NTQwLCJqdGkiOiI4aFZfenpvM1JhYVd0aXdTRGEzRkJ3XzZhYzc4ZTE4MjUxMzhlOTI3ZmM3YmU4NyJ9._zGTjQd2p9mqe3XH7UR9gbgyVezXhXuA6SYpMc1IRV0';

async function test() {
  const batchId = '6a6de3dc386150cc7a2b4232';
  const anatomySubjectSlug = '6adb0504d6248830d3d75f5b';
  const scheduleId = '6ace27e27f34f9fab31df011';

  const urls = [
    `https://meded-api.penpencil.co/v1/batches/${batchId}/subject/${anatomySubjectSlug}/schedule/${scheduleId}/schedule-details`,
    `https://api.penpencil.co/v1/batches/${batchId}/subject/${anatomySubjectSlug}/schedule/${scheduleId}/schedule-details`,
    `https://meded-api.penpencil.co/v1/batches/${batchId}/subject/anatomy-819782/schedule/${scheduleId}/schedule-details`,
    `https://meded-api.penpencil.co/v1/batches/${batchId}/subject/${anatomySubjectSlug}/schedule/${scheduleId}`,
  ];

  for (const url of urls) {
    const res = await fetch(url, {
      headers: {
        'authorization': 'Bearer ' + token,
        'client-id': '63b52963e72e8b00186c11f3',
        'client-type': 'WEB',
        'organization-id': '63b52963e72e8b00186c11f3',
        'referer': 'https://meded.pw.live/',
        'origin': 'https://meded.pw.live',
        'secure-video-required': 'true',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
      }
    });
    console.log(url, '-> status:', res.status);
    const data = await res.json();
    console.log('Response:', JSON.stringify(data).slice(0, 300));
  }
}
test();
