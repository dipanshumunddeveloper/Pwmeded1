const token = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJkYXRhIjp7Il9pZCI6IjZhYzc4ZTE4MjUxMzhlOTI3ZmM3YmU4NyIsImNvdW50cnlHcm91cCI6IklOIiwib3JnYW5pemF0aW9uIjp7Il9pZCI6IjYzYjUyOTYzZTcyZThiMDAxODZjMTFmMyJ9LCJyb2xlcyI6WyI1YjI3YmQ5NjU4NDJmOTUwYTc3OGM2ZWYiXSwidHlwZSI6IlVTRVIiLCJ1c2VybmFtZSI6IjYzODc0MjY3NzgifSwiZXhwIjoxNzk1NzAxMzQwLjgxOSwiaWF0IjoxNzk1MDk2NTQwLCJqdGkiOiI4aFZfenpvM1JhYVd0aXdTRGEzRkJ3XzZhYzc4ZTE4MjUxMzhlOTI3ZmM3YmU4NyJ9._zGTjQd2p9mqe3XH7UR9gbgyVezXhXuA6SYpMc1IRV0';

async function test() {
  const params = {
    type: "BATCHES",
    videoContainerType: "DASH",
    reqType: "query",
    childId: "6ace27e27f34f9fab31df011",
    parentId: "6a6de3dc386150cc7a2b4232",
    clientVersion: "3219"
  };

  const hosts = [
    "https://api.penpencil.co",
    "https://meded-api.penpencil.co"
  ];

  const clientIds = [
    "5eb393ee95fab7468a79d189",
    "63b52963e72e8b00186c11f3"
  ];

  for (const host of hosts) {
    for (const cid of clientIds) {
      const qs = new URLSearchParams(params).toString();
      const url = `${host}/v1/videos/video-url-details?${qs}`;
      const res = await fetch(url, {
        headers: {
          "authorization": "Bearer " + token,
          "client-id": cid,
          "client-type": "WEB",
          "Client-Version": "3219",
          "referer": "https://www.pw.live/",
          "origin": "https://www.pw.live",
          "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
        }
      });
      const text = await res.text();
      console.log(`[${res.status}] Host: ${host.slice(8, 20)} | CID: ${cid.slice(0, 8)} -> ${text.slice(0, 150)}`);
    }
  }
}

test();
