import fs from 'fs';

const js = fs.readFileSync('C:/Users/hp/.gemini/antigravity/scratch/watch_bundle_index.js', 'utf8');

let pos = 0;
while ((pos = js.indexOf('stateKey', pos)) !== -1) {
  console.log('--- Found stateKey ---');
  console.log(js.slice(Math.max(0, pos - 150), Math.min(js.length, pos + 250)));
  pos += 8;
}
