// Test: extract default_KID from HLS manifest
const hlsUrl = 'https://d1d34p8vz63oiq.cloudfront.net/drm/de9f6d33-1be5-4ed0-a9ad-8913dc037cb0/master.m3u8';

async function run() {
  const res = await fetch(hlsUrl);
  const text = await res.text();
  console.log('Status:', res.status);
  
  // Extract the skd:// base64 KID
  const m = text.match(/URI="skd:\/\/([^"]+)"/);
  if (m) {
    console.log('FairPlay KID base64:', m[1]);
    const kidHex = Buffer.from(m[1], 'base64').toString('hex');
    console.log('KID hex:', kidHex);
  }
  
  // Show first 25 lines
  console.log('---');
  console.log(text.split('\n').slice(0, 25).join('\n'));
  
  // Also check the MPD (expect 403 without signed params)
  const mpdUrl = hlsUrl.replace('/master.m3u8', '/master.mpd');
  try {
    const mpdRes = await fetch(mpdUrl);
    console.log('\nMPD Status:', mpdRes.status);
    if (mpdRes.ok) {
      const mpdText = await mpdRes.text();
      // Extract default_KID from DASH
      const kidMatch = mpdText.match(/default_KID="([^"]+)"/i) || mpdText.match(/cenc:default_KID="([^"]+)"/i);
      if (kidMatch) {
        console.log('DASH default_KID:', kidMatch[1]);
      }
      console.log(mpdText.substring(0, 1000));
    }
  } catch(e) {
    console.error('MPD fetch failed:', e.message);
  }
}
run();
