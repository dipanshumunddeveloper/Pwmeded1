// Test: ClearKey resolution using the existing token from test_clearkey.mjs  
// Since the worker token is expired, let's use the hardcoded one from test_clearkey.mjs

const token = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJkYXRhIjp7Il9pZCI6IjZhYzc4ZTE4MjUxMzhlOTI3ZmM3YmU4NyIsImNvdW50cnlHcm91cCI6IklOIiwib3JnYW5pemF0aW9uIjp7Il9pZCI6IjYzYjUyOTYzZTcyZThiMDAxODZjMTFmMyJ9LCJyb2xlcyI6WyI1YjI3YmQ5NjU4NDJmOTUwYTc3OGM2ZWYiXSwidHlwZSI6IlVTRVIiLCJ1c2VybmFtZSI6IjYzODc0MjY3NzgifSwiZXhwIjoxNzk1NzAxMzQwLjgxOSwiaWF0IjoxNzk1MDk2NTQwLCJqdGkiOiI4aFZfenpvM1JhYVd0aXdTRGEzRkJ3XzZhYzc4ZTE4MjUxMzhlOTI3ZmM3YmU4NyJ9._zGTjQd2p9mqe3XH7UR9gbgyVezXhXuA6SYpMc1IRV0';

// Check if this token is still valid
const exp = JSON.parse(Buffer.from(token.split('.')[1], 'base64').toString()).exp;
console.log('Token expires:', new Date(exp * 1000).toISOString());
console.log('Now:', new Date().toISOString());
console.log('Is valid:', Date.now() < exp * 1000);

// Also check the worker's KV token
async function run() {
  // Fetch from worker
  const workerRes = await fetch('https://pwmeded.dipanshumund-529.workers.dev/api/auth/token');
  const workerData = await workerRes.json();
  if (workerData.token) {
    const workerExp = JSON.parse(Buffer.from(workerData.token.split('.')[1], 'base64').toString()).exp;
    console.log('\nWorker token expires:', new Date(workerExp * 1000).toISOString());
    console.log('Worker token valid:', Date.now() < workerExp * 1000);
  }
}
run();
