import React, { useState, useEffect } from "react";
import { Link, useRoute } from "wouter";
import {
  fetchBatchDetails,
  fetchSubjectTopics,
  fetchSubjectContents,
  getFullImageUrl,
} from "../lib/api";
import { BatchDetail, Subject, Topic, LectureContent } from "../types/meded";
import { PdfModal } from "../components/PdfModal";
import {
  ChevronLeft,
  ChevronRight,
  Video,
  FileText,
  BookOpen,
  HelpCircle,
  Calendar,
  Clock,
  Download,
  Eye,
  Play,
  Layers,
  Sparkles,
  ArrowLeft,
  Search,
} from "lucide-react";

type ContentTab = "videos" | "notes" | "dppNotes" | "exercises";

export function TopicDetail() {
  const [, params] = useRoute("/batch/:batchId/subject/:subjectId/topic/:topicId");
  const batchId = params?.batchId || "";
  const subjectId = params?.subjectId || "";
  const topicId = params?.topicId || "";

  const [batch, setBatch] = useState<BatchDetail | null>(null);
  const [subject, setSubject] = useState<Subject | null>(null);
  const [topics, setTopics] = useState<Topic[]>([]);
  const [currentTopic, setCurrentTopic] = useState<Topic | null>(null);

  const [activeTab, setActiveTab] = useState<ContentTab>("videos");
  const [contents, setContents] = useState<LectureContent[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchFilter, setSearchFilter] = useState("");

  // PDF Preview Modal
  const [modalPdf, setModalPdf] = useState<{ url: string; title: string } | null>(null);

  // 1. Fetch Batch, Subject, and Topics
  useEffect(() => {
    if (!batchId || !subjectId) return;

    fetchBatchDetails(batchId).then((b) => {
      if (b) {
        setBatch(b);
        const sub = b.subjects?.find((s) => s._id === subjectId);
        if (sub) setSubject(sub);
      }
    });

    fetchSubjectTopics(batchId, subjectId).then((tList) => {
      setTopics(tList);
      const match = tList.find((t) => t._id === topicId || t.slug === topicId);
      if (match) {
        setCurrentTopic(match);
      } else if (tList.length > 0) {
        setCurrentTopic(tList[0]);
      }
    });
  }, [batchId, subjectId, topicId]);

  // 2. Fetch Contents when activeTab or currentTopic changes
  useEffect(() => {
    if (!batchId || !subjectId || !currentTopic) return;
    setLoading(true);

    fetchSubjectContents(batchId, subjectId, activeTab, currentTopic._id)
      .then((data) => {
        setContents(data);
      })
      .catch((err) => {
        console.error("Failed to load contents:", err);
        setContents([]);
      })
      .finally(() => setLoading(false));
  }, [batchId, subjectId, activeTab, currentTopic]);

  const filteredContents = searchFilter.trim()
    ? contents.filter((c) => {
        const text = (
          c.topic ||
          c.homeworkIds?.[0]?.topic ||
          ""
        ).toLowerCase();
        return text.includes(searchFilter.trim().toLowerCase());
      })
    : contents;

  // Chapter index
  const topicIndex = topics.findIndex((t) => t._id === currentTopic?._id);

  return (
    <div className="min-h-screen pb-16 bg-slate-950 text-slate-100">
      {/* Top Breadcrumb Header */}
      <div className="bg-slate-900/70 border-b border-slate-800 py-3 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto flex items-center space-x-2 text-xs text-slate-400 overflow-x-auto scrollbar-none whitespace-nowrap">
          <Link href="/" className="hover:text-white transition-colors shrink-0">
            Home
          </Link>
          <span>/</span>
          {batch && (
            <>
              <Link href={`/batch/${batch._id}`} className="hover:text-white transition-colors shrink-0 truncate max-w-[120px] sm:max-w-xs">
                {batch.name}
              </Link>
              <span>/</span>
            </>
          )}
          {subject && (
            <>
              <Link
                href={`/batch/${batchId}/subject/${subjectId}`}
                className="hover:text-white transition-colors shrink-0 truncate max-w-[120px] sm:max-w-xs"
              >
                {subject.subject}
              </Link>
              <span>/</span>
            </>
          )}
          <span className="text-cyan-400 font-semibold truncate shrink-0">
            {currentTopic?.name || "Chapter"}
          </span>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-6">
        {/* Chapter Header Banner */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-7 shadow-xl">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-5">
            <div>
              <div className="flex items-center space-x-2">
                <Link
                  href={`/batch/${batchId}/subject/${subjectId}`}
                  className="inline-flex items-center space-x-1 px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold transition-colors"
                >
                  <ArrowLeft className="w-3.5 h-3.5" />
                  <span>All Chapters</span>
                </Link>
                <span className="px-2.5 py-0.5 text-xs font-bold bg-cyan-950 text-cyan-400 border border-cyan-800 rounded-md">
                  CHAPTER {topicIndex >= 0 ? `#${String(topicIndex + 1).padStart(2, "0")}` : ""}
                </span>
                <span className="text-xs text-slate-400 font-medium">
                  {subject?.subject}
                </span>
              </div>

              <h1 className="text-xl sm:text-3xl font-extrabold text-white mt-3">
                {currentTopic?.name || "Chapter Contents"}
              </h1>

              {/* Counters */}
              <div className="mt-3 flex flex-wrap gap-2 text-xs">
                {currentTopic?.videos !== undefined && (
                  <span className="px-2.5 py-1 rounded-md bg-slate-800/80 text-cyan-300 border border-slate-700 font-medium flex items-center space-x-1">
                    <Video className="w-3.5 h-3.5 text-cyan-400" />
                    <span>{currentTopic.videos} Lectures</span>
                  </span>
                )}
                {currentTopic?.notes !== undefined && (
                  <span className="px-2.5 py-1 rounded-md bg-slate-800/80 text-teal-300 border border-slate-700 font-medium flex items-center space-x-1">
                    <FileText className="w-3.5 h-3.5 text-teal-400" />
                    <span>{currentTopic.notes} Notes</span>
                  </span>
                )}
                {currentTopic?.exercises !== undefined && (
                  <span className="px-2.5 py-1 rounded-md bg-slate-800/80 text-purple-300 border border-slate-700 font-medium flex items-center space-x-1">
                    <BookOpen className="w-3.5 h-3.5 text-purple-400" />
                    <span>{currentTopic.exercises} DPPs</span>
                  </span>
                )}
              </div>
            </div>

            {/* Quick Chapter Selector Pills for multi-chapter subjects */}
            {topics.length > 1 && (
              <div className="flex flex-col space-y-2 border-t md:border-t-0 md:border-l border-slate-800 pt-3 md:pt-0 md:pl-5">
                <span className="text-xs font-semibold text-slate-400">Other Chapters in {subject?.subject}:</span>
                <div className="flex flex-wrap gap-1.5 max-w-sm">
                  {topics.map((t, idx) => {
                    const isCur = t._id === currentTopic?._id;
                    return (
                      <Link
                        key={t._id}
                        href={`/batch/${batchId}/subject/${subjectId}/topic/${t._id}`}
                        className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition-colors flex items-center space-x-1 ${
                          isCur
                            ? "bg-cyan-600 text-white shadow-md shadow-cyan-900/40"
                            : "bg-slate-800 hover:bg-slate-700 text-slate-300"
                        }`}
                      >
                        <span>#{idx + 1}</span>
                        <span className="truncate max-w-[120px]">{t.name}</span>
                      </Link>
                    );
                  })}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Content Tabs */}
        <div className="mt-8 flex items-center justify-between border-b border-slate-800 pb-3 flex-wrap gap-3">
          <div className="flex items-center space-x-1.5 sm:space-x-2 overflow-x-auto scrollbar-none pb-1">
            <button
              onClick={() => { setActiveTab("videos"); setSearchFilter(""); }}
              className={`px-3.5 sm:px-4 py-2 rounded-xl text-xs sm:text-sm font-bold flex items-center space-x-1.5 transition-colors whitespace-nowrap ${
                activeTab === "videos"
                  ? "bg-cyan-600 text-white shadow-md shadow-cyan-600/30"
                  : "text-slate-400 hover:text-white hover:bg-slate-900"
              }`}
            >
              <Video className="w-4 h-4" />
              <span>Lectures</span>
              {currentTopic?.videos !== undefined && (
                <span className="ml-1 px-1.5 py-0.2 rounded-full text-[10px] bg-black/40">
                  {currentTopic.videos}
                </span>
              )}
            </button>

            <button
              onClick={() => { setActiveTab("notes"); setSearchFilter(""); }}
              className={`px-3.5 sm:px-4 py-2 rounded-xl text-xs sm:text-sm font-bold flex items-center space-x-1.5 transition-colors whitespace-nowrap ${
                activeTab === "notes"
                  ? "bg-cyan-600 text-white shadow-md shadow-cyan-600/30"
                  : "text-slate-400 hover:text-white hover:bg-slate-900"
              }`}
            >
              <FileText className="w-4 h-4" />
              <span>Class Notes</span>
              {currentTopic?.notes !== undefined && (
                <span className="ml-1 px-1.5 py-0.2 rounded-full text-[10px] bg-black/40">
                  {currentTopic.notes}
                </span>
              )}
            </button>

            <button
              onClick={() => { setActiveTab("dppNotes"); setSearchFilter(""); }}
              className={`px-3.5 sm:px-4 py-2 rounded-xl text-xs sm:text-sm font-bold flex items-center space-x-1.5 transition-colors whitespace-nowrap ${
                activeTab === "dppNotes"
                  ? "bg-cyan-600 text-white shadow-md shadow-cyan-600/30"
                  : "text-slate-400 hover:text-white hover:bg-slate-900"
              }`}
            >
              <BookOpen className="w-4 h-4" />
              <span>DPP Notes</span>
            </button>

            <button
              onClick={() => { setActiveTab("exercises"); setSearchFilter(""); }}
              className={`px-3.5 sm:px-4 py-2 rounded-xl text-xs sm:text-sm font-bold flex items-center space-x-1.5 transition-colors whitespace-nowrap ${
                activeTab === "exercises"
                  ? "bg-cyan-600 text-white shadow-md shadow-cyan-600/30"
                  : "text-slate-400 hover:text-white hover:bg-slate-900"
              }`}
            >
              <HelpCircle className="w-4 h-4" />
              <span>Exercises</span>
            </button>
          </div>

          {/* Quick Search in Chapter */}
          {contents.length > 2 && (
            <div className="relative w-full sm:w-64">
              <Search className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Filter by title..."
                value={searchFilter}
                onChange={(e) => setSearchFilter(e.target.value)}
                className="w-full pl-9 pr-3 py-1.5 rounded-xl bg-slate-900 border border-slate-800 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 transition-colors"
              />
            </div>
          )}
        </div>

        {/* Tab 1: Lectures & Videos View */}
        {activeTab === "videos" && (
          <div className="mt-6">
            {loading ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {[1, 2, 3, 4].map((i) => (
                  <div key={i} className="aspect-video bg-slate-900 rounded-2xl animate-pulse"></div>
                ))}
              </div>
            ) : filteredContents.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredContents.map((lec, idx) => {
                  const thumb =
                    lec.videoDetails?.image ||
                    (subject?.imageId ? getFullImageUrl(subject.imageId) : null);

                  return (
                    <div
                      key={lec._id}
                      className="bg-slate-900 border border-slate-800 hover:border-cyan-500/50 rounded-2xl overflow-hidden shadow-xl transition-all duration-300 hover:-translate-y-1 group flex flex-col justify-between"
                    >
                      <div>
                        {/* 16:9 Thumbnail Header */}
                        <div className="relative aspect-video w-full bg-slate-950 overflow-hidden">
                          {thumb ? (
                            <img
                              src={thumb}
                              alt={lec.topic}
                              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                              loading="lazy"
                            />
                          ) : (
                            <div className="w-full h-full flex items-center justify-center bg-gradient-to-tr from-cyan-950 to-slate-900 text-cyan-400">
                              <Play className="w-10 h-10 fill-current" />
                            </div>
                          )}

                          {/* Gradient Vignette */}
                          <div className="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-transparent to-black/30 pointer-events-none" />

                          {/* Duration Badge */}
                          {lec.duration && (
                            <div className="absolute bottom-2.5 right-2.5 px-2 py-0.5 rounded-md bg-black/80 backdrop-blur-sm text-[10px] font-mono font-bold text-white border border-white/10 shadow-md">
                              {lec.duration}
                            </div>
                          )}

                          {/* Top Badges (No completed/pending) */}
                          <div className="absolute top-2.5 left-2.5 flex items-center space-x-1.5">
                            <span className="px-2 py-0.5 rounded-md bg-cyan-950/90 text-cyan-300 border border-cyan-800/80 text-[10px] font-extrabold shadow">
                              #{String(idx + 1).padStart(2, "0")}
                            </span>
                          </div>

                          {/* Hover Play Icon Overlay */}
                          <Link
                            href={`/batch/${batchId}/subject/${subjectId}/watch/${lec._id}`}
                            className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity bg-black/40 backdrop-blur-[1px]"
                          >
                            <div className="w-12 h-12 rounded-full bg-cyan-500 text-black flex items-center justify-center shadow-xl shadow-cyan-900/60 transition-transform transform group-hover:scale-110">
                              <Play className="w-6 h-6 fill-current translate-x-0.5" />
                            </div>
                          </Link>
                        </div>

                        {/* Card Body */}
                        <div className="p-4">
                          <h4 className="text-sm font-bold text-white group-hover:text-cyan-300 transition-colors line-clamp-2 leading-snug">
                            {lec.topic}
                          </h4>

                          <div className="mt-2.5 flex items-center space-x-2 text-[11px] text-slate-400">
                            {lec.date && (
                              <span className="inline-flex items-center space-x-1">
                                <Calendar className="w-3 h-3 text-slate-500" />
                                <span>
                                  {new Date(lec.date).toLocaleDateString([], {
                                    month: "short",
                                    day: "numeric",
                                    year: "numeric",
                                  })}
                                </span>
                              </span>
                            )}
                          </div>
                        </div>
                      </div>

                      {/* Watch in Cinema Button */}
                      <div className="px-4 pb-4 pt-2 border-t border-slate-800/80">
                        <Link
                          href={`/batch/${batchId}/subject/${subjectId}/watch/${lec._id}`}
                          className="w-full inline-flex items-center justify-center space-x-2 px-4 py-2.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-bold transition-colors shadow-lg shadow-cyan-900/40"
                        >
                          <Play className="w-3.5 h-3.5 fill-current" />
                          <span>Watch Lecture</span>
                        </Link>
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="text-center py-16 bg-slate-900/40 border border-slate-800 rounded-2xl text-slate-400">
                <Video className="w-12 h-12 mx-auto text-slate-600 mb-2" />
                <p>No video lectures found in this chapter.</p>
              </div>
            )}
          </div>
        )}

        {/* Tab 2: Class Notes & Tab 3: DPP Notes */}
        {(activeTab === "notes" || activeTab === "dppNotes") && (
          <div className="mt-6">
            {loading ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {[1, 2, 3].map((i) => (
                  <div key={i} className="h-32 bg-slate-900 rounded-xl animate-pulse"></div>
                ))}
              </div>
            ) : filteredContents.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {filteredContents.map((item) => {
                  const homework = item.homeworkIds?.[0];
                  const attachment = homework?.attachmentIds?.[0];
                  const noteTitle = homework?.topic || item.topic || "Classroom Document";
                  const pdfUrl = attachment ? getFullImageUrl(attachment) : null;

                  return (
                    <div
                      key={item._id}
                      className="bg-slate-900 border border-slate-800 hover:border-cyan-500/40 rounded-xl p-5 flex flex-col justify-between transition-all group"
                    >
                      <div>
                        <div className="flex items-start justify-between gap-2">
                          <div className="p-2 rounded-lg bg-cyan-950 text-cyan-400">
                            <FileText className="w-5 h-5" />
                          </div>
                          <span className="px-2 py-0.5 text-[10px] font-bold bg-slate-800 text-slate-300 rounded uppercase">
                            {activeTab === "dppNotes" ? "DPP NOTE" : "CLASS NOTE"}
                          </span>
                        </div>
                        <h4 className="text-sm font-bold text-white mt-3 group-hover:text-cyan-300 transition-colors line-clamp-2">
                          {noteTitle}
                        </h4>
                        <p className="text-xs text-slate-400 mt-1">
                          {homework?.note || "Official MedEd Study Material"}
                        </p>
                      </div>

                      <div className="mt-5 pt-3 border-t border-slate-800/80 flex items-center space-x-2">
                        {pdfUrl ? (
                          <>
                            <button
                              onClick={() => setModalPdf({ url: pdfUrl, title: noteTitle })}
                              className="flex-1 inline-flex items-center justify-center space-x-1.5 px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-lg transition-colors"
                            >
                              <Eye className="w-3.5 h-3.5" />
                              <span>Preview</span>
                            </button>

                            <a
                              href={`/api/pdf-proxy?url=${encodeURIComponent(pdfUrl)}`}
                              download={`${noteTitle}.pdf`}
                              className="flex-1 inline-flex items-center justify-center space-x-1.5 px-3 py-2 bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold rounded-lg transition-colors"
                            >
                              <Download className="w-3.5 h-3.5" />
                              <span>Download</span>
                            </a>
                          </>
                        ) : (
                          <span className="text-xs text-slate-500 italic">No attachment linked</span>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="text-center py-16 bg-slate-900/40 border border-slate-800 rounded-2xl text-slate-400">
                <FileText className="w-12 h-12 mx-auto text-slate-600 mb-2" />
                <p>No documents found for this section.</p>
              </div>
            )}
          </div>
        )}

        {/* Tab 4: Exercises */}
        {activeTab === "exercises" && (
          <div className="mt-6">
            {loading ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {[1, 2].map((i) => (
                  <div key={i} className="h-32 bg-slate-900 rounded-xl animate-pulse"></div>
                ))}
              </div>
            ) : filteredContents.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {filteredContents.map((ex, idx) => (
                  <div
                    key={ex._id}
                    className="bg-slate-900 border border-slate-800 hover:border-cyan-500/40 rounded-xl p-5 flex flex-col justify-between transition-all"
                  >
                    <div>
                      <div className="flex items-center justify-between">
                        <span className="px-2 py-0.5 text-[10px] font-bold bg-cyan-950 text-cyan-400 border border-cyan-800 rounded">
                          DPP EXERCISE #{idx + 1}
                        </span>
                      </div>
                      <h4 className="text-sm font-bold text-white mt-3">
                        {ex.topic || "Practice Exercise"}
                      </h4>
                    </div>

                    <div className="mt-5 pt-3 border-t border-slate-800/80">
                      <span className="text-xs text-slate-400">
                        Interactive DPP Exercise
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-16 bg-slate-900/40 border border-slate-800 rounded-2xl text-slate-400">
                <HelpCircle className="w-12 h-12 mx-auto text-slate-600 mb-2" />
                <p>No DPP exercises available in this chapter.</p>
              </div>
            )}
          </div>
        )}
      </div>

      {/* PDF Modal */}
      {modalPdf && (
        <PdfModal
          isOpen={Boolean(modalPdf)}
          onClose={() => setModalPdf(null)}
          pdfUrl={modalPdf.url}
          title={modalPdf.title}
        />
      )}
    </div>
  );
}

export default TopicDetail;
