async function test() {
  const url = 'https://vidcloud.eu.org/play.php?batch_id=6a6de3dc386150cc7a2b4232&video_id=6ace27e27f34f9fab31df011';
  const res = await fetch(url, {
    headers: {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
      'Referer': 'https://vidcloud.eu.org/'
    }
  });
  console.log('Status:', res.status);
  const text = await res.text();
  const inputs = text.match(/<input\s+type="hidden"[^>]+>/g) || [];
  inputs.forEach(inp => console.log('  ' + inp));
}
test().catch(console.error);
