async function test() {
  const p = new URLSearchParams({
    batch_id: "6a6de3dc386150cc7a2b4232",
    subject_id: "6adb0504d6248830d3d75f5b",
    topic_id: "classes",
    video_id: "6ace27e27f34f9fab31df011",
    video_url: "https://d1d34p8vz63oiq.cloudfront.net/drm/de9f6d33-1be5-4ed0-a9ad-8913dc037cb0/master.mpd",
    video_name: "General & Systemic Histology",
    video_img: "https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/1a59e176-2b08-4850-a836-adc8eda54d5c.png",
    video_type: "penpencilvdo",
    play_type: "Lecture"
  });

  const url = `https://vidcloud.eu.org/play.php?${p.toString()}`;
  console.log("Testing URL:", url);

  const res = await fetch(url, {
    headers: {
      "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
      "Referer": "https://vidcloud.eu.org/"
    }
  });

  console.log("Status:", res.status);
  const text = await res.text();
  const inputs = text.match(/<input\s+type="hidden"[^>]+>/g) || [];
  inputs.forEach(inp => console.log("  " + inp));
}

test().catch(console.error);
