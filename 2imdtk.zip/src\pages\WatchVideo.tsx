import React, { useState, useEffect } from "react";
import { Link, useRoute, useLocation } from "wouter";
import {
  fetchBatchDetails,
  fetchSubjectContents,
} from "../lib/api";
import { BatchDetail, Subject, LectureContent } from "../types/meded";
import { VideoPlayer } from "../components/VideoPlayer";
import {
  ChevronLeft,
  ChevronRight,
  Play,
  List,
  X,
  ArrowLeft,
} from "lucide-react";

export function WatchVideo() {
  const [, params] = useRoute("/batch/:batchId/subject/:subjectId/watch/:lectureId");
  const [, altParams] = useRoute("/batch/:batchId/subject/:subjectId/lecture/:lectureId");
  const [, setLocation] = useLocation();

  const p = (params || altParams) as Record<string, string> | null;
  const batchId = p?.batchId || "";
  const subjectId = p?.subjectId || "";
  const lectureId = p?.lectureId || "";

  // Data States
  const [batch, setBatch] = useState<BatchDetail | null>(null);
  const [subject, setSubject] = useState<Subject | null>(null);
  const [lectures, setLectures] = useState<LectureContent[]>([]);
  const [currentLecture, setCurrentLecture] = useState<LectureContent | null>(null);
  const [loading, setLoading] = useState(true);
  const [showPlaylistDrawer, setShowPlaylistDrawer] = useState(false);

  useEffect(() => {
    if (!batchId || !subjectId) return;

    fetchBatchDetails(batchId).then((b) => {
      if (b) {
        setBatch(b);
        const sub = b.subjects?.find((s) => s._id === subjectId);
        if (sub) setSubject(sub);
      }
    });

    // Fetch lectures
    fetchSubjectContents(batchId, subjectId, "videos").then((data) => {
      setLectures(data);
      if (data.length > 0) {
        const found = lectureId ? data.find((l) => l._id === lectureId) : null;
        setCurrentLecture(found || data[0]);
      }
      setLoading(false);
    });
  }, [batchId, subjectId, lectureId]);

  const currentIndex = lectures.findIndex(
    (l) => l._id === (currentLecture?._id || lectureId)
  );
  const prevLecture = currentIndex > 0 ? lectures[currentIndex - 1] : null;
  const nextLecture =
    currentIndex >= 0 && currentIndex < lectures.length - 1
      ? lectures[currentIndex + 1]
      : null;

  const handleSelectLecture = (lec: LectureContent) => {
    setCurrentLecture(lec);
    setShowPlaylistDrawer(false);
    setLocation(`/batch/${batchId}/subject/${subjectId}/watch/${lec._id}`);
  };

  return (
    <div className="min-h-screen bg-black text-slate-100 flex flex-col justify-start">
      {/* Ultra-Minimal Header */}
      <header className="sticky top-0 z-30 bg-slate-950/90 backdrop-blur-md border-b border-slate-900 px-3 sm:px-6 py-2">
        <div className="max-w-7xl mx-auto flex items-center justify-between gap-3">
          {/* Back link */}
          <Link
            href={`/batch/${batchId}/subject/${subjectId}`}
            className="inline-flex items-center space-x-1.5 px-2.5 py-1.5 rounded-lg text-xs font-semibold text-slate-300 hover:text-white hover:bg-slate-800 transition-colors shrink-0"
          >
            <ArrowLeft className="w-4 h-4" />
            <span className="hidden sm:inline">Back</span>
          </Link>

          {/* Current Lecture Title in Header */}
          <div className="flex-1 text-center min-w-0 px-2">
            <h1 className="text-xs sm:text-sm font-bold text-white truncate">
              {currentLecture?.topic || "Loading Video..."}
            </h1>
          </div>

          {/* Minimal Navigation & Playlist */}
          <div className="flex items-center space-x-1.5 shrink-0">
            {prevLecture && (
              <button
                onClick={() => handleSelectLecture(prevLecture)}
                title={`Previous: ${prevLecture.topic}`}
                className="p-1.5 rounded-lg bg-slate-850 hover:bg-slate-800 text-slate-300 hover:text-white transition-colors"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
            )}

            {nextLecture && (
              <button
                onClick={() => handleSelectLecture(nextLecture)}
                title={`Next: ${nextLecture.topic}`}
                className="p-1.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white transition-colors flex items-center space-x-1 text-xs font-semibold px-2"
              >
                <span className="hidden sm:inline">Next</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            )}

            <button
              onClick={() => setShowPlaylistDrawer(!showPlaylistDrawer)}
              title="Show Playlist"
              className="p-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white transition-colors flex items-center space-x-1 text-xs font-semibold px-2"
            >
              <List className="w-4 h-4 text-cyan-400" />
              <span className="hidden sm:inline">Playlist ({lectures.length})</span>
            </button>
          </div>
        </div>
      </header>

      {/* PURE VIDEO CONTAINER - Cinema Mode */}
      <main className="flex-1 w-full max-w-7xl mx-auto flex flex-col justify-center items-center p-0 sm:p-4">
        {loading || !currentLecture ? (
          <div className="aspect-video w-full max-w-6xl bg-slate-950 animate-pulse rounded-none sm:rounded-2xl flex items-center justify-center text-slate-600 text-sm">
            Initializing secure video playback...
          </div>
        ) : (
          <div className="w-full max-w-6xl overflow-hidden rounded-none sm:rounded-2xl bg-black shadow-2xl border-0 sm:border border-slate-900">
            <VideoPlayer
              key={currentLecture._id}
              lecture={currentLecture}
              batchId={batchId}
              showMetaBar={false}
            />
          </div>
        )}
      </main>

      {/* Slide-over Playlist Drawer (Dispatched On-Demand) */}
      {showPlaylistDrawer && (
        <div className="fixed inset-0 z-50 flex justify-end bg-black/60 backdrop-blur-sm transition-opacity">
          <div className="w-full max-w-md bg-slate-900 border-l border-slate-800 flex flex-col h-full shadow-2xl">
            {/* Drawer Header */}
            <div className="p-4 border-b border-slate-800 flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold text-white">Course Lectures</h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  {subject?.subject || "Subject"} • {lectures.length} Lectures
                </p>
              </div>
              <button
                onClick={() => setShowPlaylistDrawer(false)}
                className="p-1.5 rounded-lg bg-slate-800 text-slate-400 hover:text-white transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Drawer List */}
            <div className="flex-1 overflow-y-auto p-3 space-y-2">
              {lectures.map((lec, idx) => {
                const isSelected = lec._id === currentLecture?._id;
                const thumb = lec.videoDetails?.image;

                return (
                  <div
                    key={lec._id}
                    onClick={() => handleSelectLecture(lec)}
                    className={`flex items-center space-x-3 p-2.5 rounded-xl cursor-pointer transition-all border ${
                      isSelected
                        ? "bg-cyan-950/60 border-cyan-500/50 shadow-md"
                        : "bg-slate-950/50 border-slate-800/80 hover:bg-slate-800/60 hover:border-slate-700"
                    }`}
                  >
                    {/* Thumbnail */}
                    <div className="relative w-24 aspect-video rounded-lg overflow-hidden bg-slate-900 shrink-0">
                      {thumb ? (
                        <img
                          src={thumb}
                          alt={lec.topic}
                          className="w-full h-full object-cover"
                          loading="lazy"
                        />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center text-cyan-400 bg-slate-800">
                          <Play className="w-4 h-4 fill-current" />
                        </div>
                      )}
                      {isSelected && (
                        <div className="absolute inset-0 bg-cyan-950/70 flex items-center justify-center">
                          <Play className="w-4 h-4 text-cyan-300 fill-current" />
                        </div>
                      )}
                    </div>

                    {/* Details */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center space-x-1.5">
                        <span className="text-[10px] font-bold text-cyan-400">
                          #{String(idx + 1).padStart(2, "0")}
                        </span>
                        {lec.duration && (
                          <span className="text-[10px] text-slate-400 font-medium">
                            • {lec.duration}
                          </span>
                        )}
                      </div>
                      <h4
                        className={`text-xs font-semibold line-clamp-2 mt-0.5 leading-tight ${
                          isSelected ? "text-cyan-300 font-bold" : "text-slate-200"
                        }`}
                      >
                        {lec.topic}
                      </h4>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default WatchVideo;
