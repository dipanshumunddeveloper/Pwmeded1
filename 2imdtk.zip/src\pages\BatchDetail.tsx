import React, { useState, useEffect } from "react";
import { Link, useRoute } from "wouter";
import { fetchBatchDetails, getFullImageUrl } from "../lib/api";
import { BatchDetail as IBatchDetail } from "../types/meded";
import { SubjectCard } from "../components/SubjectCard";
import {
  ChevronLeft,
  BookOpen,
  Calendar,
  CheckCircle2,
  Users,
  Clock,
  Sparkles,
  Info,
} from "lucide-react";

export function BatchDetail() {
  const [, params] = useRoute("/batch/:batchId");
  const batchId = params ? (params as any).batchId || "" : "";

  const [batch, setBatch] = useState<IBatchDetail | null>(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<"classroom" | "description">("classroom");

  useEffect(() => {
    if (!batchId) return;
    setLoading(true);
    fetchBatchDetails(batchId)
      .then((data) => {
        setBatch(data);
      })
      .catch((err) => {
        console.error(err);
      })
      .finally(() => setLoading(false));
  }, [batchId]);

  if (loading) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-12">
        <div className="h-64 bg-slate-900 border border-slate-800 rounded-3xl animate-pulse"></div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mt-8">
          {[1, 2, 3, 4].map((i) => (
            <div key={i} className="h-48 bg-slate-900 border border-slate-800 rounded-2xl animate-pulse"></div>
          ))}
        </div>
      </div>
    );
  }

  if (!batch) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-16 text-center">
        <h2 className="text-2xl font-bold text-white">Batch Not Found</h2>
        <p className="text-slate-400 mt-2">Could not retrieve information for batch {batchId}.</p>
        <Link
          href="/"
          className="mt-6 inline-flex items-center space-x-2 px-4 py-2 bg-cyan-600 text-white rounded-xl text-sm font-semibold"
        >
          <ChevronLeft className="w-4 h-4" />
          <span>Back to Batches</span>
        </Link>
      </div>
    );
  }

  const previewImg = getFullImageUrl(batch.previewImage);

  return (
    <div className="min-h-screen pb-16">
      {/* Top Breadcrumb Header */}
      <div className="bg-slate-900/60 border-b border-slate-800 py-3 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto flex items-center space-x-2 text-xs text-slate-400">
          <Link href="/" className="hover:text-white transition-colors flex items-center space-x-1">
            <ChevronLeft className="w-3.5 h-3.5" />
            <span>Home</span>
          </Link>
          <span>/</span>
          <span className="text-slate-200 font-medium truncate max-w-xs">{batch.name}</span>
        </div>
      </div>

      {/* Batch Hero Banner */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-8">
        <div className="relative overflow-hidden bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 flex flex-col md:flex-row items-center gap-8 shadow-2xl">
          <div className="w-full md:w-80 aspect-video rounded-2xl overflow-hidden shrink-0 border border-slate-700/80 bg-black">
            <img
              src={previewImg}
              alt={batch.name}
              className="w-full h-full object-cover"
              onError={(e) => {
                (e.target as HTMLImageElement).src =
                  "https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?w=600&auto=format&fit=crop&q=80";
              }}
            />
          </div>

          <div className="flex-1">
            <div className="flex flex-wrap items-center gap-2">
              <span className="px-2.5 py-0.5 text-xs font-bold bg-cyan-950 text-cyan-300 border border-cyan-800 rounded-md">
                PW MEDED
              </span>
              {batch.exam?.[0] && (
                <span className="px-2.5 py-0.5 text-xs font-semibold bg-emerald-950 text-emerald-300 border border-emerald-800 rounded-md">
                  {batch.exam[0]}
                </span>
              )}
              {batch.language && (
                <span className="px-2.5 py-0.5 text-xs font-medium bg-slate-800 text-slate-300 rounded-md">
                  {batch.language}
                </span>
              )}
            </div>

            <h1 className="text-2xl sm:text-3xl font-extrabold text-white mt-3 leading-snug">
              {batch.name}
            </h1>

            <p className="text-sm text-slate-400 mt-2 max-w-2xl">
              {batch.byName || "Full Year Medical Course including Live Lectures, Class Notes, DPPs & Revision."}
            </p>

            {/* Quick stats pills */}
            <div className="mt-5 flex flex-wrap gap-3 text-xs text-slate-300">
              <div className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-slate-800/80 border border-slate-700/50">
                <BookOpen className="w-4 h-4 text-cyan-400" />
                <span>{batch.subjects?.length || 0} Core Subjects</span>
              </div>

              {batch.meta?.map((m, idx) => (
                <div
                  key={idx}
                  className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-slate-800/80 border border-slate-700/50"
                >
                  <Clock className="w-4 h-4 text-teal-400" />
                  <span>
                    {m.value} {m.key.toLowerCase()}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Tabs navigation */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-8">
        <div className="flex space-x-2 border-b border-slate-800 pb-2">
          <button
            onClick={() => setActiveTab("classroom")}
            className={`px-5 py-2.5 rounded-xl font-bold text-sm transition-colors flex items-center space-x-2 ${
              activeTab === "classroom"
                ? "bg-cyan-600 text-white shadow-md shadow-cyan-600/30"
                : "text-slate-400 hover:text-white hover:bg-slate-900"
            }`}
          >
            <BookOpen className="w-4 h-4" />
            <span>Classroom Subjects ({batch.subjects?.length || 0})</span>
          </button>

          <button
            onClick={() => setActiveTab("description")}
            className={`px-5 py-2.5 rounded-xl font-bold text-sm transition-colors flex items-center space-x-2 ${
              activeTab === "description"
                ? "bg-cyan-600 text-white shadow-md shadow-cyan-600/30"
                : "text-slate-400 hover:text-white hover:bg-slate-900"
            }`}
          >
            <Info className="w-4 h-4" />
            <span>Curriculum & Features</span>
          </button>
        </div>

        {/* Tab 1: Classroom Subjects */}
        {activeTab === "classroom" && (
          <div className="mt-8">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-bold text-white">All Subjects</h2>
              <span className="text-xs text-slate-400">
                Select a subject to view chapters, lecture recordings and PDF notes
              </span>
            </div>

            {batch.subjects && batch.subjects.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {batch.subjects.map((sub) => (
                  <SubjectCard key={sub._id} batchId={batch._id} subject={sub} />
                ))}
              </div>
            ) : (
              <div className="text-center py-12 bg-slate-900 rounded-2xl border border-slate-800 text-slate-400">
                No subjects found in this batch.
              </div>
            )}
          </div>
        )}

        {/* Tab 2: Curriculum & Description */}
        {activeTab === "description" && (
          <div className="mt-8 bg-slate-900 border border-slate-800 rounded-2xl p-6 sm:p-8">
            <h3 className="text-lg font-bold text-white mb-4">About this Batch</h3>
            {batch.description ? (
              <div
                className="prose prose-invert max-w-none text-slate-300 text-sm leading-relaxed"
                dangerouslySetInnerHTML={{ __html: batch.description }}
              />
            ) : (
              <p className="text-slate-400 text-sm">
                This batch includes interactive live lectures, recorded videos, question bank with 2000+ questions, 3D anatomical models, vitals cards, daily practice problems (DPPs), and lecture PDF notes.
              </p>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
