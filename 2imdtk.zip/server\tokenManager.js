import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const rootDir = path.resolve(__dirname, "..");
const envPath = path.join(rootDir, ".env");

const CLIENT_ID_AUTH = "system-admin";
const CLIENT_SECRET = "KjPXuAVfC5xbmgreETNMaL7z";
const REFRESH_ENDPOINT = "https://meded-api.penpencil.co/v3/oauth/refresh-token";

let currentToken = process.env.MEDED_TOKEN || "";
let currentRefreshToken = process.env.REFRESH_TOKEN || "dcf4fe39891a753e4c00347058137feead1e78b220f729e2cee61f5f600005b8";
let refreshPromise = null;

function parseJwtExp(token) {
  try {
    const parts = token.split(".");
    if (parts.length < 2) return 0;
    const json = JSON.parse(Buffer.from(parts[1], "base64").toString("utf-8"));
    return (json.exp || 0) * 1000;
  } catch {
    return 0;
  }
}

function updateEnvFile(newToken, newRefreshToken) {
  try {
    if (!fs.existsSync(envPath)) return;
    let content = fs.readFileSync(envPath, "utf-8");
    if (content.includes("MEDED_TOKEN=")) {
      content = content.replace(/MEDED_TOKEN=.*(\r?\n|$)/, `MEDED_TOKEN=${newToken}$1`);
    } else {
      content += `\nMEDED_TOKEN=${newToken}`;
    }
    if (content.includes("REFRESH_TOKEN=")) {
      content = content.replace(/REFRESH_TOKEN=.*(\r?\n|$)/, `REFRESH_TOKEN=${newRefreshToken}$1`);
    } else {
      content += `\nREFRESH_TOKEN=${newRefreshToken}`;
    }
    fs.writeFileSync(envPath, content, "utf-8");
  } catch (err) {
    console.error("[TokenManager] Failed to update .env file:", err.message);
  }
}

export async function refreshAccessToken() {
  if (refreshPromise) {
    return refreshPromise;
  }

  refreshPromise = (async () => {
    try {
      console.log("\x1b[33m[TokenManager]\x1b[0m Automatically refreshing MedEd token from refresh token...");
      const body = {
        client_id: CLIENT_ID_AUTH,
        client_secret: CLIENT_SECRET,
        refresh_token: currentRefreshToken,
      };

      const response = await fetch(REFRESH_ENDPOINT, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "client-id": "63b52963e72e8b00186c11f3",
          "Origin": "https://meded.pw.live",
          "Referer": "https://meded.pw.live/",
        },
        body: JSON.stringify(body),
      });

      if (!response.ok) {
        const errText = await response.text();
        throw new Error(`Refresh token endpoint returned ${response.status}: ${errText}`);
      }

      const json = await response.json();
      if (json?.data?.access_token) {
        currentToken = json.data.access_token;
        process.env.MEDED_TOKEN = currentToken;
        if (json.data.refresh_token) {
          currentRefreshToken = json.data.refresh_token;
          process.env.REFRESH_TOKEN = currentRefreshToken;
        }
        updateEnvFile(currentToken, currentRefreshToken);
        console.log("\x1b[32m[TokenManager]\x1b[0m Token successfully refreshed! New exp:", new Date(json.data.expires_in || Date.now() + 86400000).toLocaleString());
        return currentToken;
      }
      throw new Error("No access_token found in refresh response");
    } finally {
      refreshPromise = null;
    }
  })();

  return refreshPromise;
}

export async function getValidToken() {
  const exp = parseJwtExp(currentToken);
  const now = Date.now();
  // If expired or expiring within 15 minutes, refresh immediately
  if (!currentToken || !exp || now > exp - 15 * 60 * 1000) {
    return await refreshAccessToken();
  }
  return currentToken;
}

export function getCurrentToken() {
  return currentToken;
}

export function getCurrentRefreshToken() {
  return currentRefreshToken;
}
