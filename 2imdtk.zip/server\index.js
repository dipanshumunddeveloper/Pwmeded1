import express from "express";
import cors from "cors";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { getValidToken, refreshAccessToken, getCurrentToken } from "./tokenManager.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const rootDir = path.resolve(__dirname, "..");

// Load .env
const envPath = path.join(rootDir, ".env");
if (fs.existsSync(envPath)) {
  const envContent = fs.readFileSync(envPath, "utf-8");
  for (const line of envContent.split(/\r?\n/)) {
    const trimmed = line.trim();
    if (trimmed && !trimmed.startsWith("#") && trimmed.includes("=")) {
      const idx = trimmed.indexOf("=");
      const key = trimmed.slice(0, idx).trim();
      const val = trimmed.slice(idx + 1).trim();
      if (!process.env[key]) {
        process.env[key] = val.replace(/^["']|["']$/g, "");
      }
    }
  }
}

const PORT = Number(process.env.PORT) || 8081;
const CLIENT_ID = process.env.CLIENT_ID || "63b52963e72e8b00186c11f3";
const ORGANIZATION_ID = process.env.ORGANIZATION_ID || "63b52963e72e8b00186c11f3";
const COHORT_ID = process.env.COHORT_ID || "69fb317edb2ceff4293c1189";

const app = express();
app.use(cors());
app.use(express.json());

async function getMedEdHeaders(req) {
  const token = await getValidToken();
  const auth = req?.headers?.authorization || (token ? `Bearer ${token}` : "");
  return {
    "authorization": auth,
    "client-id": CLIENT_ID,
    "client-type": "WEB",
    "organization-id": ORGANIZATION_ID,
    "referer": "https://meded.pw.live/",
    "origin": "https://meded.pw.live",
    "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    "accept": "application/json, text/plain, */*",
  };
}

async function fetchWithAutoRefresh(url, options = {}, req = null) {
  const headers = await getMedEdHeaders(req);
  let response = await fetch(url, { ...options, headers: { ...headers, ...options.headers } });
  
  if (response.status === 401) {
    console.warn(`\x1b[33m[PWMedEd API]\x1b[0m 401 Unauthorized from ${url}. Automatically refreshing token...`);
    await refreshAccessToken();
    const newHeaders = await getMedEdHeaders(req);
    response = await fetch(url, { ...options, headers: { ...newHeaders, ...options.headers } });
  }
  return response;
}

// Health
app.get("/api/health", (_req, res) => {
  res.json({
    status: "ok",
    service: "pwmeded-api",
    hasToken: Boolean(getCurrentToken()),
    cohortId: COHORT_ID,
  });
});

// User Profile / Settings
app.get("/api/me", (_req, res) => {
  res.json({
    success: true,
    data: {
      name: "Medical Scholar",
      college: process.env.COLLEGE_NAME || "Post Graduate Institute Of Dental Sciences, Rohtak",
      targetExam: process.env.TARGET_EXAM || "BDS 1st Year 2026",
      cohortId: COHORT_ID,
      clientId: CLIENT_ID,
    },
  });
});

// Auth Token Endpoint
app.get("/api/auth/token", async (_req, res) => {
  try {
    const token = await getValidToken();
    res.json({ success: true, token: token || "" });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Enrolled Batches (My Batches)
app.get("/api/batches/my-batches", async (req, res) => {
  try {
    const page = req.query.page || 1;
    const url = `https://api.penpencil.co/v3/batches/my-batches?page=${page}&mode=1`;
    const response = await fetchWithAutoRefresh(url, {}, req);
    const data = await response.json();
    res.status(response.status).json(data);
  } catch (err) {
    console.error("Error fetching my-batches:", err);
    res.status(500).json({ success: false, error: err.message });
  }
});

// Explore Cohort Batches
app.get("/api/cohort/batches", async (req, res) => {
  try {
    const page = req.query.page || 1;
    const limit = req.query.limit || 20;
    const examYear = req.query.examYear || 1;
    const cohort = req.query.cohortId || COHORT_ID;
    const url = `https://meded-api.penpencil.co/v1/cohort/${cohort}/batches?page=${page}&limit=${limit}&examYear=${examYear}&isSubscribed=true`;
    const response = await fetchWithAutoRefresh(url, {}, req);
    const data = await response.json();
    res.status(response.status).json(data);
  } catch (err) {
    console.error("Error fetching cohort batches:", err);
    res.status(500).json({ success: false, error: err.message });
  }
});

// Batch Details
app.get("/api/batches/:batchId/details", async (req, res) => {
  try {
    const { batchId } = req.params;
    const url = `https://meded-api.penpencil.co/v3/batches/${batchId}/details`;
    const response = await fetchWithAutoRefresh(url, {}, req);
    const data = await response.json();
    res.status(response.status).json(data);
  } catch (err) {
    console.error(`Error fetching batch details for ${req.params.batchId}:`, err);
    res.status(500).json({ success: false, error: err.message });
  }
});

// Batch Subject Topics (Chapters)
app.get("/api/batches/:batchId/subject/:subjectId/topics", async (req, res) => {
  try {
    const { batchId, subjectId } = req.params;
    const page = req.query.page || 1;
    const url = `https://meded-api.penpencil.co/v2/batches/${batchId}/subject/${subjectId}/topics?page=${page}`;
    const response = await fetchWithAutoRefresh(url, {}, req);
    const data = await response.json();
    res.status(response.status).json(data);
  } catch (err) {
    console.error("Error fetching topics:", err);
    res.status(500).json({ success: false, error: err.message });
  }
});

// Batch Subject Contents (Videos, Notes, DPPs)
app.get("/api/batches/:batchId/subject/:subjectId/contents", async (req, res) => {
  try {
    const { batchId, subjectId } = req.params;
    const page = req.query.page || 1;
    const contentType = req.query.contentType || "videos";
    let url = `https://meded-api.penpencil.co/v2/batches/${batchId}/subject/${subjectId}/contents?page=${page}&contentType=${contentType}`;
    if (req.query.tag) {
      url += `&tag=${encodeURIComponent(req.query.tag)}`;
    }
    const response = await fetchWithAutoRefresh(url, {}, req);
    const data = await response.json();
    res.status(response.status).json(data);
  } catch (err) {
    console.error("Error fetching contents:", err);
    res.status(500).json({ success: false, error: err.message });
  }
});

// DPPs and Practice Tests
app.get("/api/tests/dpp", async (req, res) => {
  try {
    const { batchId, batchSubjectId, chapterId, page = 1, limit = 20 } = req.query;
    let url = `https://meded-api.penpencil.co/v3/test-service/tests/dpp?batchId=${batchId}&batchSubjectId=${batchSubjectId}&page=${page}&limit=${limit}`;
    if (chapterId) {
      url += `&chapterId=${encodeURIComponent(chapterId)}`;
    }
    const response = await fetchWithAutoRefresh(url, {}, req);
    const data = await response.json();
    res.status(response.status).json(data);
  } catch (err) {
    console.error("Error fetching dpp:", err);
    res.status(500).json({ success: false, error: err.message });
  }
});

// Rewrite m3u8 manifest to ensure all relative chunks and key URIs inherit query parameters
function rewriteM3u8Manifest(manifestText, baseUrl, queryParams) {
  const baseHref = baseUrl.substring(0, baseUrl.lastIndexOf("/") + 1);
  return manifestText
    .split(/\r?\n/)
    .map((line) => {
      const trimmed = line.trim();
      if (!trimmed) return line;
      if (trimmed.startsWith("#")) {
        // Rewrite URI in #EXT-X-KEY
        return line.replace(/URI="([^"]+)"/g, (_m, uri) => {
          try {
            // If it's a PenPencil get-hls-key endpoint, route it through our key proxy
            if (uri.includes("get-hls-key")) {
              const u = new URL(uri);
              const vk = u.searchParams.get("videoKey");
              if (vk) {
                return `URI="/api/videos/get-hls-key?videoKey=${encodeURIComponent(vk)}&key=enc.key"`;
              }
            }
            let fullUri = uri.startsWith("http") ? uri : new URL(uri, baseHref).href;
            if (queryParams && !fullUri.includes("?")) {
              fullUri += queryParams;
            }
            return `URI="${fullUri}"`;
          } catch {
            return `URI="${uri}"`;
          }
        });
      }
      // Segment URI
      try {
        let segUrl = trimmed.startsWith("http") ? trimmed : new URL(trimmed, baseHref).href;
        if (queryParams && !segUrl.includes("?")) {
          segUrl += queryParams;
        }
        return `/api/video-proxy?url=${encodeURIComponent(segUrl)}`;
      } catch {
        return line;
      }
    })
    .join("\n");
}

// Video Stream Resolver: Exchanges batchId & childId for CloudFront signed URL, HLS manifest, & DRM details
app.get("/api/videos/resolve", async (req, res) => {
  const { batchId, childId, videoId } = req.query;
  if (!batchId || (!childId && !videoId)) {
    return res.status(400).json({ success: false, error: "batchId and childId (or videoId) required" });
  }

  const idsToTry = [childId, videoId].filter(Boolean);
  let lastError = null;

  for (const id of idsToTry) {
    try {
      // 1. First attempt with DASH to check for Widevine / Pallycon DRM licenses
      const qsDash = new URLSearchParams({
        type: "BATCHES",
        videoContainerType: "DASH",
        reqType: "query",
        childId: id,
        parentId: batchId,
      });

      const dashUrl = `https://meded-api.penpencil.co/v1/videos/video-url-details?${qsDash.toString()}`;
      const dashResp = await fetchWithAutoRefresh(dashUrl, {}, req);
      if (dashResp.ok) {
        const json = await dashResp.json();
        if (json?.data?.url && json?.data?.signedUrl) {
          const rawUrl = json.data.url;
          const signedQs = json.data.signedUrl;
          const hlsCandidate = rawUrl.replace(/\/master\.mpd$/i, "/master.m3u8") + signedQs;
          const dashCandidate = rawUrl + signedQs;
          const hasDrm = Boolean(json.data.drmDetails?.licenseToken);

          return res.json({
            success: true,
            data: {
              rawUrl,
              signedQs,
              hlsUrl: hlsCandidate,
              dashUrl: dashCandidate,
              hasDrm,
              drmDetails: json.data.drmDetails || null,
              videoContainer: hasDrm ? "DASH" : "HLS",
              signatureExpireAt: json.data.signatureExpireAt,
            },
          });
        }
      }

      // 2. Fallback attempt with HLS
      const qsHls = new URLSearchParams({
        type: "BATCHES",
        videoContainerType: "HLS",
        reqType: "query",
        childId: id,
        parentId: batchId,
      });

      const hlsFetchUrl = `https://meded-api.penpencil.co/v1/videos/video-url-details?${qsHls.toString()}`;
      const hlsResp = await fetchWithAutoRefresh(hlsFetchUrl, {}, req);
      if (hlsResp.ok) {
        const json = await hlsResp.json();
        if (json?.data?.url && json?.data?.signedUrl) {
          const rawUrl = json.data.url;
          const signedQs = json.data.signedUrl;
          const hlsCandidate = rawUrl.replace(/\/master\.mpd$/i, "/master.m3u8") + signedQs;
          const dashCandidate = rawUrl + signedQs;
          const hasDrm = Boolean(json.data.drmDetails?.licenseToken);

          return res.json({
            success: true,
            data: {
              rawUrl,
              signedQs,
              hlsUrl: hlsCandidate,
              dashUrl: dashCandidate,
              hasDrm,
              drmDetails: json.data.drmDetails || null,
              videoContainer: "HLS",
              signatureExpireAt: json.data.signatureExpireAt,
            },
          });
        }
      }
    } catch (err) {
      lastError = err;
    }
  }

  res.status(404).json({
    success: false,
    error: lastError?.message || "Could not resolve signed stream details for this lecture",
  });
});

// Pallycon / Widevine License Proxy
app.all("/api/pallycon-license", express.raw({ type: "*/*", limit: "2mb" }), async (req, res) => {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "*");

  if (req.method === "OPTIONS") {
    return res.status(204).end();
  }

  try {
    const pallyconToken = req.headers["pallycon-customdata-v2"];
    const targetUrl = req.query.url || "https://license-global.pallycon.com/ri/licenseManager.do";
    const licenseRes = await fetch(targetUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/octet-stream",
        "pallycon-customdata-v2": pallyconToken || "",
        "Origin": "https://meded.pw.live",
        "Referer": "https://meded.pw.live/",
      },
      body: req.body,
    });
    res.status(licenseRes.status);
    res.setHeader("Content-Type", "application/octet-stream");
    const buf = await licenseRes.arrayBuffer();
    res.send(Buffer.from(buf));
  } catch (err) {
    console.error("License proxy error:", err);
    res.status(500).json({ error: err.message });
  }
});

// Proxy for AES-128 Encryption Keys
app.get("/api/videos/get-hls-key", async (req, res) => {
  try {
    const { videoKey, key = "enc.key" } = req.query;
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Content-Type", "application/octet-stream");

    const url = `https://meded-api.penpencil.co/v1/videos/get-hls-key?videoKey=${encodeURIComponent(videoKey)}&key=${encodeURIComponent(key)}`;
    const response = await fetchWithAutoRefresh(url, {}, req);
    if (response.ok) {
      const buf = await response.arrayBuffer();
      return res.send(Buffer.from(buf));
    }
    // Fallback to api.penpencil.co
    const fbUrl = `https://api.penpencil.co/v1/videos/get-hls-key?videoKey=${encodeURIComponent(videoKey)}&key=${encodeURIComponent(key)}`;
    const fbRes = await fetchWithAutoRefresh(fbUrl, {}, req);
    if (fbRes.ok) {
      const buf = await fbRes.arrayBuffer();
      return res.send(Buffer.from(buf));
    }
    res.status(response.status).json({ error: "Failed to fetch encryption key" });
  } catch (err) {
    console.error("HLS Key fetch error:", err);
    res.status(500).json({ error: err.message });
  }
});

// Universal Video Proxy (Handles CloudFront WAF bypass, CORS, Range requests)
app.all("/api/video-proxy", async (req, res) => {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "GET, HEAD, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "*");
  res.setHeader("Access-Control-Expose-Headers", "Content-Length, Content-Range, Accept-Ranges");

  if (req.method === "OPTIONS") {
    return res.status(204).end();
  }

  try {
    let rawUrl = req.query.url;
    if (!rawUrl || typeof rawUrl !== "string") {
      return res.status(400).json({ error: "Missing url parameter" });
    }

    // Safeguard: Reconstruct query params if Express parser split them
    const extraParams = new URLSearchParams();
    for (const [key, value] of Object.entries(req.query)) {
      if (key !== "url" && typeof value === "string") {
        if (!rawUrl.includes(key + "=")) {
          extraParams.set(key, value);
        }
      }
    }
    const extraStr = extraParams.toString();
    if (extraStr) {
      rawUrl += (rawUrl.includes("?") ? "&" : "?") + extraStr;
    }

    const parsed = new URL(rawUrl);
    const upstreamHeaders = {
      "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
      "Origin": "https://meded.pw.live",
      "Referer": "https://meded.pw.live/",
      "Accept": "*/*",
    };
    if (req.headers.range) {
      upstreamHeaders["Range"] = req.headers.range;
    }

    const upstream = await fetch(rawUrl, {
      headers: upstreamHeaders,
    });

    const contentType = upstream.headers.get("content-type") || "application/octet-stream";
    const lowerPath = parsed.pathname.toLowerCase();
    const isM3u8 = lowerPath.endsWith(".m3u8") || contentType.includes("mpegurl");
    const isMpd = lowerPath.endsWith(".mpd") || contentType.includes("dash+xml");

    res.status(upstream.status);
    for (const [hName, hVal] of upstream.headers.entries()) {
      const lowerH = hName.toLowerCase();
      if (lowerH === "content-length" || lowerH === "content-range" || lowerH === "accept-ranges") {
        res.setHeader(hName, hVal);
      }
    }

    if (isM3u8 && upstream.status < 300) {
      const text = await upstream.text();
      res.setHeader("Content-Type", "application/vnd.apple.mpegurl");
      const rewritten = rewriteM3u8Manifest(text, rawUrl, parsed.search);
      return res.send(rewritten);
    }

    if (isMpd && upstream.status < 300) {
      const mpdText = await upstream.text();
      res.setHeader("Content-Type", "application/dash+xml");
      const rawNoQuery = rawUrl.split("?")[0];
      const basePath = rawNoQuery.substring(0, rawNoQuery.lastIndexOf("/") + 1);
      const injected = mpdText.includes("<BaseURL>")
        ? mpdText.replace(/<BaseURL>.*?<\/BaseURL>/g, `<BaseURL>${basePath}</BaseURL>`)
        : mpdText.replace(/<Period([^>]*)>/, `<Period$1>\n    <BaseURL>${basePath}</BaseURL>`);
      return res.send(injected);
    }

    res.setHeader("Content-Type", contentType);
    const buffer = await upstream.arrayBuffer();
    res.send(Buffer.from(buffer));
  } catch (err) {
    console.error("Video Proxy Error:", err);
    res.status(500).json({ error: "Failed to proxy video resource: " + err.message });
  }
});

// PDF Proxy with CORS headers
app.get("/api/pdf-proxy", async (req, res) => {
  try {
    const targetUrl = req.query.url;
    if (!targetUrl || typeof targetUrl !== "string") {
      return res.status(400).json({ error: "Missing url parameter" });
    }
    const decoded = decodeURIComponent(targetUrl);
    const pdfRes = await fetch(decoded);
    if (!pdfRes.ok) {
      return res.status(pdfRes.status).send(`Failed to fetch PDF: ${pdfRes.statusText}`);
    }
    res.setHeader("Content-Type", "application/pdf");
    res.setHeader("Content-Disposition", "inline");
    const arrayBuffer = await pdfRes.arrayBuffer();
    res.send(Buffer.from(arrayBuffer));
  } catch (err) {
    console.error("PDF Proxy Error:", err);
    res.status(500).json({ error: "Failed to proxy PDF" });
  }
});

app.listen(PORT, "0.0.0.0", () => {
  console.log(`\x1b[32m[PWMedEd API]\x1b[0m Listening on http://localhost:${PORT}`);
});
