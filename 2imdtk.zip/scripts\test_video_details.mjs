const token = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJkYXRhIjp7Il9pZCI6IjZhYzc4ZTE4MjUxMzhlOTI3ZmM3YmU4NyIsImNvdW50cnlHcm91cCI6IklOIiwib3JnYW5pemF0aW9uIjp7Il9pZCI6IjYzYjUyOTYzZTcyZThiMDAxODZjMTFmMyJ9LCJyb2xlcyI6WyI1YjI3YmQ5NjU4NDJmOTUwYTc3OGM2ZWYiXSwidHlwZSI6IlVTRVIiLCJ1c2VybmFtZSI6IjYzODc0MjY3NzgifSwiZXhwIjoxNzk1NzAxMzQwLjgxOSwiaWF0IjoxNzk1MDk2NTQwLCJqdGkiOiI4aFZfenpvM1JhYVd0aXdTRGEzRkJ3XzZhYzc4ZTE4MjUxMzhlOTI3ZmM3YmU4NyJ9._zGTjQd2p9mqe3XH7UR9gbgyVezXhXuA6SYpMc1IRV0";

async function main() {
  console.log("Token length:", token.length);

  // Let's test multiple combinations
  const candidates = [
    { childId: "6ace27e27f34f9fab31df011", parentId: "6a6de3dc386150cc7a2b4232" },
    { childId: "de9f6d33-1be5-4ed0-a9ad-8913dc037cb0", parentId: "6a6de3dc386150cc7a2b4232" },
    { childId: "6ace27e27f34f9fab31df011" },
    { childId: "de9f6d33-1be5-4ed0-a9ad-8913dc037cb0" },
  ];

  for (const c of candidates) {
    for (const vct of ["DASH", "HLS"]) {
      const p = {
        type: "BATCHES",
        videoContainerType: vct,
        reqType: "query",
        ...c,
      };
      const qs = new URLSearchParams(p).toString();
      const url = `https://meded-api.penpencil.co/v1/videos/video-url-details?${qs}`;
      const res = await fetch(url, {
        headers: {
          authorization: `Bearer ${token}`,
          "client-id": "63b52963e72e8b00186c11f3",
          "client-type": "WEB",
          "organization-id": "63b52963e72e8b00186c11f3",
          referer: "https://meded.pw.live/",
          origin: "https://meded.pw.live",
          "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
        },
      });
      const text = await res.text();
      console.log(`[${res.status}] ${qs} -> ${text}`);
    }
  }
}

main().catch(console.error);
