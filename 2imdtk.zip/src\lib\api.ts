import { BatchItem, BatchDetail, Topic, LectureContent } from "../types/meded";

export async function fetchMyBatches(): Promise<BatchItem[]> {
  const res = await fetch("/api/batches/my-batches");
  const data = await res.json();
  if (data?.success && Array.isArray(data.data)) {
    return data.data.map((item: any) => ({
      _id: item._id,
      name: item.name || item.batchName,
      batchName: item.batchName || item.name,
      byName: item.byName,
      slug: item.slug,
      language: item.language,
      exam: item.exam,
      class: item.class,
      isPurchased: true,
      previewImage: item.previewImage,
      meta: item.meta,
      startDate: item.startDate,
      endDate: item.endDate,
    }));
  }
  return [];
}

export async function fetchCohortBatches(cohortId?: string): Promise<BatchItem[]> {
  const url = cohortId ? `/api/cohort/batches?cohortId=${cohortId}` : "/api/cohort/batches";
  const res = await fetch(url);
  const data = await res.json();
  if (data?.success && Array.isArray(data.data)) {
    return data.data.map((item: any) => {
      const b = item.batchId || item;
      return {
        _id: b._id,
        name: b.name || b.batchName,
        batchName: b.batchName || b.name,
        byName: b.byName,
        slug: b.slug,
        language: b.language,
        exam: b.exam,
        class: b.class,
        isPurchased: b.isPurchased ?? false,
        previewImage: b.previewImage,
        meta: b.meta,
        startDate: b.startDate,
        endDate: b.endDate,
      };
    });
  }
  return [];
}

export async function fetchBatchDetails(batchId: string): Promise<BatchDetail | null> {
  const res = await fetch(`/api/batches/${batchId}/details`);
  const data = await res.json();
  if (data?.success && data.data) {
    return data.data;
  }
  return null;
}

export async function fetchSubjectTopics(batchId: string, subjectId: string): Promise<Topic[]> {
  const res = await fetch(`/api/batches/${batchId}/subject/${subjectId}/topics`);
  const data = await res.json();
  if (data?.success && Array.isArray(data.data)) {
    return data.data;
  }
  return [];
}

export async function fetchSubjectContents(
  batchId: string,
  subjectId: string,
  contentType: "videos" | "notes" | "dppNotes" | "exercises" = "videos",
  tag?: string
): Promise<LectureContent[]> {
  let url = `/api/batches/${batchId}/subject/${subjectId}/contents?contentType=${contentType}`;
  if (tag) {
    url += `&tag=${encodeURIComponent(tag)}`;
  }
  const res = await fetch(url);
  const data = await res.json();
  if (data?.success && Array.isArray(data.data)) {
    return data.data;
  }
  return [];
}

export function getFullImageUrl(img?: { baseUrl?: string; key?: string }): string {
  if (!img || !img.key) return "https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?w=600&auto=format&fit=crop&q=80";
  const base = img.baseUrl || "https://static.pw.live/";
  return `${base.replace(/\/+$/, "")}/${img.key.replace(/^\/+/, "")}`;
}

export interface ResolvedVideo {
  rawUrl: string;
  signedQs: string;
  hlsUrl: string;
  dashUrl: string;
  hasDrm?: boolean;
  token?: string;
  drmDetails?: {
    licenseUrl?: string;
    licenseToken?: string;
    drmType?: string;
    drmVendor?: string;
    contentId?: string;
  };
  videoContainer: "HLS" | "DASH";
  signatureExpireAt?: number;
}

export async function fetchAuthToken(): Promise<string> {
  try {
    const res = await fetch("/api/auth/token");
    const data = await res.json();
    return data?.token || "";
  } catch {
    return "";
  }
}

export async function resolveVideoStream(
  batchId: string,
  childId: string,
  videoId?: string
): Promise<ResolvedVideo | null> {
  try {
    let url = `/api/videos/resolve?batchId=${encodeURIComponent(batchId)}&childId=${encodeURIComponent(childId)}`;
    if (videoId) {
      url += `&videoId=${encodeURIComponent(videoId)}`;
    }
    const res = await fetch(url);
    const data = await res.json();
    if (data?.success && data.data) {
      return data.data;
    }
    return null;
  } catch (err) {
    console.error("resolveVideoStream error:", err);
    return null;
  }
}
