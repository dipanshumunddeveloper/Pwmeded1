import { BDS_MASTER_DATA } from "./bdsMasterData";

export interface Env {
  ASSETS: {
    fetch: (request: Request) => Promise<Response>;
  };
  CLIENT_ID?: string;
  ORGANIZATION_ID?: string;
  COHORT_ID?: string;
  COLLEGE_NAME?: string;
  TARGET_EXAM?: string;
  MEDED_TOKEN?: string;
  REFRESH_TOKEN?: string;
  PWMEDED_AUTH?: {
    get: (key: string) => Promise<string | null>;
    put: (key: string, value: string) => Promise<void>;
  };
}

const CORS_HEADERS: Record<string, string> = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS, HEAD",
  "Access-Control-Allow-Headers": "*",
  "Access-Control-Expose-Headers": "Content-Length, Content-Range, Accept-Ranges",
};

let activeAccessToken = "";
let activeRefreshToken = "";
let refreshPromise: Promise<string> | null = null;

function parseJwtExp(token: string): number {
  try {
    const parts = token.split(".");
    if (parts.length < 2) return 0;
    let b64 = parts[1].replace(/-/g, "+").replace(/_/g, "/");
    while (b64.length % 4 !== 0) {
      b64 += "=";
    }
    const json = JSON.parse(atob(b64));
    return (json.exp || 0) * 1000;
  } catch {
    return 0;
  }
}

async function refreshCloudflareToken(env: Env): Promise<string> {
  if (refreshPromise) return refreshPromise;

  refreshPromise = (async () => {
    try {
      if (env.PWMEDED_AUTH) {
        try {
          const kvRf = await env.PWMEDED_AUTH.get("REFRESH_TOKEN");
          if (kvRf) activeRefreshToken = kvRf.trim();
        } catch {}
      }
      let rf = activeRefreshToken || env.REFRESH_TOKEN || "";

      if (!rf) {
        throw new Error("No refresh_token found in KV or environment");
      }

      const body = {
        client_id: "system-admin",
        client_secret: "KjPXuAVfC5xbmgreETNMaL7z",
        refresh_token: rf,
      };

      const res = await fetch("https://meded-api.penpencil.co/v3/oauth/refresh-token", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "client-id": env.CLIENT_ID || "63b52963e72e8b00186c11f3",
          "client-type": "WEB",
          "Origin": "https://meded.pw.live",
          "Referer": "https://meded.pw.live/",
          "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
        },
        body: JSON.stringify(body),
      });

      if (!res.ok) {
        throw new Error(`Refresh token failed: ${res.status}`);
      }

      const json: any = await res.json();
      if (json?.data?.access_token) {
        activeAccessToken = json.data.access_token;
        if (json.data.refresh_token) {
          activeRefreshToken = json.data.refresh_token;
        }

        // Persist to Cloudflare KV for permanent storage
        if (env.PWMEDED_AUTH) {
          try {
            await env.PWMEDED_AUTH.put("MEDED_TOKEN", activeAccessToken);
            if (activeRefreshToken) {
              await env.PWMEDED_AUTH.put("REFRESH_TOKEN", activeRefreshToken);
            }
          } catch (kvErr) {
            console.error("Failed to persist token to KV:", kvErr);
          }
        }

        return activeAccessToken;
      }
      throw new Error("No access_token returned");
    } finally {
      refreshPromise = null;
    }
  })();

  return refreshPromise;
}

async function getValidToken(request: Request, env: Env, forceReload = false): Promise<string> {
  const reqAuth = request.headers.get("authorization");
  if (reqAuth && reqAuth.startsWith("Bearer ")) {
    return reqAuth.replace("Bearer ", "").trim();
  }

  // 1. Always load from KV if not cached or forceReload
  if (forceReload || !activeAccessToken) {
    if (env.PWMEDED_AUTH) {
      try {
        const kvToken = await env.PWMEDED_AUTH.get("MEDED_TOKEN");
        const kvRefresh = await env.PWMEDED_AUTH.get("REFRESH_TOKEN");
        if (kvToken) activeAccessToken = kvToken.trim();
        if (kvRefresh) activeRefreshToken = kvRefresh.trim();
      } catch (err) {
        console.error("KV read error:", err);
      }
    }
  }

  if (!activeAccessToken && env.MEDED_TOKEN) {
    activeAccessToken = env.MEDED_TOKEN;
  }
  if (!activeRefreshToken && env.REFRESH_TOKEN) {
    activeRefreshToken = env.REFRESH_TOKEN;
  }

  const exp = parseJwtExp(activeAccessToken);
  const now = Date.now();
  // Automatically generate fresh token if expiring within 30 minutes
  if (!activeAccessToken || !exp || now > exp - 30 * 60 * 1000) {
    try {
      return await refreshCloudflareToken(env);
    } catch {
      return activeAccessToken;
    }
  }
  return activeAccessToken;
}

function getMedEdHeaders(token: string, env: Env): HeadersInit {
  return {
    "authorization": token ? `Bearer ${token}` : "",
    "client-id": env.CLIENT_ID || "63b52963e72e8b00186c11f3",
    "client-type": "WEB",
    "organization-id": env.ORGANIZATION_ID || "63b52963e72e8b00186c11f3",
    "referer": "https://meded.pw.live/",
    "origin": "https://meded.pw.live",
    "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    "accept": "application/json, text/plain, */*",
  };
}

async function fetchWithAutoRefresh(url: string, options: RequestInit = {}, request: Request, env: Env): Promise<Response> {
  let token = await getValidToken(request, env);
  let defaultHeaders = getMedEdHeaders(token, env);
  let res = await fetch(url, { ...options, headers: { ...defaultHeaders, ...(options.headers as any) } });

  // If 401 or 400 with auth error, try refreshing token and retrying
  if (res.status === 401 || res.status === 400) {
    const clone = res.clone();
    const text = await clone.text().catch(() => "");
    if (res.status === 401 || text.includes("Could not get user details") || text.includes("Unauthorised")) {
      try {
        // Try reloading from KV first (in case another isolate refreshed it)
        token = await getValidToken(request, env, true);
        let retryHeaders = getMedEdHeaders(token, env);
        res = await fetch(url, { ...options, headers: { ...retryHeaders, ...(options.headers as any) } });

        // If still unauthorized, roll the token
        const retryClone = res.clone();
        const retryText = await retryClone.text().catch(() => "");
        if (res.status === 401 || retryText.includes("Could not get user details") || retryText.includes("Unauthorised")) {
          const newToken = await refreshCloudflareToken(env);
          retryHeaders = getMedEdHeaders(newToken, env);
          res = await fetch(url, { ...options, headers: { ...retryHeaders, ...(options.headers as any) } });
        }
      } catch (err) {
        console.error("Auto refresh on error failed:", err);
      }
    }
  }
  return res;
}

function jsonResponse(data: unknown, status = 200, headers: Record<string, string> = {}) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      "Content-Type": "application/json",
      ...CORS_HEADERS,
      ...headers,
    },
  });
}

// ===== BDS MASTER DATA FALLBACK =====
// Map batch IDs that should use BDS fallback data
const BDS_BATCH_IDS = new Set([
  "6a6de3dc386150cc7a2b4232", // PRARAMBH BDS 1st Year 2026
  "69fb0a5d1be0ea07d5da3d22", // BDS Notes Batch
]);

function findBdsSubjectByName(subjectName: string) {
  const normalizedQuery = subjectName.toLowerCase().trim();
  return BDS_MASTER_DATA.subjects.find((s) => {
    const name = s.subjectName.toLowerCase().trim();
    return name === normalizedQuery || name.includes(normalizedQuery) || normalizedQuery.includes(name);
  });
}

function bdsClassToLectureContent(c: typeof BDS_MASTER_DATA.subjects[number]["classes"][number]) {
  return {
    _id: c.id,
    topic: c.topic,
    date: c.date,
    duration: c.duration,
    url: c.videoUrl,
    urlType: "penpencilvdo",
    status: "COMPLETED",
    lectureType: "VIDEO",
    childId: c.id,
    videoId: c.id,
    videoDetails: {
      _id: c.id,
      id: c.id,
      name: c.videoName,
      image: c.thumbnail,
      videoUrl: c.videoUrl,
      duration: c.duration,
      drmProtected: true,
    },
    homeworkIds: [],
  };
}

function serveBdsFallback(batchId: string, subjectId: string, subjectNameHint: string, tagFilter?: string) {
  // Try to match subject by ID first, then by name
  let bdsSub = BDS_MASTER_DATA.subjects.find((s) => s.subjectId === subjectId);
  if (!bdsSub && subjectNameHint) {
    bdsSub = findBdsSubjectByName(subjectNameHint);
  }
  if (!bdsSub) {
    // Try all subjects, see if any class has the subjectId
    return null;
  }

  let classes = bdsSub.classes;

  // If a tag filter is provided, match against the class tags
  if (tagFilter) {
    const tagLower = tagFilter.toLowerCase().trim();
    const filtered = classes.filter((c) =>
      c.tags.some((t) => {
        const tLower = t.toLowerCase().trim();
        return tLower === tagLower || tLower.includes(tagLower) || tagLower.includes(tLower);
      })
    );
    if (filtered.length > 0) {
      classes = filtered;
    }
    // If no match by tag content, try matching tag as a topic name ID (PW uses topic._id as tag param)
    // In that case, return all classes for the subject
  }

  return classes.map(bdsClassToLectureContent);
}

function rewriteM3u8Manifest(manifestText: string, baseUrl: string, queryParams: string): string {
  const baseHref = baseUrl.substring(0, baseUrl.lastIndexOf("/") + 1);
  return manifestText
    .split(/\r?\n/)
    .map((line) => {
      const trimmed = line.trim();
      if (!trimmed) return line;
      if (trimmed.startsWith("#")) {
        return line.replace(/URI="([^"]+)"/g, (_m, uri) => {
          try {
            if (uri.includes("get-hls-key")) {
              const u = new URL(uri);
              const vk = u.searchParams.get("videoKey");
              if (vk) {
                return `URI="/api/videos/get-hls-key?videoKey=${encodeURIComponent(vk)}&key=enc.key"`;
              }
            }
            let fullUri = uri.startsWith("http") ? uri : new URL(uri, baseHref).href;
            if (queryParams && !fullUri.includes("?")) {
              fullUri += queryParams;
            }
            return `URI="${fullUri}"`;
          } catch {
            return `URI="${uri}"`;
          }
        });
      }
      try {
        let segUrl = trimmed.startsWith("http") ? trimmed : new URL(trimmed, baseHref).href;
        if (queryParams && !segUrl.includes("?")) {
          segUrl += queryParams;
        }
        return `/api/video-proxy?url=${encodeURIComponent(segUrl)}`;
      } catch {
        return line;
      }
    })
    .join("\n");
}

export default {
  async fetch(request: Request, env: Env): Promise<Response> {
    const url = new URL(request.url);

    // OPTIONS preflight
    if (request.method === "OPTIONS") {
      return new Response(null, {
        status: 204,
        headers: CORS_HEADERS,
      });
    }

    // Pass through non-API requests to static assets
    if (!url.pathname.startsWith("/api/")) {
      return await env.ASSETS.fetch(request);
    }

    try {
      // 1. Health check
      if (url.pathname === "/api/health") {
        return jsonResponse({
          status: "ok",
          service: "pwmeded-cloudflare-worker",
          hasToken: Boolean(activeAccessToken || env.MEDED_TOKEN),
          cohortId: env.COHORT_ID || "69fb317edb2ceff4293c1189",
        });
      }

      // 1b. Autonomous Auth Status & Auto-Refresh
      if (url.pathname === "/api/auth/status") {
        const token = await getValidToken(request, env);
        const exp = parseJwtExp(token);
        return jsonResponse({
          success: true,
          authenticated: Boolean(token),
          expiresAt: exp ? new Date(exp).toISOString() : null,
          expiresInDays: exp ? Math.round(((exp - Date.now()) / (1000 * 60 * 60 * 24)) * 10) / 10 : 0,
          storage: env.PWMEDED_AUTH ? "Cloudflare Global KV (Persistent)" : "Memory/Env",
          autonomousRefresh: true,
        });
      }

      if (url.pathname === "/api/auth/token") {
        const token = await getValidToken(request, env);
        return jsonResponse({
          success: true,
          token: token || "",
        });
      }

      if (url.pathname === "/api/auth/refresh") {
        try {
          const newToken = await refreshCloudflareToken(env);
          const exp = parseJwtExp(newToken);
          return jsonResponse({
            success: true,
            message: "Token refreshed successfully from rolling refresh token",
            expiresAt: exp ? new Date(exp).toISOString() : null,
          });
        } catch (err: any) {
          return jsonResponse({ success: false, error: err.message }, 500);
        }
      }

      // ==========================================
      // ADMIN PANEL CONTROL ROUTES
      // Password: mundmund (stored as SHA-256 hash)
      // ==========================================
      const ADMIN_PASSWORD_HASH = "8d85134adc779b5e8d08d6c9dc0cf75aac0abcccc3598d3d0fc295606ff5d6cc";

      const checkAdminAuth = (req: Request) => {
        const hash = req.headers.get("X-Admin-Hash") || "";
        return hash === ADMIN_PASSWORD_HASH;
      };

      // Admin Login Verification
      if (url.pathname === "/api/admin/verify" && request.method === "POST") {
        const body: any = await request.json().catch(() => ({}));
        if (body.passHash === ADMIN_PASSWORD_HASH) {
          return jsonResponse({ ok: true, message: "Admin access granted" });
        }
        return jsonResponse({ ok: false, error: "Invalid master key" }, 401);
      }

      // Admin Status
      if (url.pathname === "/api/admin/status") {
        if (!checkAdminAuth(request)) {
          return jsonResponse({ error: "Unauthorized" }, 401);
        }
        const token = await getValidToken(request, env);
        const exp = parseJwtExp(token);
        return jsonResponse({
          success: true,
          authenticated: Boolean(token),
          expiresAt: exp ? new Date(exp).toISOString() : null,
          expiresInDays: exp ? Math.round(((exp - Date.now()) / (1000 * 60 * 60 * 24)) * 10) / 10 : 0,
          storage: env.PWMEDED_AUTH ? "Cloudflare Global KV (Persistent)" : "Environment",
        });
      }

      // Admin: Send OTP to Mobile
      if (url.pathname === "/api/admin/send-otp" && request.method === "POST") {
        if (!checkAdminAuth(request)) {
          return jsonResponse({ error: "Unauthorized" }, 401);
        }
        const body: any = await request.json().catch(() => ({}));
        const mobile = body.mobile ? String(body.mobile).trim() : "";
        if (!mobile || mobile.length !== 10) {
          return jsonResponse({ success: false, error: "Valid 10-digit mobile number required" }, 400);
        }

        const otpRes = await fetch("https://meded-api.penpencil.co/v1/users/get-otp?smsType=0", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "client-id": env.CLIENT_ID || "63b52963e72e8b00186c11f3",
            "client-type": "WEB",
            "Origin": "https://meded.pw.live",
            "Referer": "https://meded.pw.live/",
            "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
          },
          body: JSON.stringify({
            username: mobile,
            countryCode: "+91",
            organizationId: env.ORGANIZATION_ID || "63b52963e72e8b00186c11f3",
          }),
        });

        const otpJson: any = await otpRes.json().catch(() => ({}));
        return jsonResponse(otpJson, otpRes.status);
      }

      // Admin: Verify OTP & Generate Fresh Tokens
      if (url.pathname === "/api/admin/verify-otp" && request.method === "POST") {
        if (!checkAdminAuth(request)) {
          return jsonResponse({ error: "Unauthorized" }, 401);
        }
        const body: any = await request.json().catch(() => ({}));
        const mobile = body.mobile ? String(body.mobile).trim() : "";
        const otp = body.otp ? String(body.otp).trim() : "";

        if (!mobile || !otp) {
          return jsonResponse({ success: false, error: "Mobile number and OTP required" }, 400);
        }

        const tokenRes = await fetch("https://meded-api.penpencil.co/v3/oauth/token", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "client-id": env.CLIENT_ID || "63b52963e72e8b00186c11f3",
            "client-type": "WEB",
            "Origin": "https://meded.pw.live",
            "Referer": "https://meded.pw.live/",
            "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
          },
          body: JSON.stringify({
            client_id: "system-admin",
            client_secret: "KjPXuAVfC5xbmgreETNMaL7z",
            grant_type: "password",
            ttl: 604800000,
            latitude: 0,
            longitude: 0,
            organizationId: env.ORGANIZATION_ID || "63b52963e72e8b00186c11f3",
            username: mobile,
            otp: otp,
          }),
        });

        const tokenJson: any = await tokenRes.json().catch(() => ({}));
        if (tokenJson?.data?.access_token) {
          activeAccessToken = tokenJson.data.access_token;
          if (tokenJson.data.refresh_token) {
            activeRefreshToken = tokenJson.data.refresh_token;
          }

          // Persist directly to Cloudflare KV database
          if (env.PWMEDED_AUTH) {
            try {
              await env.PWMEDED_AUTH.put("MEDED_TOKEN", activeAccessToken);
              if (activeRefreshToken) {
                await env.PWMEDED_AUTH.put("REFRESH_TOKEN", activeRefreshToken);
              }
            } catch (kvErr) {
              console.error("KV save error:", kvErr);
            }
          }

          return jsonResponse({
            success: true,
            message: "New tokens generated and saved to Cloudflare KV!",
            user: tokenJson.data.user,
          });
        }

        return jsonResponse(tokenJson, tokenRes.status);
      }

      // Admin: Manual Token Save
      if (url.pathname === "/api/admin/save-token" && request.method === "POST") {
        if (!checkAdminAuth(request)) {
          return jsonResponse({ error: "Unauthorized" }, 401);
        }
        const body: any = await request.json().catch(() => ({}));
        if (!body.token) {
          return jsonResponse({ success: false, error: "Token is required" }, 400);
        }

        activeAccessToken = body.token.trim();
        if (body.refreshToken) {
          activeRefreshToken = body.refreshToken.trim();
        }

        if (env.PWMEDED_AUTH) {
          await env.PWMEDED_AUTH.put("MEDED_TOKEN", activeAccessToken);
          if (activeRefreshToken) {
            await env.PWMEDED_AUTH.put("REFRESH_TOKEN", activeRefreshToken);
          }
        }

        return jsonResponse({ success: true, message: "Tokens saved to Cloudflare KV" });
      }

      // 2. User profile
      if (url.pathname === "/api/me") {
        return jsonResponse({
          success: true,
          data: {
            name: "Medical Scholar",
            college: env.COLLEGE_NAME || "Post Graduate Institute Of Dental Sciences, Rohtak",
            targetExam: env.TARGET_EXAM || "BDS 1st Year 2026",
            cohortId: env.COHORT_ID || "69fb317edb2ceff4293c1189",
            clientId: env.CLIENT_ID || "63b52963e72e8b00186c11f3",
          },
        });
      }

      // 3. My Batches / All Batches
      if (url.pathname === "/api/batches/my-batches" || url.pathname === "/api/batches/all") {
        const page = url.searchParams.get("page") || "1";
        const limit = url.searchParams.get("limit") || "100";
        const mode = url.searchParams.get("mode");
        let upstreamUrl = `https://meded-api.penpencil.co/v3/batches/my-batches?page=${page}&limit=${limit}`;
        if (mode) {
          upstreamUrl += `&mode=${mode}`;
        }
        const res = await fetchWithAutoRefresh(upstreamUrl, {}, request, env);
        const data = await res.json();
        return jsonResponse(data, res.status);
      }

      // 4. Cohort Batches
      if (url.pathname === "/api/cohort/batches") {
        const page = url.searchParams.get("page") || "1";
        const limit = url.searchParams.get("limit") || "100";
        const examYear = url.searchParams.get("examYear") || "1";
        const cohort = url.searchParams.get("cohortId") || env.COHORT_ID || "69fb317edb2ceff4293c1189";
        const upstreamUrl = `https://meded-api.penpencil.co/v1/cohort/${cohort}/batches?page=${page}&limit=${limit}&examYear=${examYear}&isSubscribed=true`;
        const res = await fetchWithAutoRefresh(upstreamUrl, {}, request, env);
        const data = await res.json();
        return jsonResponse(data, res.status);
      }

      // 5. Batch Details: /api/batches/:batchId/details
      const batchDetailsMatch = url.pathname.match(/^\/api\/batches\/([^/]+)\/details$/);
      if (batchDetailsMatch) {
        const batchId = batchDetailsMatch[1];
        const upstreamUrl = `https://meded-api.penpencil.co/v3/batches/${batchId}/details`;
        const res = await fetchWithAutoRefresh(upstreamUrl, {}, request, env);
        const data = await res.json();
        return jsonResponse(data, res.status);
      }

      // 6. Batch Subject Topics: /api/batches/:batchId/subject/:subjectId/topics
      const topicsMatch = url.pathname.match(/^\/api\/batches\/([^/]+)\/subject\/([^/]+)\/topics$/);
      if (topicsMatch) {
        const [, batchId, subjectId] = topicsMatch;
        const page = url.searchParams.get("page") || "1";
        // PenPencil MedEd topics are served on v1 (fallback to v2)
        let upstreamUrl = `https://meded-api.penpencil.co/v1/batches/${batchId}/subject/${subjectId}/topics?page=${page}`;
        let res = await fetchWithAutoRefresh(upstreamUrl, {}, request, env);
        if (!res.ok) {
          upstreamUrl = `https://meded-api.penpencil.co/v2/batches/${batchId}/subject/${subjectId}/topics?page=${page}`;
          res = await fetchWithAutoRefresh(upstreamUrl, {}, request, env);
        }
        const data = await res.json();
        return jsonResponse(data, res.status);
      }

      // 7. Batch Subject Contents: /api/batches/:batchId/subject/:subjectId/contents
      const contentsMatch = url.pathname.match(/^\/api\/batches\/([^/]+)\/subject\/([^/]+)\/contents$/);
      if (contentsMatch) {
        const [, batchId, subjectId] = contentsMatch;
        const page = url.searchParams.get("page") || "1";
        const contentType = url.searchParams.get("contentType") || "videos";
        const tag = url.searchParams.get("tag") || "";

        // Try upstream first
        let upstreamUrl = `https://meded-api.penpencil.co/v2/batches/${batchId}/subject/${subjectId}/contents?page=${page}&contentType=${contentType}`;
        if (tag) {
          upstreamUrl += `&tag=${encodeURIComponent(tag)}`;
        }

        let upstreamData: any = null;
        let upstreamOk = false;
        try {
          const res = await fetchWithAutoRefresh(upstreamUrl, {}, request, env);
          upstreamData = await res.json();
          // Check if upstream returned valid data with actual content
          if (
            upstreamData?.success &&
            Array.isArray(upstreamData.data) &&
            upstreamData.data.length > 0
          ) {
            upstreamOk = true;
          }
        } catch {
          // upstream failed, will fall through to BDS fallback
        }

        if (upstreamOk) {
          return jsonResponse(upstreamData);
        }

        // ===== BDS FALLBACK =====
        // If upstream returned 401/empty and this is a BDS batch, serve from master data
        if (contentType === "videos" || contentType === "all") {
          // We need the subject name to match against BDS data
          // First check if it's a known BDS batch
          const isBdsBatch = BDS_BATCH_IDS.has(batchId);

          if (isBdsBatch || true) {
            // Try fallback for any batch that upstream failed
            // Get subject name from batch details to match
            let subjectNameHint = "";
            try {
              const detailsUrl = `https://meded-api.penpencil.co/v3/batches/${batchId}/details`;
              const detailsRes = await fetchWithAutoRefresh(detailsUrl, {}, request, env);
              const detailsJson: any = await detailsRes.json();
              if (detailsJson?.data?.subjects) {
                const matchedSub = detailsJson.data.subjects.find(
                  (s: any) => s._id === subjectId
                );
                if (matchedSub) {
                  subjectNameHint = matchedSub.subject || "";
                }
              }
            } catch {}

            // Also try to resolve tag name from topic name
            let tagNameHint = tag;
            if (tag && !tagNameHint.match(/[a-zA-Z]/)) {
              // tag looks like an ObjectId, try to resolve the topic name
              try {
                const topicsUrl = `https://meded-api.penpencil.co/v1/batches/${batchId}/subject/${subjectId}/topics?page=1`;
                const topicsRes = await fetchWithAutoRefresh(topicsUrl, {}, request, env);
                const topicsJson: any = await topicsRes.json();
                if (topicsJson?.data && Array.isArray(topicsJson.data)) {
                  const matchedTopic = topicsJson.data.find((t: any) => t._id === tag);
                  if (matchedTopic) {
                    tagNameHint = matchedTopic.name || tag;
                  }
                }
              } catch {}
            }

            const fallbackData = serveBdsFallback(batchId, subjectId, subjectNameHint, tagNameHint || undefined);
            if (fallbackData && fallbackData.length > 0) {
              return jsonResponse({
                success: true,
                data: fallbackData,
                source: "bds-master-fallback",
                totalItems: fallbackData.length,
              });
            }
          }
        }

        // Return upstream data even if empty (original behavior)
        return jsonResponse(upstreamData || { success: true, data: [] });
      }

      // 8. DPP Tests
      if (url.pathname === "/api/tests/dpp") {
        const batchId = url.searchParams.get("batchId") || "";
        const batchSubjectId = url.searchParams.get("batchSubjectId") || "";
        const chapterId = url.searchParams.get("chapterId");
        const page = url.searchParams.get("page") || "1";
        const limit = url.searchParams.get("limit") || "20";
        let upstreamUrl = `https://meded-api.penpencil.co/v3/test-service/tests/dpp?batchId=${batchId}&batchSubjectId=${batchSubjectId}&page=${page}&limit=${limit}`;
        if (chapterId) {
          upstreamUrl += `&chapterId=${encodeURIComponent(chapterId)}`;
        }
        const res = await fetchWithAutoRefresh(upstreamUrl, {}, request, env);
        const data = await res.json();
        return jsonResponse(data, res.status);
      }

      // 9. Video Resolver
      if (url.pathname === "/api/videos/resolve") {
        const batchId = url.searchParams.get("batchId");
        const childId = url.searchParams.get("childId");
        const videoId = url.searchParams.get("videoId");
        const queryVideoUrl = url.searchParams.get("videoUrl") || "";

        if (!batchId || (!childId && !videoId)) {
          return jsonResponse({ success: false, error: "batchId and childId (or videoId) required" }, 400);
        }

        const idsToTry = [childId, videoId].filter(Boolean) as string[];
        let lastError: any = null;
        const activeToken = await getValidToken(request, env);

        // Find candidate videoUrl from BDS master data if available
        let bdsMatch: any = null;
        for (const sub of BDS_MASTER_DATA.subjects) {
          const found = sub.classes.find((c) => idsToTry.includes(c.id));
          if (found) {
            bdsMatch = found;
            break;
          }
        }
        const effectiveVideoUrl = queryVideoUrl || bdsMatch?.videoUrl || "";

        for (const id of idsToTry) {
          try {
            // First attempt with DASH for Widevine DRM
            const qsDash = new URLSearchParams({
              type: "BATCHES",
              videoContainerType: "DASH",
              reqType: "query",
              childId: id,
              parentId: batchId,
              clientVersion: "201",
            });
            if (effectiveVideoUrl) {
              qsDash.set("videoUrl", effectiveVideoUrl);
            }

            const endpoints = [
              `https://meded-api.penpencil.co/v1/videos/video-url-details?${qsDash.toString()}`,
              `https://api.penpencil.co/v1/videos/video-url-details?${qsDash.toString()}`,
            ];

            for (const dashUrl of endpoints) {
              const dashResp = await fetchWithAutoRefresh(dashUrl, {}, request, env);
              if (dashResp.ok) {
                const json: any = await dashResp.json();
                if (json?.data?.url && json?.data?.signedUrl) {
                  const rawUrl = json.data.url;
                  const signedQs = json.data.signedUrl;
                  const hlsCandidate = rawUrl.replace(/\/master\.mpd$/i, "/master.m3u8") + signedQs;
                  const dashCandidate = rawUrl + signedQs;
                  const hasDrm = Boolean(json.data.drmDetails?.licenseToken);

                  return jsonResponse({
                    success: true,
                    data: {
                      rawUrl,
                      signedQs,
                      hlsUrl: hlsCandidate,
                      dashUrl: dashCandidate,
                      hasDrm,
                      token: activeToken,
                      drmDetails: json.data.drmDetails || null,
                      videoContainer: hasDrm ? "DASH" : "HLS",
                      signatureExpireAt: json.data.signatureExpireAt,
                    },
                  });
                }
              }
            }

            // Fallback attempt with HLS
            const qsHls = new URLSearchParams({
              type: "BATCHES",
              videoContainerType: "HLS",
              reqType: "query",
              childId: id,
              parentId: batchId,
              clientVersion: "201",
            });
            if (effectiveVideoUrl) {
              qsHls.set("videoUrl", effectiveVideoUrl);
            }

            const hlsEndpoints = [
              `https://meded-api.penpencil.co/v1/videos/video-url-details?${qsHls.toString()}`,
              `https://api.penpencil.co/v1/videos/video-url-details?${qsHls.toString()}`,
            ];

            for (const hlsFetchUrl of hlsEndpoints) {
              const hlsResp = await fetchWithAutoRefresh(hlsFetchUrl, {}, request, env);
              if (hlsResp.ok) {
                const json: any = await hlsResp.json();
                if (json?.data?.url && json?.data?.signedUrl) {
                  const rawUrl = json.data.url;
                  const signedQs = json.data.signedUrl;
                  const hlsCandidate = rawUrl.replace(/\/master\.mpd$/i, "/master.m3u8") + signedQs;
                  const dashCandidate = rawUrl + signedQs;
                  const hasDrm = Boolean(json.data.drmDetails?.licenseToken);

                  return jsonResponse({
                    success: true,
                    data: {
                      rawUrl,
                      signedQs,
                      hlsUrl: hlsCandidate,
                      dashUrl: dashCandidate,
                      hasDrm,
                      token: activeToken,
                      drmDetails: json.data.drmDetails || null,
                      videoContainer: "HLS",
                      signatureExpireAt: json.data.signatureExpireAt,
                    },
                  });
                }
              }
            }
          } catch (err) {
            lastError = err;
          }
        }

        // Check BDS fallback for video details
        if (bdsMatch && bdsMatch.videoUrl) {
          const rawUrl = bdsMatch.videoUrl;
          const hlsCandidate = rawUrl.replace(/\/master\.mpd$/i, "/master.m3u8");
          return jsonResponse({
            success: true,
            data: {
              rawUrl,
              signedQs: "",
              hlsUrl: hlsCandidate,
              dashUrl: rawUrl,
              hasDrm: true,
              token: activeToken,
              drmDetails: {
                licenseUrl: "/api/pallycon-license",
                drmVendor: "Pallycon",
              },
              videoContainer: "DASH",
              signatureExpireAt: Date.now() + 86400000,
              source: "bds-master-fallback",
              topic: bdsMatch.topic,
              videoName: bdsMatch.videoName,
            },
          });
        }

        return jsonResponse(
          { success: false, error: lastError?.message || "Could not resolve signed stream details" },
          404
        );
      }

      // 10. Pallycon / Widevine License Proxy
      if (url.pathname === "/api/pallycon-license") {
        const pallyconToken = request.headers.get("pallycon-customdata-v2");
        const targetUrl = url.searchParams.get("url") || "https://license-global.pallycon.com/ri/licenseManager.do";
        const bodyBuf = await request.arrayBuffer();

        const licenseRes = await fetch(targetUrl, {
          method: "POST",
          headers: {
            "Content-Type": "application/octet-stream",
            "pallycon-customdata-v2": pallyconToken || "",
            "Origin": "https://meded.pw.live",
            "Referer": "https://meded.pw.live/",
          },
          body: bodyBuf,
        });

        const respBuf = await licenseRes.arrayBuffer();
        return new Response(respBuf, {
          status: licenseRes.status,
          headers: {
            "Content-Type": "application/octet-stream",
            ...CORS_HEADERS,
          },
        });
      }

      // 11. HLS AES-128 Key Proxy
      if (url.pathname === "/api/videos/get-hls-key") {
        const videoKey = url.searchParams.get("videoKey") || "";
        const key = url.searchParams.get("key") || "enc.key";

        const primaryUrl = `https://meded-api.penpencil.co/v1/videos/get-hls-key?videoKey=${encodeURIComponent(videoKey)}&key=${encodeURIComponent(key)}`;
        let response = await fetchWithAutoRefresh(primaryUrl, {}, request, env);
        if (!response.ok) {
          const fallbackUrl = `https://api.penpencil.co/v1/videos/get-hls-key?videoKey=${encodeURIComponent(videoKey)}&key=${encodeURIComponent(key)}`;
          response = await fetchWithAutoRefresh(fallbackUrl, {}, request, env);
        }

        if (response.ok) {
          const buf = await response.arrayBuffer();
          return new Response(buf, {
            status: 200,
            headers: {
              "Content-Type": "application/octet-stream",
              ...CORS_HEADERS,
            },
          });
        }
        return jsonResponse({ error: "Failed to fetch encryption key" }, response.status);
      }

      // 12. Universal Video Proxy
      if (url.pathname === "/api/video-proxy") {
        let rawUrl = url.searchParams.get("url");
        if (!rawUrl) {
          return jsonResponse({ error: "Missing url parameter" }, 400);
        }

        // Reconstruct remaining query params
        const extraParams = new URLSearchParams();
        for (const [key, val] of url.searchParams.entries()) {
          if (key !== "url" && !rawUrl.includes(key + "=")) {
            extraParams.set(key, val);
          }
        }
        const extraStr = extraParams.toString();
        if (extraStr) {
          rawUrl += (rawUrl.includes("?") ? "&" : "?") + extraStr;
        }

        const parsed = new URL(rawUrl);
        const upstreamHeaders: Record<string, string> = {
          "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
          "Origin": "https://meded.pw.live",
          "Referer": "https://meded.pw.live/",
          "Accept": "*/*",
        };
        const range = request.headers.get("range");
        if (range) {
          upstreamHeaders["Range"] = range;
        }

        const upstream = await fetch(rawUrl, { headers: upstreamHeaders });
        const contentType = upstream.headers.get("content-type") || "application/octet-stream";
        const lowerPath = parsed.pathname.toLowerCase();
        const isM3u8 = lowerPath.endsWith(".m3u8") || contentType.includes("mpegurl");
        const isMpd = lowerPath.endsWith(".mpd") || contentType.includes("dash+xml");

        const responseHeaders: Record<string, string> = {
          ...CORS_HEADERS,
        };

        for (const [hName, hVal] of upstream.headers.entries()) {
          const lowerH = hName.toLowerCase();
          if (lowerH === "content-length" || lowerH === "content-range" || lowerH === "accept-ranges") {
            responseHeaders[hName] = hVal;
          }
        }

        if (isM3u8 && upstream.status < 300) {
          const text = await upstream.text();
          responseHeaders["Content-Type"] = "application/vnd.apple.mpegurl";
          const rewritten = rewriteM3u8Manifest(text, rawUrl, parsed.search);
          return new Response(rewritten, {
            status: upstream.status,
            headers: responseHeaders,
          });
        }

        if (isMpd && upstream.status < 300) {
          const mpdText = await upstream.text();
          responseHeaders["Content-Type"] = "application/dash+xml";
          const rawNoQuery = rawUrl.split("?")[0];
          const basePath = rawNoQuery.substring(0, rawNoQuery.lastIndexOf("/") + 1);
          const injected = mpdText.includes("<BaseURL>")
            ? mpdText.replace(/<BaseURL>.*?<\/BaseURL>/g, `<BaseURL>${basePath}</BaseURL>`)
            : mpdText.replace(/<Period([^>]*)>/, `<Period$1>\n    <BaseURL>${basePath}</BaseURL>`);
          return new Response(injected, {
            status: upstream.status,
            headers: responseHeaders,
          });
        }

        responseHeaders["Content-Type"] = contentType;
        return new Response(upstream.body, {
          status: upstream.status,
          headers: responseHeaders,
        });
      }

      // 13. PDF Proxy
      if (url.pathname === "/api/pdf-proxy") {
        const targetUrl = url.searchParams.get("url");
        if (!targetUrl) {
          return jsonResponse({ error: "Missing url parameter" }, 400);
        }
        const decoded = decodeURIComponent(targetUrl);
        const pdfRes = await fetch(decoded);
        if (!pdfRes.ok) {
          return new Response(`Failed to fetch PDF: ${pdfRes.statusText}`, { status: pdfRes.status });
        }
        return new Response(pdfRes.body, {
          status: 200,
          headers: {
            "Content-Type": "application/pdf",
            "Content-Disposition": "inline",
            ...CORS_HEADERS,
          },
        });
      }

      return jsonResponse({ error: "Endpoint not found" }, 404);
    } catch (err: any) {
      return jsonResponse({ error: err?.message || "Internal Worker error" }, 500);
    }
  },

  // Cloudflare Autonomous Cron Trigger (Fires every 12 hours)
  async scheduled(event: any, env: Env, ctx: any): Promise<void> {
    ctx.waitUntil((async () => {
      try {
        console.log("Running autonomous scheduled token refresh check...");
        await refreshCloudflareToken(env);
        console.log("Autonomous scheduled token refresh succeeded.");
      } catch (err) {
        console.error("Autonomous scheduled token refresh failed:", err);
      }
    })());
  },
};
