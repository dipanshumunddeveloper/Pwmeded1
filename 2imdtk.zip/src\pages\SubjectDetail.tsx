import React, { useState, useEffect } from "react";
import { Link, useRoute } from "wouter";
import {
  fetchBatchDetails,
  fetchSubjectTopics,
  fetchSubjectContents,
  getFullImageUrl,
} from "../lib/api";
import { BatchDetail, Subject, Topic, LectureContent } from "../types/meded";
import { PdfModal } from "../components/PdfModal";
import {
  ChevronLeft,
  ChevronRight,
  BookOpen,
  Video,
  FileText,
  Calendar,
  Clock,
  Download,
  Eye,
  Play,
  Layers,
  Sparkles,
  ArrowRight,
  Search,
  Filter,
} from "lucide-react";

export function SubjectDetail() {
  const [, params] = useRoute("/batch/:batchId/subject/:subjectId");
  const batchId = params?.batchId || "";
  const subjectId = params?.subjectId || "";

  const [batch, setBatch] = useState<BatchDetail | null>(null);
  const [subject, setSubject] = useState<Subject | null>(null);
  const [topics, setTopics] = useState<Topic[]>([]);
  const [allLectures, setAllLectures] = useState<LectureContent[]>([]);
  const [allNotes, setAllNotes] = useState<LectureContent[]>([]);
  const [activeView, setActiveView] = useState<"chapters" | "all-lectures" | "all-notes">("chapters");
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");

  // PDF Preview Modal
  const [modalPdf, setModalPdf] = useState<{ url: string; title: string } | null>(null);

  useEffect(() => {
    if (!batchId || !subjectId) return;
    setLoading(true);

    fetchBatchDetails(batchId).then((b) => {
      if (b) {
        setBatch(b);
        const sub = b.subjects?.find((s) => s._id === subjectId);
        if (sub) setSubject(sub);
      }
    });

    fetchSubjectTopics(batchId, subjectId).then((t) => {
      setTopics(t);
    });

    // Also prefetch all lectures for direct browser tab
    fetchSubjectContents(batchId, subjectId, "videos").then((vids) => {
      setAllLectures(vids);
      setLoading(false);
    });

    fetchSubjectContents(batchId, subjectId, "notes").then((nts) => {
      setAllNotes(nts);
    });
  }, [batchId, subjectId]);

  const teacher = subject?.teacherIds?.[0];

  const filteredTopics = search.trim()
    ? topics.filter((t) => t.name.toLowerCase().includes(search.trim().toLowerCase()))
    : topics;

  const totalVideos = topics.reduce((acc, t) => acc + (t.videos || t.lectureVideos || 0), 0) || allLectures.length;
  const totalNotes = topics.reduce((acc, t) => acc + (t.notes || 0), 0) || allNotes.length;

  return (
    <div className="min-h-screen pb-16 bg-slate-950 text-slate-100">
      {/* Top Breadcrumbs */}
      <div className="bg-slate-900/60 border-b border-slate-800 py-3 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto flex items-center space-x-2 text-xs text-slate-400 overflow-x-auto scrollbar-none whitespace-nowrap">
          <Link href="/" className="hover:text-white transition-colors shrink-0">
            Home
          </Link>
          <span>/</span>
          {batch && (
            <>
              <Link href={`/batch/${batch._id}`} className="hover:text-white transition-colors shrink-0 truncate max-w-[140px] sm:max-w-xs">
                {batch.name}
              </Link>
              <span>/</span>
            </>
          )}
          <span className="text-slate-200 font-semibold truncate shrink-0">
            {subject?.subject || "Subject Details"}
          </span>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-6">
        {/* Subject Header */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-7 flex flex-col md:flex-row md:items-center justify-between gap-6 shadow-xl">
          <div>
            <div className="flex items-center space-x-2">
              <span className="px-2.5 py-0.5 text-xs font-bold bg-cyan-950 text-cyan-400 border border-cyan-800 rounded-md">
                SUBJECT MODULE
              </span>
              <span className="text-xs text-slate-400 font-medium">
                Part of {batch?.name || "PW MedEd"}
              </span>
            </div>

            <h1 className="text-2xl sm:text-3xl font-extrabold text-white mt-2">
              {subject?.subject || "Module"}
            </h1>

            {/* Quick summary stats */}
            <div className="mt-3.5 flex flex-wrap gap-2 text-xs">
              <span className="px-2.5 py-1 rounded-lg bg-slate-800/80 text-cyan-300 border border-slate-700/80 font-medium flex items-center space-x-1.5">
                <Layers className="w-3.5 h-3.5 text-cyan-400" />
                <span>{topics.length} Chapters</span>
              </span>
              <span className="px-2.5 py-1 rounded-lg bg-slate-800/80 text-teal-300 border border-slate-700/80 font-medium flex items-center space-x-1.5">
                <Video className="w-3.5 h-3.5 text-teal-400" />
                <span>{totalVideos} Video Lectures</span>
              </span>
              <span className="px-2.5 py-1 rounded-lg bg-slate-800/80 text-purple-300 border border-slate-700/80 font-medium flex items-center space-x-1.5">
                <FileText className="w-3.5 h-3.5 text-purple-400" />
                <span>{totalNotes} Class Notes</span>
              </span>
            </div>
          </div>

          {teacher && (
            <div className="flex items-center space-x-3.5 bg-slate-950/70 p-3.5 rounded-xl border border-slate-800 shrink-0">
              {teacher.imageId && (
                <img
                  src={getFullImageUrl(teacher.imageId)}
                  alt={teacher.firstName}
                  className="w-12 h-12 rounded-full object-cover border border-cyan-500/40"
                  onError={(e) => {
                    (e.target as HTMLElement).style.display = "none";
                  }}
                />
              )}
              <div>
                <p className="text-[11px] text-slate-400 font-medium">Faculty Specialist</p>
                <h4 className="text-sm font-bold text-white">
                  {teacher.firstName} {teacher.lastName}
                </h4>
                <p className="text-[11px] text-cyan-400 font-semibold">{teacher.qualification}</p>
              </div>
            </div>
          )}
        </div>

        {/* View Switcher Tabs */}
        <div className="mt-8 flex items-center justify-between border-b border-slate-800 pb-3 flex-wrap gap-3">
          <div className="flex space-x-2">
            <button
              onClick={() => setActiveView("chapters")}
              className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-bold flex items-center space-x-2 transition-colors ${
                activeView === "chapters"
                  ? "bg-cyan-600 text-white shadow-md shadow-cyan-600/30"
                  : "text-slate-400 hover:text-white hover:bg-slate-900"
              }`}
            >
              <Layers className="w-4 h-4" />
              <span>Chapters ({topics.length})</span>
            </button>

            <button
              onClick={() => setActiveView("all-lectures")}
              className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-bold flex items-center space-x-2 transition-colors ${
                activeView === "all-lectures"
                  ? "bg-cyan-600 text-white shadow-md shadow-cyan-600/30"
                  : "text-slate-400 hover:text-white hover:bg-slate-900"
              }`}
            >
              <Video className="w-4 h-4" />
              <span>All Lectures ({allLectures.length})</span>
            </button>

            <button
              onClick={() => setActiveView("all-notes")}
              className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-bold flex items-center space-x-2 transition-colors ${
                activeView === "all-notes"
                  ? "bg-cyan-600 text-white shadow-md shadow-cyan-600/30"
                  : "text-slate-400 hover:text-white hover:bg-slate-900"
              }`}
            >
              <FileText className="w-4 h-4" />
              <span>All Notes ({allNotes.length})</span>
            </button>
          </div>

          {activeView === "chapters" && topics.length > 2 && (
            <div className="relative w-full sm:w-64">
              <Search className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search chapters..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="w-full pl-9 pr-3 py-1.5 rounded-xl bg-slate-900 border border-slate-800 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 transition-colors"
              />
            </div>
          )}
        </div>

        {/* View 1: Chapters Grid */}
        {activeView === "chapters" && (
          <div className="mt-6">
            {loading ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
                {[1, 2, 3].map((i) => (
                  <div key={i} className="h-44 bg-slate-900 border border-slate-800 rounded-2xl animate-pulse"></div>
                ))}
              </div>
            ) : filteredTopics.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
                {filteredTopics.map((topic, idx) => {
                  const lecCount = topic.videos || topic.lectureVideos || 0;
                  const noteCount = topic.notes || 0;
                  const exCount = topic.exercises || 0;

                  return (
                    <Link
                      key={topic._id}
                      href={`/batch/${batchId}/subject/${subjectId}/topic/${topic._id}`}
                      className="group bg-slate-900 border border-slate-800 hover:border-cyan-500/50 rounded-2xl p-5 sm:p-6 shadow-xl transition-all duration-300 hover:-translate-y-1 flex flex-col justify-between"
                    >
                      <div>
                        {/* Chapter badge and index */}
                        <div className="flex items-center justify-between">
                          <span className="px-2.5 py-0.5 rounded-md bg-cyan-950 text-cyan-400 border border-cyan-800 text-[10px] font-extrabold">
                            CHAPTER #{String(idx + 1).padStart(2, "0")}
                          </span>
                          <span className="text-slate-500 group-hover:text-cyan-400 transition-colors">
                            <ArrowRight className="w-4 h-4 transform group-hover:translate-x-1 transition-transform" />
                          </span>
                        </div>

                        {/* Chapter Title */}
                        <h3 className="text-base sm:text-lg font-bold text-white group-hover:text-cyan-300 transition-colors mt-3 line-clamp-2 leading-snug">
                          {topic.name}
                        </h3>
                      </div>

                      {/* Chapter Content Stats */}
                      <div className="mt-5 pt-4 border-t border-slate-800/80 flex items-center justify-between text-xs text-slate-400">
                        <div className="flex items-center space-x-3">
                          <span className="flex items-center space-x-1 text-cyan-300 font-medium">
                            <Video className="w-3.5 h-3.5 text-cyan-400" />
                            <span>{lecCount} Lectures</span>
                          </span>

                          <span className="flex items-center space-x-1 text-slate-400">
                            <FileText className="w-3.5 h-3.5 text-slate-500" />
                            <span>{noteCount} Notes</span>
                          </span>

                          {exCount > 0 && (
                            <span className="flex items-center space-x-1 text-purple-400">
                              <BookOpen className="w-3.5 h-3.5" />
                              <span>{exCount} DPP</span>
                            </span>
                          )}
                        </div>

                        <span className="text-xs font-semibold text-cyan-400 group-hover:underline">
                          View
                        </span>
                      </div>
                    </Link>
                  );
                })}
              </div>
            ) : (
              <div className="text-center py-16 bg-slate-900/40 border border-slate-800 rounded-2xl text-slate-400">
                <Layers className="w-12 h-12 mx-auto text-slate-600 mb-2" />
                <p>No chapters found matching your query.</p>
              </div>
            )}
          </div>
        )}

        {/* View 2: All Lectures Grid */}
        {activeView === "all-lectures" && (
          <div className="mt-6">
            {loading ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {[1, 2, 3, 4, 5, 6].map((i) => (
                  <div key={i} className="aspect-video bg-slate-900 rounded-2xl animate-pulse"></div>
                ))}
              </div>
            ) : allLectures.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {allLectures.map((lec, idx) => {
                  const thumb =
                    lec.videoDetails?.image ||
                    (subject?.imageId ? getFullImageUrl(subject.imageId) : null);

                  return (
                    <div
                      key={lec._id}
                      className="bg-slate-900 border border-slate-800 hover:border-cyan-500/50 rounded-2xl overflow-hidden shadow-xl transition-all duration-300 hover:-translate-y-1 group flex flex-col justify-between"
                    >
                      <div>
                        {/* 16:9 Thumbnail Header */}
                        <div className="relative aspect-video w-full bg-slate-950 overflow-hidden">
                          {thumb ? (
                            <img
                              src={thumb}
                              alt={lec.topic}
                              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                              loading="lazy"
                            />
                          ) : (
                            <div className="w-full h-full flex items-center justify-center bg-gradient-to-tr from-cyan-950 to-slate-900 text-cyan-400">
                              <Play className="w-10 h-10 fill-current" />
                            </div>
                          )}

                          <div className="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-transparent to-black/30 pointer-events-none" />

                          {lec.duration && (
                            <div className="absolute bottom-2.5 right-2.5 px-2 py-0.5 rounded-md bg-black/80 backdrop-blur-sm text-[10px] font-mono font-bold text-white border border-white/10 shadow-md">
                              {lec.duration}
                            </div>
                          )}

                          <div className="absolute top-2.5 left-2.5 flex items-center space-x-1.5">
                            <span className="px-2 py-0.5 rounded-md bg-cyan-950/90 text-cyan-300 border border-cyan-800/80 text-[10px] font-extrabold shadow">
                              #{String(idx + 1).padStart(2, "0")}
                            </span>
                          </div>

                          <Link
                            href={`/batch/${batchId}/subject/${subjectId}/watch/${lec._id}`}
                            className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity bg-black/40 backdrop-blur-[1px]"
                          >
                            <div className="w-12 h-12 rounded-full bg-cyan-500 text-black flex items-center justify-center shadow-xl shadow-cyan-900/60 transition-transform transform group-hover:scale-110">
                              <Play className="w-6 h-6 fill-current translate-x-0.5" />
                            </div>
                          </Link>
                        </div>

                        {/* Card Body */}
                        <div className="p-4">
                          <h4 className="text-sm font-bold text-white group-hover:text-cyan-300 transition-colors line-clamp-2 leading-snug">
                            {lec.topic}
                          </h4>

                          <div className="mt-2.5 flex items-center space-x-2 text-[11px] text-slate-400">
                            {lec.date && (
                              <span className="inline-flex items-center space-x-1">
                                <Calendar className="w-3 h-3 text-slate-500" />
                                <span>
                                  {new Date(lec.date).toLocaleDateString([], {
                                    month: "short",
                                    day: "numeric",
                                    year: "numeric",
                                  })}
                                </span>
                              </span>
                            )}
                          </div>
                        </div>
                      </div>

                      {/* Watch in Cinema Button */}
                      <div className="px-4 pb-4 pt-2 border-t border-slate-800/80">
                        <Link
                          href={`/batch/${batchId}/subject/${subjectId}/watch/${lec._id}`}
                          className="w-full inline-flex items-center justify-center space-x-2 px-4 py-2.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-bold transition-colors shadow-lg shadow-cyan-900/40"
                        >
                          <Play className="w-3.5 h-3.5 fill-current" />
                          <span>Watch Lecture</span>
                        </Link>
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="text-center py-16 bg-slate-900/40 border border-slate-800 rounded-2xl text-slate-400">
                <Video className="w-12 h-12 mx-auto text-slate-600 mb-2" />
                <p>No video lectures found for this subject.</p>
              </div>
            )}
          </div>
        )}

        {/* View 3: All Notes */}
        {activeView === "all-notes" && (
          <div className="mt-6">
            {allNotes.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {allNotes.map((item) => {
                  const homework = item.homeworkIds?.[0];
                  const attachment = homework?.attachmentIds?.[0];
                  const noteTitle = homework?.topic || item.topic || "Classroom Document";
                  const pdfUrl = attachment ? getFullImageUrl(attachment) : null;

                  return (
                    <div
                      key={item._id}
                      className="bg-slate-900 border border-slate-800 hover:border-cyan-500/40 rounded-xl p-5 flex flex-col justify-between transition-all group"
                    >
                      <div>
                        <div className="flex items-start justify-between gap-2">
                          <div className="p-2 rounded-lg bg-cyan-950 text-cyan-400">
                            <FileText className="w-5 h-5" />
                          </div>
                          <span className="px-2 py-0.5 text-[10px] font-bold bg-slate-800 text-slate-300 rounded uppercase">
                            CLASS NOTE
                          </span>
                        </div>
                        <h4 className="text-sm font-bold text-white mt-3 group-hover:text-cyan-300 transition-colors line-clamp-2">
                          {noteTitle}
                        </h4>
                        <p className="text-xs text-slate-400 mt-1">
                          {homework?.note || "Official MedEd Study Material"}
                        </p>
                      </div>

                      <div className="mt-5 pt-3 border-t border-slate-800/80 flex items-center space-x-2">
                        {pdfUrl ? (
                          <>
                            <button
                              onClick={() => setModalPdf({ url: pdfUrl, title: noteTitle })}
                              className="flex-1 inline-flex items-center justify-center space-x-1.5 px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-lg transition-colors"
                            >
                              <Eye className="w-3.5 h-3.5" />
                              <span>Preview</span>
                            </button>

                            <a
                              href={`/api/pdf-proxy?url=${encodeURIComponent(pdfUrl)}`}
                              download={`${noteTitle}.pdf`}
                              className="flex-1 inline-flex items-center justify-center space-x-1.5 px-3 py-2 bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold rounded-lg transition-colors"
                            >
                              <Download className="w-3.5 h-3.5" />
                              <span>Download</span>
                            </a>
                          </>
                        ) : (
                          <span className="text-xs text-slate-500 italic">No attachment linked</span>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="text-center py-16 bg-slate-900/40 border border-slate-800 rounded-2xl text-slate-400">
                <FileText className="w-12 h-12 mx-auto text-slate-600 mb-2" />
                <p>No class notes found for this subject.</p>
              </div>
            )}
          </div>
        )}
      </div>

      {/* PDF Modal */}
      {modalPdf && (
        <PdfModal
          isOpen={Boolean(modalPdf)}
          onClose={() => setModalPdf(null)}
          pdfUrl={modalPdf.url}
          title={modalPdf.title}
        />
      )}
    </div>
  );
}

export default SubjectDetail;
