import fs from 'fs';
import path from 'path';
import archiver from 'archiver';

const sourceDir = 'C:\\Users\\hp\\.gemini\\antigravity\\scratch\\pwmeded';
const outZip = 'C:\\Users\\hp\\.gemini\\antigravity\\scratch\\pwmeded_backup.zip';

async function zipDir() {
  const output = fs.createWriteStream(outZip);
  const archive = archiver('zip', { zlib: { level: 9 } });

  output.on('close', async () => {
    console.log(`Zip finished: ${archive.pointer()} total bytes`);
    
    // Now upload to Catbox
    console.log('Uploading to Catbox...');
    const formData = new FormData();
    formData.append('reqtype', 'fileupload');
    const fileBytes = fs.readFileSync(outZip);
    const blob = new Blob([fileBytes], { type: 'application/zip' });
    formData.append('fileToUpload', blob, 'pwmeded_code.zip');

    try {
      const res = await fetch('https://catbox.moe/user/api.php', {
        method: 'POST',
        body: formData
      });
      const link = await res.text();
      console.log('UPLOAD_RESULT:', link.trim());
    } catch (err) {
      console.error('Upload failed:', err);
    }
  });

  archive.on('error', (err) => {
    throw err;
  });

  archive.pipe(output);

  archive.glob('**/*', {
    cwd: sourceDir,
    ignore: ['node_modules/**', 'dist/**', '.wrangler/**', '.git/**']
  });

  await archive.finalize();
}

zipDir().catch(console.error);
