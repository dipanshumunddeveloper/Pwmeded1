import React from "react";
import { Route, Switch, Link } from "wouter";
import { Navbar } from "./components/Navbar";
import { Home } from "./pages/Home";
import { BatchDetail } from "./pages/BatchDetail";
import { SubjectDetail } from "./pages/SubjectDetail";
import { TopicDetail } from "./pages/TopicDetail";
import { WatchVideo } from "./pages/WatchVideo";
import { Admin } from "./pages/Admin";

export function App() {
  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans overflow-x-hidden">
      <Navbar />

      <main className="flex-1 w-full overflow-x-hidden">
        <Switch>
          <Route path="/" component={Home} />
          <Route path="/explore" component={Home} />
          <Route path="/admin" component={Admin} />
          <Route path="/batch/:batchId" component={BatchDetail} />
          <Route path="/batch/:batchId/subject/:subjectId/topic/:topicId" component={TopicDetail} />
          <Route path="/batch/:batchId/subject/:subjectId/watch/:lectureId" component={WatchVideo} />
          <Route path="/batch/:batchId/subject/:subjectId/lecture/:lectureId" component={WatchVideo} />
          <Route path="/batch/:batchId/subject/:subjectId" component={SubjectDetail} />
          <Route>
            <div className="max-w-2xl mx-auto px-4 py-20 text-center">
              <h2 className="text-3xl font-extrabold text-white">404 - Page Not Found</h2>
              <p className="text-slate-400 mt-2">The page you were looking for doesn't exist.</p>
              <a
                href="/"
                className="mt-6 inline-block px-5 py-2.5 bg-cyan-600 text-white rounded-xl text-sm font-semibold hover:bg-cyan-500 transition-colors"
              >
                Return Home
              </a>
            </div>
          </Route>
        </Switch>
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-900 bg-slate-950 py-6 px-4 sm:px-6 lg:px-8 text-center text-xs text-slate-500 flex flex-col items-center justify-center space-y-2">
        <p className="max-w-xl mx-auto">
          PWMedEd Medical Learning Environment.
        </p>
        <Link href="/admin" className="text-[11px] text-slate-600 hover:text-cyan-400 transition-colors">
          Control Center
        </Link>
      </footer>
    </div>
  );
}

export default App;
