import React, { useState, useEffect } from "react";
import { Link } from "wouter";
import {
  ShieldCheck,
  Lock,
  KeyRound,
  Smartphone,
  CheckCircle2,
  AlertCircle,
  RefreshCw,
  Database,
  Clock,
  ArrowRight,
  LogOut,
  ChevronLeft,
  Send,
} from "lucide-react";

// SHA-256 hash helper using browser Web Crypto API
async function sha256(message: string): Promise<string> {
  const msgBuffer = new TextEncoder().encode(message);
  const hashBuffer = await crypto.subtle.digest("SHA-256", msgBuffer);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map((b) => b.toString(16).padStart(2, "0")).join("");
}

export function Admin() {
  // Admin Session State
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);
  const [passwordInput, setPasswordInput] = useState<string>("");
  const [loginError, setLoginError] = useState<string>("");
  const [isLoggingIn, setIsLoggingIn] = useState<boolean>(false);

  // System Status State
  const [systemStatus, setSystemStatus] = useState<any>(null);
  const [loadingStatus, setLoadingStatus] = useState<boolean>(false);

  // OTP Login Flow State
  const [mobileNumber, setMobileNumber] = useState<string>("6387426778");
  const [otpSent, setOtpSent] = useState<boolean>(false);
  const [otpInput, setOtpInput] = useState<string>("");
  const [otpLoading, setOtpLoading] = useState<boolean>(false);
  const [otpMessage, setOtpMessage] = useState<{ text: string; type: "success" | "error" } | null>(null);

  // Manual Token State
  const [manualToken, setManualToken] = useState<string>("");
  const [manualRefreshToken, setManualRefreshToken] = useState<string>("");
  const [manualLoading, setManualLoading] = useState<boolean>(false);
  const [manualMessage, setManualMessage] = useState<string>("");

  // Check existing session
  useEffect(() => {
    const savedHash = sessionStorage.getItem("pwmeded_admin_hash");
    if (savedHash) {
      verifyStoredHash(savedHash);
    }
  }, []);

  async function verifyStoredHash(hash: string) {
    try {
      const res = await fetch("/api/admin/verify", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ passHash: hash }),
      });
      const data = await res.json();
      if (data.ok) {
        setIsAuthenticated(true);
        loadStatus(hash);
      } else {
        sessionStorage.removeItem("pwmeded_admin_hash");
        setIsAuthenticated(false);
      }
    } catch {
      setIsAuthenticated(false);
    }
  }

  async function handleLogin(e: React.FormEvent) {
    e.preventDefault();
    setLoginError("");
    setIsLoggingIn(true);

    try {
      const hash = await sha256(passwordInput.trim());
      const res = await fetch("/api/admin/verify", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ passHash: hash }),
      });
      const data = await res.json();

      if (data.ok) {
        sessionStorage.setItem("pwmeded_admin_hash", hash);
        setIsAuthenticated(true);
        loadStatus(hash);
      } else {
        setLoginError("Invalid Master Key. Access denied.");
      }
    } catch (err: any) {
      setLoginError(err.message || "Authentication error.");
    } finally {
      setIsLoggingIn(false);
    }
  }

  function handleLogout() {
    sessionStorage.removeItem("pwmeded_admin_hash");
    setIsAuthenticated(false);
    setPasswordInput("");
  }

  async function loadStatus(hash?: string) {
    const adminHash = hash || sessionStorage.getItem("pwmeded_admin_hash") || "";
    setLoadingStatus(true);
    try {
      const res = await fetch("/api/admin/status", {
        headers: { "X-Admin-Hash": adminHash },
      });
      const data = await res.json();
      setSystemStatus(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoadingStatus(false);
    }
  }

  async function handleSendOtp() {
    if (!mobileNumber || mobileNumber.length < 10) {
      setOtpMessage({ text: "Please enter a valid 10-digit mobile number.", type: "error" });
      return;
    }

    setOtpLoading(true);
    setOtpMessage(null);
    const adminHash = sessionStorage.getItem("pwmeded_admin_hash") || "";

    try {
      const res = await fetch("/api/admin/send-otp", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-Admin-Hash": adminHash,
        },
        body: JSON.stringify({ mobile: mobileNumber.trim() }),
      });
      const data = await res.json();

      if (data.success) {
        setOtpSent(true);
        setOtpMessage({ text: `OTP sent successfully to +91 ${mobileNumber}! Please check SMS.`, type: "success" });
      } else {
        setOtpMessage({ text: data.error || data.message || "Failed to send OTP.", type: "error" });
      }
    } catch (err: any) {
      setOtpMessage({ text: err.message || "Network error sending OTP.", type: "error" });
    } finally {
      setOtpLoading(false);
    }
  }

  async function handleVerifyOtp() {
    if (!otpInput || otpInput.trim().length < 4) {
      setOtpMessage({ text: "Please enter the OTP received on your mobile.", type: "error" });
      return;
    }

    setOtpLoading(true);
    setOtpMessage(null);
    const adminHash = sessionStorage.getItem("pwmeded_admin_hash") || "";

    try {
      const res = await fetch("/api/admin/verify-otp", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-Admin-Hash": adminHash,
        },
        body: JSON.stringify({
          mobile: mobileNumber.trim(),
          otp: otpInput.trim(),
        }),
      });
      const data = await res.json();

      if (data.success) {
        setOtpMessage({
          text: "Login successful! New token generated and saved to Cloudflare Global KV.",
          type: "success",
        });
        setOtpInput("");
        setOtpSent(false);
        loadStatus(adminHash);
      } else {
        setOtpMessage({ text: data.error || data.message || "Invalid OTP. Please check and retry.", type: "error" });
      }
    } catch (err: any) {
      setOtpMessage({ text: err.message || "Error verifying OTP.", type: "error" });
    } finally {
      setOtpLoading(false);
    }
  }

  async function handleManualSave() {
    if (!manualToken.trim()) return;
    setManualLoading(true);
    setManualMessage("");
    const adminHash = sessionStorage.getItem("pwmeded_admin_hash") || "";

    try {
      const res = await fetch("/api/admin/save-token", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-Admin-Hash": adminHash,
        },
        body: JSON.stringify({
          token: manualToken.trim(),
          refreshToken: manualRefreshToken.trim() || undefined,
        }),
      });
      const data = await res.json();

      if (data.success) {
        setManualMessage("Token updated in Cloudflare KV successfully!");
        setManualToken("");
        setManualRefreshToken("");
        loadStatus(adminHash);
      } else {
        setManualMessage(data.error || "Failed to update token.");
      }
    } catch (err: any) {
      setManualMessage(err.message || "Network error.");
    } finally {
      setManualLoading(false);
    }
  }

  // View 1: Password Gate
  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-slate-950 flex flex-col justify-center items-center px-4 py-12">
        <div className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-3xl p-8 shadow-2xl">
          <div className="w-12 h-12 rounded-2xl bg-cyan-950 border border-cyan-800 flex items-center justify-center text-cyan-400 mx-auto mb-4">
            <ShieldCheck className="w-6 h-6" />
          </div>

          <h2 className="text-xl font-bold text-white text-center">PWMedEd Control Center</h2>
          <p className="text-xs text-slate-400 text-center mt-1">
            Enter your encrypted administrator key to manage system tokens and mobile logins.
          </p>

          <form onSubmit={handleLogin} className="mt-6 space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">Master Key</label>
              <div className="relative">
                <Lock className="w-4 h-4 text-slate-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="password"
                  placeholder="••••••••"
                  value={passwordInput}
                  onChange={(e) => setPasswordInput(e.target.value)}
                  className="w-full pl-10 pr-4 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-sm text-white placeholder-slate-600 focus:outline-none focus:border-cyan-500 transition-colors"
                  required
                />
              </div>
            </div>

            {loginError && (
              <div className="p-3 rounded-xl bg-red-950/50 border border-red-800 text-red-300 text-xs flex items-center space-x-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{loginError}</span>
              </div>
            )}

            <button
              type="submit"
              disabled={isLoggingIn}
              className="w-full py-2.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-sm font-bold transition-colors shadow-lg shadow-cyan-900/40 flex items-center justify-center space-x-2 disabled:opacity-50"
            >
              {isLoggingIn ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>Verifying...</span>
                </>
              ) : (
                <>
                  <KeyRound className="w-4 h-4" />
                  <span>Unlock Admin Panel</span>
                </>
              )}
            </button>
          </form>

          <div className="mt-6 text-center">
            <Link href="/" className="text-xs text-slate-500 hover:text-slate-300 transition-colors">
              ← Return to Classroom
            </Link>
          </div>
        </div>
      </div>
    );
  }

  // View 2: Authenticated Admin Panel
  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 pb-20">
      {/* Top Admin Header */}
      <div className="bg-slate-900/80 border-b border-slate-800 py-3.5 px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Link
              href="/"
              className="inline-flex items-center space-x-1.5 px-2.5 py-1.5 rounded-lg text-xs font-semibold text-slate-300 hover:text-white hover:bg-slate-800 transition-colors"
            >
              <ChevronLeft className="w-4 h-4" />
              <span>Classroom</span>
            </Link>
            <div className="h-4 w-px bg-slate-800 hidden sm:block" />
            <h1 className="text-sm font-bold text-white flex items-center space-x-2">
              <ShieldCheck className="w-4 h-4 text-cyan-400" />
              <span>Admin Control Center</span>
            </h1>
          </div>

          <button
            onClick={handleLogout}
            className="inline-flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold transition-colors"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Lock</span>
          </button>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 pt-8 space-y-8">
        {/* Card 1: System Status & Cloudflare KV */}
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-7 shadow-xl">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-5">
            <div>
              <div className="flex items-center space-x-2">
                <Database className="w-4 h-4 text-cyan-400" />
                <span className="text-xs font-bold text-cyan-400 uppercase tracking-wider">
                  Cloudflare Infrastructure
                </span>
              </div>
              <h3 className="text-lg font-bold text-white mt-1">Autonomous Token Engine</h3>
            </div>

            <button
              onClick={() => loadStatus()}
              disabled={loadingStatus}
              className="inline-flex items-center space-x-1.5 px-3.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold transition-colors shrink-0 self-start sm:self-auto"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${loadingStatus ? "animate-spin text-cyan-400" : ""}`} />
              <span>Refresh Status</span>
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mt-5">
            <div className="bg-slate-950/60 p-4 rounded-2xl border border-slate-800">
              <span className="text-xs text-slate-400 font-medium">Session Status</span>
              <div className="mt-1 flex items-center space-x-2">
                <div
                  className={`w-2.5 h-2.5 rounded-full ${
                    systemStatus?.authenticated ? "bg-emerald-400 animate-pulse" : "bg-amber-400"
                  }`}
                />
                <span className="text-sm font-bold text-white">
                  {systemStatus?.authenticated ? "Authenticated & Active" : "Waiting for Token"}
                </span>
              </div>
            </div>

            <div className="bg-slate-950/60 p-4 rounded-2xl border border-slate-800">
              <span className="text-xs text-slate-400 font-medium">Cloud Database</span>
              <div className="mt-1 flex items-center space-x-2">
                <span className="text-sm font-bold text-cyan-400">
                  {systemStatus?.storage || "Cloudflare Global KV"}
                </span>
              </div>
            </div>

            <div className="bg-slate-950/60 p-4 rounded-2xl border border-slate-800">
              <span className="text-xs text-slate-400 font-medium">Token Expiration</span>
              <div className="mt-1 flex items-center space-x-2">
                <Clock className="w-3.5 h-3.5 text-teal-400" />
                <span className="text-sm font-bold text-white">
                  {systemStatus?.expiresInDays ? `${systemStatus.expiresInDays} Days Remaining` : "Auto-Renewing"}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Card 2: Update Number & Generate Token via OTP */}
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-7 shadow-xl">
          <div className="flex items-center space-x-2 text-cyan-400 mb-1">
            <Smartphone className="w-4 h-4" />
            <span className="text-xs font-bold uppercase tracking-wider">Mobile Number & OTP Sync</span>
          </div>
          <h3 className="text-lg font-bold text-white">Change Number or Re-Authenticate</h3>
          <p className="text-xs text-slate-400 mt-1 max-w-xl">
            In the future, if you ever change your registered mobile number or want to generate a new token set, enter
            your mobile number here. The system will send an official OTP and automatically save the fresh credentials to
            Cloudflare KV.
          </p>

          <div className="mt-6 max-w-lg space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">Registered Mobile Number</label>
              <div className="flex gap-2">
                <div className="px-3.5 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-sm font-bold text-slate-400 select-none">
                  +91
                </div>
                <input
                  type="tel"
                  maxLength={10}
                  placeholder="6387426778"
                  value={mobileNumber}
                  onChange={(e) => setMobileNumber(e.target.value.replace(/\D/g, ""))}
                  className="flex-1 px-4 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-sm text-white placeholder-slate-600 focus:outline-none focus:border-cyan-500 font-mono tracking-wider transition-colors"
                />
                <button
                  type="button"
                  onClick={handleSendOtp}
                  disabled={otpLoading || mobileNumber.length !== 10}
                  className="px-4 py-2.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-bold transition-colors shadow-md disabled:opacity-40 flex items-center space-x-1.5 shrink-0"
                >
                  {otpLoading ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Send className="w-3.5 h-3.5" />}
                  <span>{otpSent ? "Resend OTP" : "Send OTP"}</span>
                </button>
              </div>
            </div>

            {otpSent && (
              <div className="p-4 rounded-2xl bg-cyan-950/40 border border-cyan-800/80 space-y-3">
                <label className="block text-xs font-semibold text-cyan-300">
                  Enter 4 or 6-digit OTP received via SMS
                </label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    maxLength={6}
                    placeholder="123456"
                    value={otpInput}
                    onChange={(e) => setOtpInput(e.target.value.replace(/\D/g, ""))}
                    className="flex-1 px-4 py-2.5 bg-slate-950 border border-cyan-700/80 rounded-xl text-sm text-white placeholder-slate-600 font-mono tracking-widest text-center focus:outline-none focus:border-cyan-400"
                  />
                  <button
                    type="button"
                    onClick={handleVerifyOtp}
                    disabled={otpLoading || otpInput.length < 4}
                    className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition-colors shadow-md disabled:opacity-40 flex items-center space-x-1.5 shrink-0"
                  >
                    {otpLoading ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <CheckCircle2 className="w-3.5 h-3.5" />}
                    <span>Verify & Save</span>
                  </button>
                </div>
              </div>
            )}

            {otpMessage && (
              <div
                className={`p-3 rounded-xl border text-xs flex items-center space-x-2 ${
                  otpMessage.type === "success"
                    ? "bg-emerald-950/50 border-emerald-800 text-emerald-300"
                    : "bg-red-950/50 border-red-800 text-red-300"
                }`}
              >
                {otpMessage.type === "success" ? (
                  <CheckCircle2 className="w-4 h-4 shrink-0" />
                ) : (
                  <AlertCircle className="w-4 h-4 shrink-0" />
                )}
                <span>{otpMessage.text}</span>
              </div>
            )}
          </div>
        </div>

        {/* Card 3: Manual Token Override (Fallback) */}
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-7 shadow-xl">
          <h3 className="text-base font-bold text-white">Manual Token Override</h3>
          <p className="text-xs text-slate-400 mt-1">
            If you ever have a raw JWT access token or rolling refresh token, you can directly inject it into Cloudflare KV.
          </p>

          <div className="mt-4 max-w-xl space-y-3">
            <div>
              <label className="block text-[11px] font-semibold text-slate-400 mb-1">Access Token (Bearer)</label>
              <textarea
                rows={2}
                placeholder="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
                value={manualToken}
                onChange={(e) => setManualToken(e.target.value)}
                className="w-full p-2.5 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-200 font-mono placeholder-slate-700 focus:outline-none focus:border-cyan-500"
              />
            </div>

            <div>
              <label className="block text-[11px] font-semibold text-slate-400 mb-1">Refresh Token (Optional)</label>
              <input
                type="text"
                placeholder="dcf4fe39891a753e4c00347058137feead1e..."
                value={manualRefreshToken}
                onChange={(e) => setManualRefreshToken(e.target.value)}
                className="w-full p-2.5 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-200 font-mono placeholder-slate-700 focus:outline-none focus:border-cyan-500"
              />
            </div>

            {manualMessage && (
              <div className="p-2.5 rounded-xl bg-slate-800 border border-slate-700 text-cyan-300 text-xs">
                {manualMessage}
              </div>
            )}

            <button
              onClick={handleManualSave}
              disabled={manualLoading || !manualToken.trim()}
              className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold transition-colors disabled:opacity-40"
            >
              {manualLoading ? "Saving..." : "Save to Cloudflare KV"}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Admin;
