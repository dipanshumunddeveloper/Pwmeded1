import React from "react";
import { Link } from "wouter";
import { Subject } from "../types/meded";
import { getFullImageUrl } from "../lib/api";
import { Video, FileText, ArrowRight, User } from "lucide-react";

interface SubjectCardProps {
  batchId: string;
  subject: Subject;
}

export function SubjectCard({ batchId, subject }: SubjectCardProps) {
  const teacher = subject.teacherIds?.[0];
  const teacherImg = teacher?.imageId
    ? getFullImageUrl(teacher.imageId)
    : null;

  return (
    <div className="bg-slate-900/90 border border-slate-800 hover:border-cyan-500/40 rounded-2xl p-5 transition-all duration-300 hover:shadow-lg hover:shadow-cyan-950/20 flex flex-col justify-between group">
      <div>
        <div className="flex items-start justify-between gap-3">
          <div>
            <span className="text-[11px] font-bold text-cyan-400 uppercase tracking-wider">
              Subject
            </span>
            <h4 className="text-lg font-bold text-white group-hover:text-cyan-300 transition-colors mt-0.5">
              {subject.subject}
            </h4>
          </div>

          <div className="px-2.5 py-1 rounded-lg bg-slate-800 border border-slate-700/60 text-xs font-semibold text-slate-300 flex items-center space-x-1 shrink-0">
            <Video className="w-3.5 h-3.5 text-cyan-400" />
            <span>{subject.lectureCount || 0} Lectures</span>
          </div>
        </div>

        {/* Teacher Information */}
        {teacher ? (
          <div className="mt-4 flex items-center space-x-3 p-2.5 rounded-xl bg-slate-950/50 border border-slate-800/80">
            {teacherImg ? (
              <img
                src={teacherImg}
                alt={`${teacher.firstName} ${teacher.lastName}`}
                className="w-10 h-10 rounded-full object-cover border border-cyan-500/30"
                onError={(e) => {
                  (e.target as HTMLElement).style.display = "none";
                }}
              />
            ) : (
              <div className="w-10 h-10 rounded-full bg-slate-800 flex items-center justify-center text-slate-400">
                <User className="w-5 h-5" />
              </div>
            )}
            <div className="overflow-hidden">
              <p className="text-xs font-semibold text-slate-200 truncate">
                {teacher.firstName} {teacher.lastName}
              </p>
              <p className="text-[11px] text-slate-400 truncate">
                {teacher.qualification || "Faculty Specialist"}
              </p>
            </div>
          </div>
        ) : (
          <div className="mt-4 p-2.5 rounded-xl bg-slate-950/30 text-xs text-slate-500 italic">
            Department Faculty
          </div>
        )}
      </div>

      <div className="mt-5 pt-3">
        <Link
          href={`/batch/${batchId}/subject/${subject._id}`}
          className="w-full inline-flex items-center justify-between px-4 py-2 rounded-xl bg-slate-800 hover:bg-cyan-600 text-slate-200 hover:text-white font-medium text-xs transition-colors"
        >
          <span>View Chapters & Lectures</span>
          <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
        </Link>
      </div>
    </div>
  );
}
