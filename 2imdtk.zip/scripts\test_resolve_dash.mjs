// Test: resolve video URL from the worker API and check if DASH MPD is accessible with signed params
async function run() {
  const workerBase = 'https://pwmeded.dipanshumund-529.workers.dev';
  
  // 1. Get auth token
  const tokenRes = await fetch(`${workerBase}/api/auth/token`);
  const tokenData = await tokenRes.json();
  console.log('Token available:', !!tokenData.token);
  console.log('Token prefix:', tokenData.token?.substring(0, 50) + '...');
  
  // 2. Resolve video for General & Systemic Histology
  const resolveUrl = `${workerBase}/api/videos/resolve?batchId=6a6de3dc386150cc7a2b4232&childId=6ace27e27f34f9fab31df011&videoId=6ace27e27f34f9fab31df011`;
  const resolveRes = await fetch(resolveUrl);
  const resolveData = await resolveRes.json();
  console.log('\nResolve status:', resolveRes.status);
  console.log('Resolve response:', JSON.stringify(resolveData, null, 2));
  
  // 3. If we got a signed DASH URL, test if it's accessible
  if (resolveData?.data?.dashUrl) {
    const dashUrl = resolveData.data.dashUrl;
    console.log('\nTesting signed DASH URL...');
    const dashRes = await fetch(dashUrl, { method: 'HEAD' });
    console.log('DASH status:', dashRes.status);
    console.log('Content-Type:', dashRes.headers.get('content-type'));
  }
  
  // 4. Test proxied DASH URL through the worker
  if (resolveData?.data?.dashUrl) {
    const proxiedUrl = `${workerBase}/api/video-proxy?url=${encodeURIComponent(resolveData.data.dashUrl)}`;
    console.log('\nTesting proxied DASH URL...');
    const proxiedRes = await fetch(proxiedUrl);
    console.log('Proxied DASH status:', proxiedRes.status);
    if (proxiedRes.ok) {
      const mpdText = await proxiedRes.text();
      console.log('MPD content (first 1000 chars):', mpdText.substring(0, 1000));
      
      // Extract default_KID from DASH
      const kidMatch = mpdText.match(/default_KID="([^"]+)"/i) || mpdText.match(/cenc:default_KID="([^"]+)"/i);
      if (kidMatch) {
        console.log('\nDASH default_KID:', kidMatch[1]);
        const cleanKid = kidMatch[1].replace(/-/g, '');
        console.log('Clean KID hex:', cleanKid);
      }
    }
  }
}
run();
