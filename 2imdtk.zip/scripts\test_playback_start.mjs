const token = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJkYXRhIjp7Il9pZCI6IjZhYzc4ZTE4MjUxMzhlOTI3ZmM3YmU4NyIsImNvdW50cnlHcm91cCI6IklOIiwib3JnYW5pemF0aW9uIjp7Il9pZCI6IjYzYjUyOTYzZTcyZThiMDAxODZjMTFmMyJ9LCJyb2xlcyI6WyI1YjI3YmQ5NjU4NDJmOTUwYTc3OGM2ZWYiXSwidHlwZSI6IlVTRVIiLCJ1c2VybmFtZSI6IjYzODc0MjY3NzgifSwiZXhwIjoxNzk1NzAxMzQwLjgxOSwiaWF0IjoxNzk1MDk2NTQwLCJqdGkiOiI4aFZfenpvM1JhYVd0aXdTRGEzRkJ3XzZhYzc4ZTE4MjUxMzhlOTI3ZmM3YmU4NyJ9._zGTjQd2p9mqe3XH7UR9gbgyVezXhXuA6SYpMc1IRV0';

async function test() {
  const body = {
    type: "BATCHES",
    videoContainerType: "DASH",
    reqType: "query",
    childId: "6ace27e27f34f9fab31df011",
    parentId: "6a6de3dc386150cc7a2b4232",
    clientVersion: "201"
  };

  const urls = [
    "https://meded-api.penpencil.co/v1/videos/playback/start",
    "https://api.penpencil.co/v1/videos/playback/start",
    "https://meded-api.penpencil.co/v1/videos/video-url-details"
  ];

  for (const url of urls) {
    console.log("=== Testing", url, "===");
    // test GET (for video-url-details) and POST
    try {
      const resPost = await fetch(url, {
        method: "POST",
        headers: {
          "content-type": "application/json",
          "authorization": "Bearer " + token,
          "client-id": "63b52963e72e8b00186c11f3",
          "client-type": "WEB",
          "organization-id": "63b52963e72e8b00186c11f3",
          "referer": "https://meded.pw.live/",
          "origin": "https://meded.pw.live",
          "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
        },
        body: JSON.stringify(body)
      });
      console.log("POST status:", resPost.status);
      const text = await resPost.text();
      console.log("POST body:", text.slice(0, 300));
    } catch (e) {
      console.log("POST error:", e.message);
    }
  }
}

test();
