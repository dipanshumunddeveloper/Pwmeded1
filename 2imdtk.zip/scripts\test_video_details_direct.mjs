// Test: direct call to video-url-details API with proper headers
async function run() {
  const workerBase = 'https://pwmeded.dipanshumund-529.workers.dev';
  
  // Get token
  const tokenRes = await fetch(`${workerBase}/api/auth/token`);
  const { token } = await tokenRes.json();
  
  const videoUrl = 'https://d1d34p8vz63oiq.cloudfront.net/drm/de9f6d33-1be5-4ed0-a9ad-8913dc037cb0/master.mpd';
  
  const headers = {
    'Authorization': `Bearer ${token}`,
    'client-id': '63b52963e72e8b00186c11f3',
    'client-type': 'WEB',
    'client-version': '201',
    'Origin': 'https://meded.pw.live',
    'Referer': 'https://meded.pw.live/',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
  };

  // Try DASH
  const dashParams = new URLSearchParams({
    type: 'BATCHES',
    videoContainerType: 'DASH',
    reqType: 'query',
    childId: '6ace27e27f34f9fab31df011',
    parentId: '6a6de3dc386150cc7a2b4232',
    clientVersion: '201',
    videoUrl: videoUrl
  });

  for (const base of ['https://meded-api.penpencil.co', 'https://api.penpencil.co']) {
    const url = `${base}/v1/videos/video-url-details?${dashParams}`;
    console.log('Trying:', url.substring(0, 100) + '...');
    const res = await fetch(url, { headers });
    console.log('Status:', res.status);
    const text = await res.text();
    console.log('Response:', text.substring(0, 500));
    console.log('---');
  }

  // Try HLS
  const hlsParams = new URLSearchParams({
    type: 'BATCHES',
    videoContainerType: 'HLS',
    reqType: 'query',
    childId: '6ace27e27f34f9fab31df011',
    parentId: '6a6de3dc386150cc7a2b4232',
    clientVersion: '201',
    videoUrl: videoUrl.replace('.mpd', '.m3u8')
  });

  for (const base of ['https://meded-api.penpencil.co', 'https://api.penpencil.co']) {
    const url = `${base}/v1/videos/video-url-details?${hlsParams}`;
    console.log('Trying HLS:', url.substring(0, 100) + '...');
    const res = await fetch(url, { headers });
    console.log('Status:', res.status);
    const text = await res.text();
    console.log('Response:', text.substring(0, 500));
    console.log('---');
  }
}
run();
