import React, { useState, useEffect, useRef } from "react";
import { LectureContent } from "../types/meded";
import { resolveVideoStream, fetchAuthToken, ResolvedVideo } from "../lib/api";
import {
  Play,
  Pause,
  RotateCcw,
  RotateCw,
  Volume2,
  VolumeX,
  Maximize2,
  Minimize2,
  Settings,
  AlertCircle,
  RefreshCw,
  ExternalLink,
  Layers,
  Check,
  ShieldCheck,
  Zap,
  Monitor,
  Globe,
} from "lucide-react";

interface VideoPlayerProps {
  lecture: LectureContent;
  batchId?: string;
  showMetaBar?: boolean;
}

interface QualityTrack {
  height: number;
  bandwidth: number;
  levelIndex: number;
}

function formatTime(secs: number): string {
  if (!isFinite(secs) || secs < 0) return "00:00";
  const h = Math.floor(secs / 3600);
  const m = Math.floor((secs % 3600) / 60);
  const s = Math.floor(secs % 60);
  if (h > 0) {
    return `${h}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
  }
  return `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
}

export function VideoPlayer({ lecture, batchId = "", showMetaBar = false }: VideoPlayerProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const hlsRef = useRef<any>(null);
  const shakaRef = useRef<any>(null);
  const hideControlsTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Stream Resolution & Mode
  const [resolved, setResolved] = useState<ResolvedVideo | null>(null);
  const [authToken, setAuthToken] = useState<string>("");
  const [playerEngine, setPlayerEngine] = useState<"hls" | "shaka">("shaka");
  const [useProxy, setUseProxy] = useState<boolean>(true);

  // Playback State
  const [status, setStatus] = useState<"resolving" | "loading" | "ready" | "error">("resolving");
  const [statusMsg, setStatusMsg] = useState<string>("Resolving secure stream...");
  const [errorMsg, setErrorMsg] = useState<string>("");
  const [playing, setPlaying] = useState<boolean>(false);
  const [currentTime, setCurrentTime] = useState<number>(0);
  const [duration, setDuration] = useState<number>(0);
  const [bufferedTime, setBufferedTime] = useState<number>(0);
  const [volume, setVolume] = useState<number>(1);
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [playbackRate, setPlaybackRate] = useState<number>(1);
  const [isFullscreen, setIsFullscreen] = useState<boolean>(false);
  const [showControls, setShowControls] = useState<boolean>(true);

  // Qualities & Settings Menu
  const [qualities, setQualities] = useState<QualityTrack[]>([]);
  const [currentQuality, setCurrentQuality] = useState<number | "auto">("auto");
  const [showSettingsMenu, setShowSettingsMenu] = useState<boolean>(false);
  const [activeMenuTab, setActiveMenuTab] = useState<"main" | "quality" | "speed" | "engine">("main");

  // Player Engine Mode: "pw-embed" (Official PW HD Video Player) or "native" (In-browser Shaka/HLS engine)
  const [playerMode, setPlayerMode] = useState<"pw-embed" | "native">("pw-embed");

  // Check YouTube
  const ytEmbed = lecture.videoDetails?.embedCode || (lecture.url?.includes("youtube.com") ? lecture.url : null);
  const rawVideoUrl = lecture.videoDetails?.videoUrl || lecture.url || "";
  const childId = lecture._id || lecture.videoDetails?._id || "";
  const videoId = lecture.videoId || lecture.videoDetails?.id || "";

  // Dynamic Official Watch URL with active session authorization
  const effectiveBatchId = batchId || "6a6de3dc386150cc7a2b4232";
  const activeToken = resolved?.token || authToken;
  const tokenQuery = activeToken ? `&token=${encodeURIComponent(activeToken)}&random_id=d123456` : "";
  const watchUrl = `https://www.pw.live/watch/?batchSlug=prarambh-bds-1st-year-2026-800894&batchSubjectId=6adb0504d6248830d3d75f5b&subjectSlug=6adb0504d6248830d3d75f5b&topicSlug=classes&scheduleId=${encodeURIComponent(childId)}&is_products_enabled=false&type=penpencilvdo&parentId=${encodeURIComponent(effectiveBatchId)}&childId=${encodeURIComponent(childId)}&src=${encodeURIComponent(rawVideoUrl)}${tokenQuery}&back_button=false&three_dots=false&vType=RECORDED&came_from=NEET_PG&is_poll_enabled=false&client_id=63b52963e72e8b00186c11f3`;
  const officialClassroomUrl = `https://meded.pw.live/live-batch/prarambh-bds-1st-year-2026-800894/subject/anatomy-819782/topics/introduction-to-anatomy-123456/${childId}/video`;

  // Fetch active token on initial mount
  useEffect(() => {
    fetchAuthToken().then((t) => {
      if (t) setAuthToken(t);
    });
  }, []);

  const openStandalonePlayer = () => {
    const width = Math.min(1360, window.screen.width - 60);
    const height = Math.min(840, window.screen.height - 60);
    const left = Math.max(0, Math.floor((window.screen.width - width) / 2));
    const top = Math.max(0, Math.floor((window.screen.height - height) / 2));
    window.open(
      watchUrl,
      'pwTheaterPlayer',
      `width=${width},height=${height},left=${left},top=${top},menubar=no,toolbar=no,location=no,status=no,resizable=yes,scrollbars=no`
    );
  };

  // 1. Resolve Stream from backend when lecture changes
  useEffect(() => {
    let cancelled = false;

    if (ytEmbed) {
      setStatus("ready");
      return;
    }

    if (!batchId || !childId) {
      if (rawVideoUrl) {
        setStatus("ready");
      }
      return;
    }

    setStatus("resolving");
    setStatusMsg("Exchanging MedEd credentials for authenticated stream...");
    setErrorMsg("");

    resolveVideoStream(batchId, childId, videoId).then((res) => {
      if (cancelled) return;
      if (res) {
        setResolved(res);
        if (res.token) {
          setAuthToken(res.token);
        }
        const isDash =
          res.videoContainer === "DASH" ||
          res.dashUrl?.includes(".mpd") ||
          rawVideoUrl.includes(".mpd") ||
          Boolean(res.hasDrm);

        if (isDash) {
          setPlayerEngine("shaka");
          setStatusMsg(res.hasDrm ? "Decrypting Widevine DRM stream..." : "Loading DASH stream...");
        } else {
          setPlayerEngine("hls");
          setStatusMsg("Loading video stream...");
        }
        setStatus("loading");
      } else {
        // Fallback to raw URL
        setStatus("error");
        setErrorMsg("Could not authenticate with MedEd video licensing server.");
      }
    });

    return () => {
      cancelled = true;
    };
  }, [batchId, childId, videoId, ytEmbed, rawVideoUrl]);

  // 2. Initialize Player Engine (HLS.js or Shaka)
  useEffect(() => {
    if (ytEmbed) return;
    const video = videoRef.current;
    if (!video || !resolved) return;

    let cancelled = false;

    // Cleanup previous instances
    if (hlsRef.current) {
      hlsRef.current.destroy();
      hlsRef.current = null;
    }
    if (shakaRef.current) {
      shakaRef.current.destroy();
      shakaRef.current = null;
    }

    const signedQs = resolved.signedQs || "";
    const effectiveHlsUrl = useProxy
      ? `/api/video-proxy?url=${encodeURIComponent(resolved.hlsUrl)}`
      : resolved.hlsUrl;
    const effectiveDashUrl = useProxy
      ? `/api/video-proxy?url=${encodeURIComponent(resolved.dashUrl)}`
      : resolved.dashUrl;

    async function loadStream() {
      try {
        if (playerEngine === "hls") {
          const HlsModule = await import("hls.js");
          const Hls = (HlsModule as any).default ?? HlsModule;
          if (cancelled) return;

          if (Hls.isSupported()) {
            const hls = new Hls({
              enableWorker: true,
              lowLatencyMode: false,
              backBufferLength: 90,
              xhrSetup: (xhr: XMLHttpRequest, reqUrl: string) => {
                let finalUrl = reqUrl;
                // Intercept key request
                if (reqUrl.includes("get-hls-key") || reqUrl.includes("/v1/videos/get-hls-key")) {
                  try {
                    const u = new URL(reqUrl, window.location.origin);
                    const vk = u.searchParams.get("videoKey") || "";
                    finalUrl = `/api/videos/get-hls-key?videoKey=${encodeURIComponent(vk)}&key=enc.key`;
                  } catch {}
                } else if (reqUrl.includes("cloudfront.net") && !reqUrl.includes("/api/video-proxy")) {
                  // Route all CloudFront manifests and segments through proxy to eliminate origin CORS blocks
                  finalUrl = `/api/video-proxy?url=${encodeURIComponent(reqUrl)}`;
                } else if (signedQs && !reqUrl.includes("?") && !reqUrl.includes(".key")) {
                  finalUrl = reqUrl + signedQs;
                }
                xhr.open("GET", finalUrl, true);
              },
            });

            hlsRef.current = hls;

            hls.on(Hls.Events.MANIFEST_PARSED, (_event: any, data: any) => {
              if (cancelled) return;
              const tracks: QualityTrack[] = [];
              const seen = new Set<number>();
              if (Array.isArray(data.levels)) {
                data.levels.forEach((l: any, i: number) => {
                  const h = l.height || 0;
                  if (h && !seen.has(h)) {
                    seen.add(h);
                    tracks.push({
                      height: h,
                      bandwidth: l.bitrate || 0,
                      levelIndex: i,
                    });
                  }
                });
                tracks.sort((a, b) => b.height - a.height);
                setQualities(tracks);
              }
              setStatus("ready");
              video.play().catch(() => {});
            });

            hls.on(Hls.Events.ERROR, (_event: any, data: any) => {
              if (cancelled) return;
              if (data.fatal) {
                switch (data.type) {
                  case Hls.ErrorTypes.NETWORK_ERROR:
                    console.warn("[HLS] Network error, recovering...", data);
                    hls.startLoad();
                    break;
                  case Hls.ErrorTypes.MEDIA_ERROR:
                    console.warn("[HLS] Media error, recovering...", data);
                    hls.recoverMediaError();
                    break;
                  default:
                    console.error("[HLS] Fatal playback error:", data);
                    setStatus("error");
                    setErrorMsg(`Stream error: ${data.details || "playback failed"}`);
                    break;
                }
              }
            });

            hls.loadSource(effectiveHlsUrl);
            hls.attachMedia(video);
          } else if (video.canPlayType("application/vnd.apple.mpegurl")) {
            // Safari native HLS
            video.src = effectiveHlsUrl;
            video.addEventListener("loadedmetadata", () => {
              setStatus("ready");
              video.play().catch(() => {});
            });
          } else {
            // Fallback to Shaka
            setPlayerEngine("shaka");
          }
        } else {
          // Shaka Player (DASH / DRM)
          const shakaModule = await import("shaka-player");
          const shaka = (shakaModule as any).default ?? shakaModule;
          if (cancelled) return;

          shaka.polyfill.installAll();
          const player = new shaka.Player();
          await player.attach(video);
          shakaRef.current = player;

          const config: any = {
            streaming: {
              bufferingGoal: 30,
              rebufferingGoal: 5,
              bufferBehind: 30,
              retryParameters: {
                maxAttempts: 3,
                baseDelay: 1000,
                backoffFactor: 1.5,
              },
            },
          };

          const activeTok = resolved.drmDetails?.licenseToken || resolved.token || authToken;
          if (resolved.drmDetails?.licenseToken || activeTok) {
            config.drm = {
              servers: {
                "com.widevine.alpha": resolved.drmDetails?.licenseUrl || "https://license-global.pallycon.com/ri/licenseManager.do",
              },
            };
          }

          player.configure(config);

          const netEngine = player.getNetworkingEngine();
          if (netEngine) {
            const requestType = shaka.net.NetworkingEngine.RequestType;
            netEngine.registerRequestFilter((type: number, request: any) => {
              if (!request.uris || request.uris.length === 0) return;

              // 1. Widevine License request
              if (type === requestType.LICENSE) {
                request.uris[0] = `/api/pallycon-license?url=${encodeURIComponent(request.uris[0])}`;
                if (activeTok) {
                  request.headers["pallycon-customdata-v2"] = activeTok;
                }
                request.headers["Content-Type"] = "application/octet-stream";
                return;
              }

              // 2. Intercept key request
              if (type === requestType.KEY) {
                const u = request.uris[0] || "";
                if (u.includes("get-hls-key")) {
                  try {
                    const parsedU = new URL(u, window.location.origin);
                    const vk = parsedU.searchParams.get("videoKey") || "";
                    request.uris[0] = `/api/videos/get-hls-key?videoKey=${encodeURIComponent(vk)}&key=enc.key`;
                    return;
                  } catch {}
                }
              }

              // 3. Route any CloudFront manifests and segments through proxy to eliminate origin CORS blocks
              const u = request.uris[0] || "";
              if (u.includes("cloudfront.net") && !u.includes("/api/video-proxy")) {
                let targetWithQs = u;
                if (signedQs && !targetWithQs.includes("?")) {
                  targetWithQs += signedQs;
                }
                request.uris[0] = `/api/video-proxy?url=${encodeURIComponent(targetWithQs)}`;
                return;
              }

              // 4. Append signed query parameters to manifests & segments
              if ((type === requestType.SEGMENT || type === requestType.MANIFEST) && signedQs) {
                const qp = signedQs.replace(/^\?/, "");
                request.uris = request.uris.map((u: string) => {
                  if (u.includes("Signature=") || u.includes("Policy=")) return u;
                  return u + (u.includes("?") ? "&" : "?") + qp;
                });
              }
            });
          }

          player.addEventListener("error", (ev: any) => {
            console.error("[Shaka Error]", ev);
            setStatus("error");
            setErrorMsg(`DASH error: ${ev?.detail?.message || "playback failed"}`);
          });

          player.addEventListener("streaming", () => {
            const tracks: QualityTrack[] = [];
            const seen = new Set<number>();
            (player.getVariantTracks() || []).forEach((t: any) => {
              if (t.height && !seen.has(t.height)) {
                seen.add(t.height);
                tracks.push({
                  height: t.height,
                  bandwidth: t.bandwidth || 0,
                  levelIndex: t.id,
                });
              }
            });
            tracks.sort((a, b) => b.height - a.height);
            setQualities(tracks);
          });

          await player.load(effectiveDashUrl);
          setStatus("ready");
          video.play().catch(() => {});
        }
      } catch (err: any) {
        if (!cancelled) {
          console.error("Player initialization failed:", err);
          setStatus("error");
          setErrorMsg(err?.message || "Failed to initialize video player.");
        }
      }
    }

    loadStream();

    return () => {
      cancelled = true;
      if (hlsRef.current) {
        hlsRef.current.destroy();
        hlsRef.current = null;
      }
      if (shakaRef.current) {
        shakaRef.current.destroy();
        shakaRef.current = null;
      }
    };
  }, [resolved, playerEngine, useProxy, ytEmbed]);

  // Handle Video Events
  const handleTimeUpdate = () => {
    if (!videoRef.current) return;
    setCurrentTime(videoRef.current.currentTime);
    setDuration(videoRef.current.duration || 0);

    // Calculate buffered percentage
    if (videoRef.current.buffered.length > 0) {
      setBufferedTime(videoRef.current.buffered.end(videoRef.current.buffered.length - 1));
    }
  };

  const togglePlay = () => {
    if (!videoRef.current) return;
    if (videoRef.current.paused) {
      videoRef.current.play().catch(() => {});
    } else {
      videoRef.current.pause();
    }
  };

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const target = parseFloat(e.target.value);
    if (videoRef.current) {
      videoRef.current.currentTime = target;
      setCurrentTime(target);
    }
  };

  const skipSeconds = (seconds: number) => {
    if (!videoRef.current) return;
    videoRef.current.currentTime = Math.max(0, Math.min(videoRef.current.duration || 0, videoRef.current.currentTime + seconds));
  };

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseFloat(e.target.value);
    setVolume(val);
    setIsMuted(val === 0);
    if (videoRef.current) {
      videoRef.current.volume = val;
      videoRef.current.muted = val === 0;
    }
  };

  const toggleMute = () => {
    if (!videoRef.current) return;
    if (isMuted) {
      videoRef.current.muted = false;
      setIsMuted(false);
      videoRef.current.volume = volume || 0.5;
    } else {
      videoRef.current.muted = true;
      setIsMuted(true);
    }
  };

  const changeSpeed = (rate: number) => {
    setPlaybackRate(rate);
    if (videoRef.current) {
      videoRef.current.playbackRate = rate;
    }
    setShowSettingsMenu(false);
  };

  const selectQuality = (q: number | "auto") => {
    setCurrentQuality(q);
    if (hlsRef.current) {
      if (q === "auto") {
        hlsRef.current.currentLevel = -1;
      } else {
        const found = qualities.find((x) => x.height === q);
        if (found) {
          hlsRef.current.currentLevel = found.levelIndex;
        }
      }
    }
    setShowSettingsMenu(false);
  };

  const toggleFullscreen = () => {
    if (!containerRef.current) return;
    if (!document.fullscreenElement) {
      containerRef.current.requestFullscreen().catch(() => {});
      setIsFullscreen(true);
    } else {
      document.exitFullscreen().catch(() => {});
      setIsFullscreen(false);
    }
  };

  const resetControlsTimeout = () => {
    setShowControls(true);
    if (hideControlsTimer.current) clearTimeout(hideControlsTimer.current);
    hideControlsTimer.current = setTimeout(() => {
      if (playing) {
        setShowControls(false);
        setShowSettingsMenu(false);
      }
    }, 3500);
  };

  const retryPlayback = () => {
    setStatus("resolving");
    setErrorMsg("");
    resolveVideoStream(batchId, childId, videoId).then((res) => {
      if (res) {
        setResolved(res);
        setStatus("loading");
      } else {
        setStatus("error");
        setErrorMsg("Failed to resolve stream on retry.");
      }
    });
  };

  return (
    <div className="bg-slate-900 rounded-2xl border border-slate-800 overflow-hidden shadow-2xl">
      {/* Video Viewport Container */}
      <div
        ref={containerRef}
        onMouseMove={resetControlsTimeout}
        onMouseLeave={() => playing && setShowControls(false)}
        className="relative aspect-video w-full bg-black flex items-center justify-center select-none overflow-hidden group"
      >
        {/* YouTube Embed Case */}
        {ytEmbed ? (
          <iframe
            src={ytEmbed.replace("watch?v=", "embed/")}
            title={lecture.topic}
            className="w-full h-full border-0"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
            allowFullScreen
          ></iframe>
        ) : playerMode === "pw-embed" ? (
          /* Official PW Player Embed */
          <div className="relative w-full h-full bg-black flex flex-col">
            <iframe
              id="pwOfficialPlayerIframe"
              src={watchUrl}
              title={lecture.topic}
              className="w-full h-full border-0"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share; fullscreen"
              allowFullScreen
            />
          </div>
        ) : (
          <>
            {/* Native Video Element */}
            <video
              ref={videoRef}
              onClick={togglePlay}
              onPlay={() => setPlaying(true)}
              onPause={() => setPlaying(false)}
              onTimeUpdate={handleTimeUpdate}
              playsInline
              className="w-full h-full object-contain cursor-pointer"
              poster={lecture.videoDetails?.image}
            />

            {/* Resolving / Loading Overlay */}
            {(status === "resolving" || status === "loading") && (
              <div className="absolute inset-0 bg-slate-950/80 backdrop-blur-sm flex flex-col items-center justify-center text-center p-6 z-20">
                <RefreshCw className="w-10 h-10 text-cyan-400 animate-spin mb-4" />
                <p className="text-white font-semibold text-base">{statusMsg}</p>
                <p className="text-slate-400 text-xs mt-1">
                  Authenticating stream with CloudFront DRM & PenPencil Media Engine
                </p>
              </div>
            )}

            {/* Error Overlay */}
            {status === "error" && (
              <div className="absolute inset-0 bg-slate-950/90 backdrop-blur-md flex flex-col items-center justify-center text-center p-6 z-20">
                <AlertCircle className="w-12 h-12 text-rose-500 mb-3" />
                <p className="text-white font-bold text-base mb-1">Direct Decryption Restricted</p>
                <p className="text-slate-400 text-xs max-w-md mb-6">
                  This lecture uses high-definition PW Cloud DRM. Play it instantly via the Official PW Player or Standalone Theater below.
                </p>
                <div className="flex flex-wrap items-center justify-center gap-3">
                  <button
                    onClick={() => setPlayerMode("pw-embed")}
                    className="inline-flex items-center space-x-2 px-5 py-2.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-bold shadow-lg shadow-cyan-900/40 transition-colors"
                  >
                    <Play className="w-3.5 h-3.5 fill-current" />
                    <span>Play in Official PW HD Player</span>
                  </button>
                  <button
                    onClick={openStandalonePlayer}
                    className="inline-flex items-center space-x-2 px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold transition-colors"
                  >
                    <ExternalLink className="w-3.5 h-3.5" />
                    <span>Launch Theater Window</span>
                  </button>
                  <button
                    onClick={retryPlayback}
                    className="px-3.5 py-2.5 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-400 hover:text-white text-xs font-medium transition-colors"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            )}

            {/* Big Center Play/Pause button on pause */}
            {status === "ready" && !playing && (
              <button
                onClick={togglePlay}
                className="absolute z-10 w-16 h-16 rounded-full bg-cyan-500/90 hover:bg-cyan-400 text-black flex items-center justify-center shadow-xl shadow-cyan-950/60 transition-transform active:scale-95"
              >
                <Play className="w-8 h-8 fill-current translate-x-0.5" />
              </button>
            )}

            {/* Custom Interactive Controls Bar */}
            {status === "ready" && (
              <div
                className={`absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/90 via-black/50 to-transparent pt-10 pb-3 px-4 z-20 transition-opacity duration-300 ${
                  showControls || !playing ? "opacity-100 pointer-events-auto" : "opacity-0 pointer-events-none"
                }`}
              >
                {/* Seek Bar */}
                <div className="relative group/seek mb-3">
                  {/* Buffer & Progress visual bar */}
                  <div className="h-1.5 w-full bg-slate-700/60 rounded-full overflow-hidden relative">
                    <div
                      className="absolute left-0 top-0 bottom-0 bg-slate-500/50 rounded-full transition-all"
                      style={{ width: `${duration ? (bufferedTime / duration) * 100 : 0}%` }}
                    />
                    <div
                      className="absolute left-0 top-0 bottom-0 bg-cyan-400 rounded-full"
                      style={{ width: `${duration ? (currentTime / duration) * 100 : 0}%` }}
                    />
                  </div>
                  <input
                    type="range"
                    min={0}
                    max={duration || 100}
                    step={0.1}
                    value={currentTime}
                    onChange={handleSeek}
                    className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                  />
                </div>

                {/* Bottom Buttons Bar */}
                <div className="flex items-center justify-between text-white text-xs px-1 sm:px-2">
                  {/* Left: Play/Pause, Skips, Time */}
                  <div className="flex items-center space-x-1.5 sm:space-x-3">
                    <button
                      onClick={togglePlay}
                      className="p-1 sm:p-1.5 hover:text-cyan-400 transition-colors"
                      title={playing ? "Pause (Space)" : "Play (Space)"}
                    >
                      {playing ? <Pause className="w-5 h-5 fill-current" /> : <Play className="w-5 h-5 fill-current" />}
                    </button>

                    <button
                      onClick={() => skipSeconds(-10)}
                      className="p-1 sm:p-1.5 hover:text-cyan-400 transition-colors"
                      title="Rewind 10s"
                    >
                      <RotateCcw className="w-4 h-4" />
                    </button>

                    <button
                      onClick={() => skipSeconds(10)}
                      className="p-1 sm:p-1.5 hover:text-cyan-400 transition-colors"
                      title="Forward 10s"
                    >
                      <RotateCw className="w-4 h-4" />
                    </button>

                    {/* Volume - hidden on mobile phones where physical buttons are standard */}
                    <div className="hidden sm:flex items-center space-x-1.5 group/vol">
                      <button onClick={toggleMute} className="p-1.5 hover:text-cyan-400 transition-colors">
                        {isMuted || volume === 0 ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                      </button>
                      <input
                        type="range"
                        min={0}
                        max={1}
                        step={0.05}
                        value={isMuted ? 0 : volume}
                        onChange={handleVolumeChange}
                        className="w-16 h-1 accent-cyan-400 bg-slate-700 rounded cursor-pointer"
                      />
                    </div>

                    {/* Time display */}
                    <span className="font-mono text-slate-300 text-[10px] sm:text-[11px] pl-0.5 sm:pl-1 whitespace-nowrap">
                      {formatTime(currentTime)} / {formatTime(duration)}
                    </span>
                  </div>

                  {/* Right: Engine Tag, Settings, Fullscreen */}
                  <div className="flex items-center space-x-1.5 sm:space-x-3 relative">
                    {/* Engine badge (hidden on extra small screens) */}
                    <span
                      onClick={() => setPlayerEngine(playerEngine === "hls" ? "shaka" : "hls")}
                      className="hidden sm:inline-block cursor-pointer px-2 py-0.5 text-[10px] font-bold rounded bg-cyan-950/80 text-cyan-400 border border-cyan-800/80 hover:bg-cyan-900/60 transition-colors"
                      title="Click to toggle between HLS and DASH engine"
                    >
                      {playerEngine.toUpperCase()}
                    </span>

                    {/* Settings Menu Toggle */}
                    <div className="relative">
                      <button
                        onClick={() => {
                          setShowSettingsMenu(!showSettingsMenu);
                          setActiveMenuTab("main");
                        }}
                        className={`p-1 sm:p-1.5 transition-colors ${showSettingsMenu ? "text-cyan-400" : "hover:text-cyan-400"}`}
                        title="Settings"
                      >
                        <Settings className="w-4 h-4" />
                      </button>

                      {/* Settings Popup Menu */}
                      {showSettingsMenu && (
                        <div className="absolute right-0 bottom-full mb-3 w-52 bg-slate-950/95 border border-slate-800 rounded-xl shadow-2xl p-2 z-30 backdrop-blur-md">
                          {activeMenuTab === "main" && (
                            <div className="space-y-1 text-xs">
                              <button
                                onClick={() => setActiveMenuTab("quality")}
                                className="w-full flex items-center justify-between p-2 rounded-lg hover:bg-slate-800 text-slate-300 hover:text-white"
                              >
                                <span>Quality</span>
                                <span className="text-cyan-400 font-medium">
                                  {currentQuality === "auto" ? "Auto" : `${currentQuality}p`}
                                </span>
                              </button>
                              <button
                                onClick={() => setActiveMenuTab("speed")}
                                className="w-full flex items-center justify-between p-2 rounded-lg hover:bg-slate-800 text-slate-300 hover:text-white"
                              >
                                <span>Speed</span>
                                <span className="text-cyan-400 font-medium">{playbackRate}x</span>
                              </button>
                              <button
                                onClick={() => {
                                  setUseProxy(!useProxy);
                                  setShowSettingsMenu(false);
                                }}
                                className="w-full flex items-center justify-between p-2 rounded-lg hover:bg-slate-800 text-slate-300 hover:text-white"
                              >
                                <span>Proxy Mode</span>
                                <span className="text-slate-400">{useProxy ? "Enabled" : "Direct"}</span>
                              </button>
                            </div>
                          )}

                          {activeMenuTab === "quality" && (
                            <div className="space-y-1 text-xs">
                              <div className="px-2 py-1 text-[11px] font-bold text-slate-500 uppercase tracking-wider">
                                Video Quality
                              </div>
                              <button
                                onClick={() => selectQuality("auto")}
                                className="w-full flex items-center justify-between p-2 rounded-lg hover:bg-slate-800 text-slate-200"
                              >
                                <span>Auto</span>
                                {currentQuality === "auto" && <Check className="w-3.5 h-3.5 text-cyan-400" />}
                              </button>
                              {qualities.map((q) => (
                                <button
                                  key={q.height}
                                  onClick={() => selectQuality(q.height)}
                                  className="w-full flex items-center justify-between p-2 rounded-lg hover:bg-slate-800 text-slate-200"
                                >
                                  <span>{q.height}p</span>
                                  {currentQuality === q.height && <Check className="w-3.5 h-3.5 text-cyan-400" />}
                                </button>
                              ))}
                              <button
                                onClick={() => setActiveMenuTab("main")}
                                className="w-full text-center text-slate-400 hover:text-white pt-2 text-[11px] border-t border-slate-800"
                              >
                                ← Back
                              </button>
                            </div>
                          )}

                          {activeMenuTab === "speed" && (
                            <div className="space-y-1 text-xs">
                              <div className="px-2 py-1 text-[11px] font-bold text-slate-500 uppercase tracking-wider">
                                Playback Speed
                              </div>
                              {[0.5, 0.75, 1, 1.25, 1.5, 1.75, 2].map((s) => (
                                <button
                                  key={s}
                                  onClick={() => changeSpeed(s)}
                                  className="w-full flex items-center justify-between p-2 rounded-lg hover:bg-slate-800 text-slate-200"
                                >
                                  <span>{s}x</span>
                                  {playbackRate === s && <Check className="w-3.5 h-3.5 text-cyan-400" />}
                                </button>
                              ))}
                              <button
                                onClick={() => setActiveMenuTab("main")}
                                className="w-full text-center text-slate-400 hover:text-white pt-2 text-[11px] border-t border-slate-800"
                              >
                                ← Back
                              </button>
                            </div>
                          )}
                        </div>
                      )}
                    </div>

                    {/* Fullscreen */}
                    <button
                      onClick={toggleFullscreen}
                      className="p-1.5 hover:text-cyan-400 transition-colors"
                      title={isFullscreen ? "Exit Fullscreen (f)" : "Fullscreen (f)"}
                    >
                      {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
                    </button>
                  </div>
                </div>
              </div>
            )}
          </>
        )}
      </div>

      {/* Player Mode Switcher & Quick Launch Bar */}
      {!ytEmbed && (
        <div className="bg-slate-950/90 border-t border-slate-800/80 px-4 py-2.5 flex flex-wrap items-center justify-between gap-3 text-xs">
          {/* Mode Switcher */}
          <div className="flex items-center space-x-1.5 bg-slate-900 p-1 rounded-xl border border-slate-800">
            <button
              onClick={() => setPlayerMode("pw-embed")}
              className={`inline-flex items-center space-x-1.5 px-3 py-1.5 rounded-lg font-semibold transition-all ${
                playerMode === "pw-embed"
                  ? "bg-cyan-600 text-white shadow-sm shadow-cyan-900/40"
                  : "text-slate-400 hover:text-slate-200"
              }`}
            >
              <Monitor className="w-3.5 h-3.5" />
              <span>Official PW Player (1080p HD)</span>
            </button>

            <button
              onClick={() => {
                setPlayerMode("native");
                if (status === "error") retryPlayback();
              }}
              className={`inline-flex items-center space-x-1.5 px-3 py-1.5 rounded-lg font-semibold transition-all ${
                playerMode === "native"
                  ? "bg-cyan-600 text-white shadow-sm shadow-cyan-900/40"
                  : "text-slate-400 hover:text-slate-200"
              }`}
            >
              <Zap className="w-3.5 h-3.5" />
              <span>Native Shaka Engine</span>
            </button>
          </div>

          {/* Quick Actions */}
          <div className="flex items-center space-x-2">
            <button
              onClick={openStandalonePlayer}
              className="inline-flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700/80 font-medium transition-colors"
              title="Launch cinema popup window with hardware DRM acceleration"
            >
              <ExternalLink className="w-3.5 h-3.5 text-cyan-400" />
              <span>Standalone Cinema Window</span>
            </button>

            <a
              href={officialClassroomUrl}
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700/80 font-medium transition-colors"
              title="Open directly in PW MedEd Web App"
            >
              <Globe className="w-3.5 h-3.5 text-teal-400" />
              <span className="hidden sm:inline">PW MedEd Web App</span>
            </a>
          </div>
        </div>
      )}

      {/* Optional Video Details & Stream Info Bar */}
      {showMetaBar && (
        <div className="p-5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <span className="px-2 py-0.5 text-[11px] font-bold bg-cyan-950 text-cyan-400 border border-cyan-800/80 rounded">
                  {lecture.lectureType || "LECTURE"}
                </span>
                {lecture.duration && (
                  <span className="text-xs text-slate-400">Duration: {lecture.duration}</span>
                )}
                {resolved && (
                  <span className="inline-flex items-center space-x-1 px-2 py-0.5 text-[11px] font-semibold bg-emerald-950/80 text-emerald-400 border border-emerald-800/80 rounded">
                    <ShieldCheck className="w-3 h-3" />
                    <span>CloudFront Authenticated</span>
                  </span>
                )}
              </div>
              <h2 className="text-xl font-bold text-white mt-1.5">{lecture.topic}</h2>
            </div>

            {/* Quick Stream Links & Actions */}
            <div className="flex items-center space-x-2">
              {resolved?.hlsUrl && (
                <a
                  href={resolved.hlsUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white text-xs font-medium transition-colors"
                  title="Open CloudFront authenticated manifest"
                >
                  <span>Signed HLS</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
